// Minimal design tokens for the MVP. Mirrors the dark surface used in the
// architecture map so the native app feels of a piece with skriuw.com.
export const palette = {
  bg: "#0d1117",
  surface: "#161b22",
  surfaceAlt: "#1c222b",
  border: "#2d333b",
  text: "#e6edf3",
  textDim: "#8b949e",
  accent: "#58a6ff",
  green: "#3fb950",
  amber: "#d29922",
  pink: "#f778ba",
  code: "#0b0e14",
} as const;

export type Palette = typeof palette;
