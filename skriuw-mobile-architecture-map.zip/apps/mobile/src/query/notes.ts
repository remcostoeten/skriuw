// React Query hooks over the WorkspaceBackend. Screens never touch the backend
// directly — they go through these so caching, invalidation and optimistic
// updates live in one place.
import {
  useMutation,
  useQuery,
  useQueryClient,
} from "@tanstack/react-query";
import { mobileBackend } from "@/backend/http-backend";
import type {
  CreateNoteInput,
  NoteSummary,
  UpdateNoteInput,
} from "@/backend/types";
import { notesKeys } from "@/query/notes-keys";

export function useNotes(folderId?: string | null) {
  return useQuery({
    queryKey: notesKeys.files(folderId),
    queryFn: () => mobileBackend.listNotes(folderId),
  });
}

export function useNote(id: string) {
  return useQuery({
    queryKey: notesKeys.detail(id),
    queryFn: () => mobileBackend.getNote(id),
    enabled: Boolean(id),
  });
}

export function useFolders() {
  return useQuery({
    queryKey: notesKeys.folders,
    queryFn: () => mobileBackend.listFolders(),
  });
}

export function useSearch(query: string) {
  return useQuery({
    queryKey: notesKeys.search(query),
    queryFn: () => mobileBackend.search(query),
    enabled: query.trim().length > 0,
  });
}

export function useCreateNote() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (input: CreateNoteInput) => mobileBackend.createNote(input),
    onSuccess: (note) => {
      qc.invalidateQueries({ queryKey: notesKeys.files(note.folderId) });
    },
  });
}

export function useUpdateNote() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (input: UpdateNoteInput) => mobileBackend.updateNote(input),
    onSuccess: (note) => {
      qc.setQueryData(notesKeys.detail(note.id), note);
      qc.invalidateQueries({ queryKey: notesKeys.files(note.folderId) });
    },
  });
}

export function useDeleteNote() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => mobileBackend.deleteNote(id),
    onMutate: async (id) => {
      // Optimistic removal from any cached list.
      await qc.cancelQueries({ queryKey: notesKeys.all });
      const lists = qc.getQueriesData<NoteSummary[]>({ queryKey: notesKeys.all });
      for (const [key, data] of lists) {
        if (Array.isArray(data)) {
          qc.setQueryData(
            key,
            data.filter((n) => n.id !== id),
          );
        }
      }
      return { lists };
    },
    onError: (_err, _id, ctx) => {
      ctx?.lists.forEach(([key, data]) => qc.setQueryData(key, data));
    },
    onSettled: () => {
      qc.invalidateQueries({ queryKey: notesKeys.all });
    },
  });
}
