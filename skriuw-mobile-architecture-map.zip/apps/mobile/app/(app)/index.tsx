import { useRouter } from "expo-router";
import {
  ActivityIndicator,
  FlatList,
  Pressable,
  RefreshControl,
  Text,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useNotes } from "@/query/notes";
import type { NoteSummary } from "@/backend/types";
import { palette } from "@/theme/colors";

export default function NotesListScreen() {
  const router = useRouter();
  const { data: notes, isLoading, isError, refetch, isRefetching } = useNotes(null);

  return (
    <SafeAreaView edges={["bottom"]} style={{ flex: 1, backgroundColor: palette.bg }}>
      {isLoading ? (
        <Centered>
          <ActivityIndicator color={palette.accent} />
        </Centered>
      ) : isError ? (
        <Centered>
          <Text style={{ color: palette.textDim }}>Could not load notes.</Text>
          <Pressable onPress={() => refetch()} style={{ marginTop: 12 }}>
            <Text style={{ color: palette.accent }}>Retry</Text>
          </Pressable>
        </Centered>
      ) : (
        <FlatList
          data={notes}
          keyExtractor={(n) => n.id}
          refreshControl={
            <RefreshControl
              refreshing={isRefetching}
              onRefresh={refetch}
              tintColor={palette.textDim}
            />
          }
          ListEmptyComponent={
            <Centered>
              <Text style={{ color: palette.textDim }}>No notes yet.</Text>
            </Centered>
          }
          renderItem={({ item }) => (
            <NoteRow note={item} onPress={() => router.push(`/(app)/note/${item.id}`)} />
          )}
        />
      )}

      <Toolbar
        onSearch={() => router.push("/(app)/search")}
        onSettings={() => router.push("/(app)/settings")}
      />
    </SafeAreaView>
  );
}

function NoteRow({ note, onPress }: { note: NoteSummary; onPress: () => void }) {
  return (
    <Pressable
      onPress={onPress}
      style={{
        paddingHorizontal: 16,
        paddingVertical: 14,
        borderBottomWidth: 1,
        borderBottomColor: palette.border,
      }}
    >
      <Text style={{ color: palette.text, fontSize: 16, fontWeight: "600" }} numberOfLines={1}>
        {note.title || "Untitled"}
      </Text>
      {note.preview ? (
        <Text style={{ color: palette.textDim, fontSize: 14, marginTop: 4 }} numberOfLines={2}>
          {note.preview}
        </Text>
      ) : null}
    </Pressable>
  );
}

function Toolbar({
  onSearch,
  onSettings,
}: {
  onSearch: () => void;
  onSettings: () => void;
}) {
  return (
    <View
      style={{
        flexDirection: "row",
        justifyContent: "space-around",
        borderTopWidth: 1,
        borderTopColor: palette.border,
        paddingVertical: 12,
      }}
    >
      <Pressable onPress={onSearch}>
        <Text style={{ color: palette.accent, fontSize: 15 }}>Search</Text>
      </Pressable>
      <Pressable onPress={onSettings}>
        <Text style={{ color: palette.accent, fontSize: 15 }}>Settings</Text>
      </Pressable>
    </View>
  );
}

function Centered({ children }: { children: React.ReactNode }) {
  return (
    <View style={{ flex: 1, alignItems: "center", justifyContent: "center", padding: 24 }}>
      {children}
    </View>
  );
}
