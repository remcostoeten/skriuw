import { Pressable, Text, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { signOut, useSession } from "@/auth/auth-client";
import { getApiBaseUrl } from "@/lib/config";
import { palette } from "@/theme/colors";

export default function SettingsScreen() {
  const { data: session } = useSession();

  return (
    <SafeAreaView edges={["bottom"]} style={{ flex: 1, backgroundColor: palette.bg }}>
      <View style={{ padding: 16 }}>
        <Row label="Signed in as" value={session?.user?.email ?? "\u2014"} />
        <Row label="Workspace" value={getApiBaseUrl().replace(/^https?:\/\//, "")} />

        <Pressable
          onPress={() => signOut()}
          style={{
            marginTop: 28,
            backgroundColor: palette.surface,
            borderWidth: 1,
            borderColor: palette.border,
            borderRadius: 10,
            paddingVertical: 14,
            alignItems: "center",
          }}
        >
          <Text style={{ color: palette.pink, fontSize: 16, fontWeight: "600" }}>Sign out</Text>
        </Pressable>
      </View>
    </SafeAreaView>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <View
      style={{
        paddingVertical: 14,
        borderBottomWidth: 1,
        borderBottomColor: palette.border,
      }}
    >
      <Text style={{ color: palette.textDim, fontSize: 12, marginBottom: 4 }}>{label}</Text>
      <Text style={{ color: palette.text, fontSize: 16 }}>{value}</Text>
    </View>
  );
}
