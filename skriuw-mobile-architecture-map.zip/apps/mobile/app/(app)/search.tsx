import { useState } from "react";
import { useRouter } from "expo-router";
import { ActivityIndicator, FlatList, Pressable, Text, TextInput, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useSearch } from "@/query/notes";
import { palette } from "@/theme/colors";

// Query grammar (tag:/# person:/$ free text) is parsed locally on web via the
// shared search-query.ts module; execution happens server-side. Here we send
// the raw query straight to GET /api/workspace/search.
export default function SearchScreen() {
  const router = useRouter();
  const [query, setQuery] = useState("");
  const { data: results, isFetching } = useSearch(query);

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: palette.bg }}>
      <View style={{ padding: 16 }}>
        <TextInput
          autoFocus
          value={query}
          onChangeText={setQuery}
          placeholder={"Search notes, #tags, $people\u2026"}
          placeholderTextColor={palette.textDim}
          style={{
            backgroundColor: palette.surface,
            borderWidth: 1,
            borderColor: palette.border,
            borderRadius: 10,
            paddingHorizontal: 14,
            paddingVertical: 12,
            color: palette.text,
            fontSize: 16,
          }}
        />
      </View>

      {isFetching ? (
        <View style={{ padding: 24, alignItems: "center" }}>
          <ActivityIndicator color={palette.accent} />
        </View>
      ) : (
        <FlatList
          data={results}
          keyExtractor={(r) => r.noteId}
          renderItem={({ item }) => (
            <Pressable
              onPress={() => router.push(`/(app)/note/${item.noteId}`)}
              style={{
                paddingHorizontal: 16,
                paddingVertical: 12,
                borderBottomWidth: 1,
                borderBottomColor: palette.border,
              }}
            >
              <Text style={{ color: palette.text, fontSize: 15, fontWeight: "600" }}>
                {item.title}
              </Text>
              <Text style={{ color: palette.textDim, fontSize: 13, marginTop: 2 }} numberOfLines={2}>
                {item.snippet}
              </Text>
            </Pressable>
          )}
        />
      )}
    </SafeAreaView>
  );
}
