import { useCallback, useLayoutEffect } from "react";
import { useLocalSearchParams, useNavigation, useRouter } from "expo-router";
import { useQueryClient } from "@tanstack/react-query";
import { ActivityIndicator, ScrollView, Text, View } from "react-native";
import { useNote, useUpdateNote } from "@/query/notes";
import { notesKeys } from "@/query/notes-keys";
import { RichRenderer } from "@/renderer/RichRenderer";
import { setBlockChecked } from "@/domain/rich-document";
import { richToMarkdown } from "@/domain/rich-to-markdown";
import type { Note } from "@/backend/types";
import { palette } from "@/theme/colors";

export default function NoteScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const navigation = useNavigation();
  const qc = useQueryClient();
  const { data: note, isLoading, isError } = useNote(id);
  const updateNote = useUpdateNote();

  // Toggle a checklist item in the read view: optimistically patch the cached
  // note's richContent, emit markdown, and persist. Markdown is the source of
  // truth server-side, so we send `content`; the precondition guards conflicts.
  const handleToggleCheck = useCallback(
    (blockId: string, checked: boolean) => {
      const current = qc.getQueryData<Note>(notesKeys.detail(id));
      if (!current?.richContent) return;

      const nextRich = setBlockChecked(current.richContent, blockId, checked);
      if (nextRich === current.richContent) return;
      const nextContent = richToMarkdown(nextRich);

      // Optimistic cache update so the checkbox flips instantly.
      qc.setQueryData<Note>(notesKeys.detail(id), {
        ...current,
        richContent: nextRich,
        content: nextContent,
      });

      updateNote.mutate(
        { id, content: nextContent, expectedUpdatedAt: current.updatedAt },
        {
          // On failure (e.g. ConflictError) roll back to the server truth.
          onError: () => qc.setQueryData<Note>(notesKeys.detail(id), current),
        },
      );
    },
    [id, qc, updateNote],
  );

  useLayoutEffect(() => {
    navigation.setOptions({ title: note?.title ?? "" });
  }, [navigation, note?.title]);

  if (isLoading) {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: palette.bg }}>
        <ActivityIndicator color={palette.accent} />
      </View>
    );
  }

  if (isError || !note) {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center", backgroundColor: palette.bg }}>
        <Text style={{ color: palette.textDim }}>Note unavailable offline.</Text>
      </View>
    );
  }

  // Prefer the native rich renderer; fall back to raw markdown text for notes
  // saved in raw mode (richContent === null) until the read renderer derives it.
  if (note.richContent && note.richContent.length > 0) {
    return (
      <View style={{ flex: 1, backgroundColor: palette.bg }}>
        <RichRenderer
          document={note.richContent}
          onNavigateNote={(noteId) => router.push(`/(app)/note/${noteId}`)}
          onToggleCheck={handleToggleCheck}
        />
      </View>
    );
  }

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: palette.bg }}
      contentContainerStyle={{ padding: 16 }}
    >
      <Text style={{ color: palette.text, fontSize: 16, lineHeight: 24, fontFamily: "SpaceMono" }}>
        {note.content}
      </Text>
    </ScrollView>
  );
}
