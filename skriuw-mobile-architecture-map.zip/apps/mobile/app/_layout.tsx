import { useEffect } from "react";
import { Slot, useRouter, useSegments } from "expo-router";
import { StatusBar } from "expo-status-bar";
import { SafeAreaProvider } from "react-native-safe-area-context";
import { View } from "react-native";
import { AppProviders } from "@/providers/AppProviders";
import { useSession } from "@/auth/auth-client";
import { palette } from "@/theme/colors";

/** Redirects between the (auth) and (app) groups based on session state. */
function AuthGate() {
  const { data: session, isPending } = useSession();
  const segments = useSegments();
  const router = useRouter();

  useEffect(() => {
    if (isPending) return;
    const inAuthGroup = segments[0] === "(auth)";
    if (!session && !inAuthGroup) {
      router.replace("/(auth)/sign-in");
    } else if (session && inAuthGroup) {
      router.replace("/(app)");
    }
  }, [session, isPending, segments, router]);

  return <Slot />;
}

export default function RootLayout() {
  return (
    <SafeAreaProvider>
      <View style={{ flex: 1, backgroundColor: palette.bg }}>
        <StatusBar style="light" />
        <AppProviders>
          <AuthGate />
        </AppProviders>
      </View>
    </SafeAreaProvider>
  );
}
