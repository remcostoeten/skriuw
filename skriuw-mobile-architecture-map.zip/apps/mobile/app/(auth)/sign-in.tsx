import { useState } from "react";
import {
  ActivityIndicator,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  Text,
  TextInput,
  View,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { signIn } from "@/auth/auth-client";
import { palette } from "@/theme/colors";

// MVP: email + password only. GitHub/Google OAuth (skriuw:// deep link) is V1.1.
export default function SignInScreen() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit() {
    setError(null);
    setLoading(true);
    try {
      const res = await signIn.email({ email, password });
      if (res.error) setError(res.error.message ?? "Sign in failed");
    } catch {
      setError("Network error. Check your connection and try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <SafeAreaView style={{ flex: 1, backgroundColor: palette.bg }}>
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : undefined}
        style={{ flex: 1, justifyContent: "center", padding: 24 }}
      >
        <Text style={{ color: palette.text, fontSize: 30, fontWeight: "700", marginBottom: 6 }}>
          Skriuw
        </Text>
        <Text style={{ color: palette.textDim, fontSize: 15, marginBottom: 28 }}>
          Sign in to your workspace
        </Text>

        <Field
          label="Email"
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
          autoCapitalize="none"
          placeholder="you@example.com"
        />
        <Field
          label="Password"
          value={password}
          onChangeText={setPassword}
          secureTextEntry
          placeholder={"\u2022\u2022\u2022\u2022\u2022\u2022\u2022\u2022"}
        />

        {error ? (
          <Text style={{ color: palette.pink, fontSize: 13, marginBottom: 12 }}>{error}</Text>
        ) : null}

        <Pressable
          onPress={onSubmit}
          disabled={loading || !email || !password}
          style={{
            backgroundColor: palette.accent,
            borderRadius: 10,
            paddingVertical: 14,
            alignItems: "center",
            opacity: loading || !email || !password ? 0.5 : 1,
          }}
        >
          {loading ? (
            <ActivityIndicator color={palette.bg} />
          ) : (
            <Text style={{ color: palette.bg, fontSize: 16, fontWeight: "600" }}>Sign in</Text>
          )}
        </Pressable>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}

function Field({
  label,
  ...props
}: { label: string } & React.ComponentProps<typeof TextInput>) {
  return (
    <View style={{ marginBottom: 16 }}>
      <Text style={{ color: palette.textDim, fontSize: 13, marginBottom: 6 }}>{label}</Text>
      <TextInput
        {...props}
        placeholderTextColor={palette.textDim}
        style={{
          backgroundColor: palette.surface,
          borderWidth: 1,
          borderColor: palette.border,
          borderRadius: 10,
          paddingHorizontal: 14,
          paddingVertical: 12,
          color: palette.text,
          fontSize: 16,
        }}
      />
    </View>
  );
}
