import { useSyncExternalStore } from "react";

export type Priority = "urgent" | "high" | "medium" | "low";

export type Subtask = { id: string; title: string; done: boolean };

export type Task = {
  id: string;
  title: string;
  done: boolean;
  priority: Priority;
  due?: string; // ISO yyyy-mm-dd
  project?: string;
  tags: string[];
  assignees: string[];
  description?: string;
  subtasks: Subtask[];
  createdAt: string;
  updatedAt: string;
};

export const priorityMeta: Record<Priority, { label: string; dot: string; text: string }> = {
  urgent: { label: "Urgent", dot: "bg-rose-400", text: "text-rose-400" },
  high: { label: "High", dot: "bg-amber-400", text: "text-amber-400" },
  medium: { label: "Medium", dot: "bg-sky-400", text: "text-sky-400" },
  low: { label: "Low", dot: "bg-emerald-400", text: "text-emerald-400" },
};

// Anchor demo dates around "today" (July 11, 2026 per system) but use real today
// so calendar highlights work naturally.
const iso = (d: Date) => d.toISOString().slice(0, 10);
const today = new Date();
const addDays = (n: number) => {
  const d = new Date(today);
  d.setDate(d.getDate() + n);
  return iso(d);
};

const seed: Task[] = [
  {
    id: "SKR-42",
    title: "Open the inspector to see note metadata",
    done: false,
    priority: "high",
    due: addDays(0),
    project: "Skriuw onboarding",
    tags: ["getting-started", "onboarding"],
    assignees: ["S", "A"],
    description:
      "Give the reader a fast win. Walk a new user through opening the inspector, landing them on the note metadata that makes Skriuw feel connected.",
    subtasks: [
      { id: "s1", title: "Draft acceptance criteria", done: true },
      { id: "s2", title: "Review with @alex", done: true },
      { id: "s3", title: "Push to staging", done: false },
      { id: "s4", title: "Ship it", done: false },
    ],
    createdAt: addDays(-3),
    updatedAt: addDays(0),
  },
  {
    id: "SKR-43",
    title: "Write the weekly review template",
    done: false,
    priority: "medium",
    due: addDays(1),
    project: "Journaling",
    tags: ["template", "weekly"],
    assignees: ["S"],
    description: "A short prompt list: wins, drags, next steps. Keep it under a screen.",
    subtasks: [
      { id: "s1", title: "Collect existing prompts", done: true },
      { id: "s2", title: "Draft in a note", done: false },
    ],
    createdAt: addDays(-2),
    updatedAt: addDays(-1),
  },
  {
    id: "SKR-44",
    title: "Backlink the handbook to the welcome note",
    done: false,
    priority: "low",
    due: addDays(3),
    project: "Skriuw onboarding",
    tags: ["links"],
    assignees: ["A"],
    subtasks: [],
    createdAt: addDays(-5),
    updatedAt: addDays(-1),
  },
  {
    id: "SKR-45",
    title: "Ship the calendar view for tasks",
    done: false,
    priority: "urgent",
    due: addDays(0),
    project: "Tasks",
    tags: ["ui", "milestone"],
    assignees: ["S"],
    description: "Month grid with dots for each due date. Click a day to filter the list.",
    subtasks: [
      { id: "s1", title: "Grid layout", done: true },
      { id: "s2", title: "Task dots per day", done: false },
      { id: "s3", title: "Day drawer", done: false },
    ],
    createdAt: addDays(-1),
    updatedAt: addDays(0),
  },
  {
    id: "SKR-46",
    title: "Reply to Alex about the tag picker",
    done: false,
    priority: "medium",
    due: addDays(-1),
    project: "Skriuw onboarding",
    tags: ["inbox"],
    assignees: ["S"],
    subtasks: [],
    createdAt: addDays(-4),
    updatedAt: addDays(-1),
  },
  {
    id: "SKR-47",
    title: "Archive last quarter's daily notes",
    done: true,
    priority: "low",
    due: addDays(-3),
    project: "Journaling",
    tags: ["cleanup"],
    assignees: ["S"],
    subtasks: [],
    createdAt: addDays(-10),
    updatedAt: addDays(-3),
  },
  {
    id: "SKR-48",
    title: "Draft the Q3 roadmap",
    done: false,
    priority: "high",
    due: addDays(6),
    project: "Tasks",
    tags: ["planning"],
    assignees: ["S", "A"],
    description: "Anchor around three themes: capture, connect, ship.",
    subtasks: [
      { id: "s1", title: "List candidate themes", done: false },
      { id: "s2", title: "Score by user impact", done: false },
    ],
    createdAt: addDays(-1),
    updatedAt: addDays(0),
  },
  {
    id: "SKR-49",
    title: "Nothing urgent — just a reminder",
    done: false,
    priority: "low",
    tags: ["someday"],
    assignees: [],
    subtasks: [],
    createdAt: addDays(-7),
    updatedAt: addDays(-7),
  },
  {
    id: "SKR-50",
    title: "Sketch the daily journal widget",
    done: false,
    priority: "medium",
    due: addDays(2),
    project: "Journaling",
    tags: ["design"],
    assignees: ["A"],
    subtasks: [
      { id: "s1", title: "Explore two layouts", done: false },
    ],
    createdAt: addDays(-2),
    updatedAt: addDays(-1),
  },
  {
    id: "SKR-51",
    title: "Fix keyboard focus in the task drawer",
    done: true,
    priority: "high",
    due: addDays(-2),
    project: "Tasks",
    tags: ["a11y", "bug"],
    assignees: ["S"],
    subtasks: [],
    createdAt: addDays(-6),
    updatedAt: addDays(-2),
  },
];

// ------------- store -------------

let state: Task[] = seed;
const listeners = new Set<() => void>();
const emit = () => listeners.forEach((l) => l());

const subscribe = (l: () => void) => {
  listeners.add(l);
  return () => listeners.delete(l);
};
const getSnapshot = () => state;

export function useTasks(): Task[] {
  return useSyncExternalStore(subscribe, getSnapshot, getSnapshot);
}

export function useTask(id: string | null | undefined): Task | undefined {
  const tasks = useTasks();
  return id ? tasks.find((t) => t.id === id) : undefined;
}

const update = (id: string, patch: Partial<Task> | ((t: Task) => Partial<Task>)) => {
  state = state.map((t) => {
    if (t.id !== id) return t;
    const p = typeof patch === "function" ? patch(t) : patch;
    return { ...t, ...p, updatedAt: iso(new Date()) };
  });
  emit();
};

export const taskActions = {
  toggleDone(id: string) {
    update(id, (t) => ({ done: !t.done }));
  },
  setPriority(id: string, priority: Priority) {
    update(id, { priority });
  },
  setTitle(id: string, title: string) {
    update(id, { title });
  },
  setDescription(id: string, description: string) {
    update(id, { description });
  },
  setDue(id: string, due: string | undefined) {
    update(id, { due });
  },
  addSubtask(id: string, title: string) {
    if (!title.trim()) return;
    update(id, (t) => ({
      subtasks: [...t.subtasks, { id: `s${Date.now()}`, title: title.trim(), done: false }],
    }));
  },
  toggleSubtask(id: string, subId: string) {
    update(id, (t) => ({
      subtasks: t.subtasks.map((s) => (s.id === subId ? { ...s, done: !s.done } : s)),
    }));
  },
  removeSubtask(id: string, subId: string) {
    update(id, (t) => ({ subtasks: t.subtasks.filter((s) => s.id !== subId) }));
  },
  create(title: string, patch: Partial<Task> = {}) {
    if (!title.trim()) return;
    const now = iso(new Date());
    const n = state.length + 42;
    const t: Task = {
      id: `SKR-${n}`,
      title: title.trim(),
      done: false,
      priority: "medium",
      tags: [],
      assignees: [],
      subtasks: [],
      createdAt: now,
      updatedAt: now,
      ...patch,
    };
    state = [t, ...state];
    emit();
  },
};

// ------------- date helpers -------------

export const dateHelpers = {
  iso,
  today: () => iso(new Date()),
  isSameDay: (a?: string, b?: string) => !!a && !!b && a === b,
  isOverdue: (t: Task) => !!t.due && !t.done && t.due < iso(new Date()),
  isToday: (t: Task) => !!t.due && t.due === iso(new Date()),
  formatDue: (isoStr?: string) => {
    if (!isoStr) return "No date";
    const d = new Date(isoStr + "T00:00:00");
    const now = new Date();
    now.setHours(0, 0, 0, 0);
    const diff = Math.round((d.getTime() - now.getTime()) / 86400000);
    if (diff === 0) return "Today";
    if (diff === 1) return "Tomorrow";
    if (diff === -1) return "Yesterday";
    if (diff > 1 && diff < 7) return d.toLocaleDateString(undefined, { weekday: "long" });
    return d.toLocaleDateString(undefined, { weekday: "short", month: "short", day: "numeric" });
  },
};