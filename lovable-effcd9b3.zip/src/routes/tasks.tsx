import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { z } from "zod";
import {
  List, CalendarDays, Plus, ChevronLeft, ChevronRight, Filter, Search,
  CheckCircle2, Circle, AlertCircle,
} from "lucide-react";
import { Shell } from "@/components/skriuw/Shell";
import { TaskDetail } from "@/components/skriuw/TaskDetail";
import {
  useTasks, taskActions, priorityMeta, dateHelpers,
  type Task,
} from "@/lib/skriuw/tasks";

const searchSchema = z.object({
  view: z.enum(["list", "calendar"]).catch("list"),
  filter: z.enum(["inbox", "today", "upcoming", "done", "all"]).catch("inbox"),
  task: z.string().optional(),
  day: z.string().optional(), // yyyy-mm-dd for calendar
});

type TasksSearch = z.infer<typeof searchSchema>;

export const Route = createFileRoute("/tasks")({
  validateSearch: searchSchema,
  head: () => ({
    meta: [
      { title: "Tasks — Skriuw" },
      { name: "description", content: "A calm task inbox and calendar for the Skriuw workspace." },
      { property: "og:title", content: "Tasks — Skriuw" },
      { property: "og:description", content: "A calm task inbox and calendar for the Skriuw workspace." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: TasksPage,
});

function TasksPage() {
  const { view, filter, task: openTaskId, day } = Route.useSearch();
  const navigate = useNavigate({ from: Route.fullPath });

  const setTask = (id: string | undefined) =>
    navigate({ search: (prev: TasksSearch) => ({ ...prev, task: id }) });

  return (
    <Shell>
      <main className="flex-1 flex flex-col min-w-0 bg-editor">
        <TasksToolbar view={view} filter={filter} />
        <div className="flex-1 overflow-y-auto">
          {view === "list" ? (
            <ListView filter={filter} onOpen={(id) => setTask(id)} />
          ) : (
            <CalendarView day={day} onOpen={(id) => setTask(id)} onSelectDay={(d) =>
              navigate({ search: (prev: TasksSearch) => ({ ...prev, day: d }) })
            } />
          )}
        </div>
      </main>
      {openTaskId && (
        <TaskDetail taskId={openTaskId} onClose={() => setTask(undefined)} />
      )}
    </Shell>
  );
}

// ---------------- Toolbar ----------------

function TasksToolbar({ view, filter }: { view: "list" | "calendar"; filter: string }) {
  return (
    <div className="h-11 shrink-0 flex items-center justify-between px-3 border-b border-divider bg-editor">
      <div className="flex items-center gap-3">
        <span className="text-[13px] text-foreground capitalize">{filter === "done" ? "Completed" : filter}</span>
        <div className="h-4 w-px bg-divider" />
        <div className="flex items-center rounded-md border border-divider p-0.5">
          <ViewToggle to="list" current={view} Icon={List} label="List" />
          <ViewToggle to="calendar" current={view} Icon={CalendarDays} label="Calendar" />
        </div>
      </div>
      <div className="flex items-center gap-1">
        <ToolbarIcon Icon={Search} label="Search" />
        <ToolbarIcon Icon={Filter} label="Filter" />
      </div>
    </div>
  );
}

function ViewToggle({
  to, current, Icon, label,
}: { to: "list" | "calendar"; current: string; Icon: typeof List; label: string }) {
  const active = current === to;
  return (
    <Link
      to="/tasks"
      search={(prev: TasksSearch) => ({ ...prev, view: to })}
      className={`flex items-center gap-1.5 px-2 py-1 rounded text-[12px] ${
        active ? "bg-active text-foreground" : "text-dim hover:text-foreground"
      }`}
    >
      <Icon className="h-3.5 w-3.5" /> {label}
    </Link>
  );
}

function ToolbarIcon({ Icon, label }: { Icon: typeof Search; label: string }) {
  return (
    <button aria-label={label} className="h-7 w-7 rounded-md flex items-center justify-center text-dim hover:text-foreground hover:bg-hover">
      <Icon className="h-4 w-4" strokeWidth={1.75} />
    </button>
  );
}

// ---------------- List view ----------------

function ListView({ filter, onOpen }: { filter: string; onOpen: (id: string) => void }) {
  const tasks = useTasks();
  const [quick, setQuick] = useState("");

  const filtered = useMemo(() => {
    const today = dateHelpers.today();
    switch (filter) {
      case "today":
        return tasks.filter((t) => !t.done && (t.due === today || (t.due && t.due < today)));
      case "upcoming":
        return tasks.filter((t) => !t.done && t.due && t.due > today);
      case "done":
        return tasks.filter((t) => t.done);
      case "all":
        return tasks;
      case "inbox":
      default:
        return tasks.filter((t) => !t.done);
    }
  }, [tasks, filter]);

  // Group: Overdue, Today, Tomorrow, This week, Later, No date, Done
  const groups = useMemo(() => groupTasks(filtered), [filtered]);

  return (
    <div className="max-w-[820px] mx-auto px-8 py-8">
      <div className="flex items-baseline justify-between mb-6">
        <h1 className="text-[24px] font-semibold tracking-tight text-foreground capitalize">
          {filter === "done" ? "Completed" : filter}
        </h1>
        <span className="text-[12px] text-dim">{filtered.length} tasks</span>
      </div>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          if (!quick.trim()) return;
          taskActions.create(quick, filter === "today" ? { due: dateHelpers.today() } : {});
          setQuick("");
        }}
        className="flex items-center gap-2 rounded-lg bg-sidebar border border-divider px-3 py-2 mb-6 focus-within:border-foreground/40"
      >
        <Plus className="h-4 w-4 text-dim" />
        <input
          value={quick}
          onChange={(e) => setQuick(e.target.value)}
          placeholder="Add a task and press Enter"
          className="flex-1 bg-transparent outline-none text-[14px] text-foreground placeholder:text-dim"
        />
      </form>

      {filtered.length === 0 ? (
        <EmptyState filter={filter} />
      ) : (
        <div className="space-y-8">
          {groups.map(([label, items]) => (
            <section key={label}>
              <h2 className="text-[11px] uppercase tracking-wider text-dim mb-2">
                {label} <span className="text-dim/70">· {items.length}</span>
              </h2>
              <ul className="rounded-lg border border-divider overflow-hidden divide-y divide-divider">
                {items.map((t) => (
                  <TaskRow key={t.id} task={t} onOpen={() => onOpen(t.id)} />
                ))}
              </ul>
            </section>
          ))}
        </div>
      )}
    </div>
  );
}

function TaskRow({ task, onOpen }: { task: Task; onOpen: () => void }) {
  const pm = priorityMeta[task.priority];
  const overdue = dateHelpers.isOverdue(task);
  const doneCount = task.subtasks.filter((s) => s.done).length;
  return (
    <li>
      <div className="flex items-center gap-3 px-3 py-2.5 hover:bg-hover group cursor-pointer" onClick={onOpen}>
        <button
          onClick={(e) => { e.stopPropagation(); taskActions.toggleDone(task.id); }}
          aria-label={task.done ? "Mark not done" : "Mark done"}
          className={`h-4 w-4 rounded-full flex items-center justify-center shrink-0 ${
            task.done ? "bg-emerald-500 text-black" : "border border-dim hover:border-foreground"
          }`}
        >
          {task.done && <CheckCircle2 className="h-3 w-3" />}
        </button>
        <span className={`flex-1 text-[13px] truncate ${task.done ? "line-through text-dim" : "text-foreground"}`}>
          {task.title}
        </span>
        {task.subtasks.length > 0 && (
          <span className="text-[11px] text-dim tabular-nums">{doneCount}/{task.subtasks.length}</span>
        )}
        {task.tags.slice(0, 2).map((t) => (
          <span key={t} className="hidden md:inline px-1.5 py-0.5 rounded bg-tag text-[11px] font-mono text-foreground/80">
            #{t}
          </span>
        ))}
        <span className={`inline-flex items-center gap-1 text-[11px] ${pm.text}`}>
          <span className={`h-1.5 w-1.5 rounded-full ${pm.dot}`} />
          {pm.label}
        </span>
        {task.due && (
          <span className={`text-[11px] tabular-nums ${overdue ? "text-rose-400" : "text-dim"}`}>
            {overdue && <AlertCircle className="inline h-3 w-3 mr-0.5 -mt-0.5" />}
            {dateHelpers.formatDue(task.due)}
          </span>
        )}
        <span className="text-[10px] text-dim/60 tabular-nums w-14 text-right hidden lg:inline">{task.id}</span>
      </div>
    </li>
  );
}

function EmptyState({ filter }: { filter: string }) {
  const copy = filter === "done"
    ? "Nothing checked off yet."
    : filter === "today"
      ? "Nothing due today — enjoy the calm."
      : filter === "upcoming"
        ? "No upcoming tasks with due dates."
        : "Inbox zero. Add a task above.";
  return (
    <div className="flex flex-col items-center justify-center py-20 text-center">
      <Circle className="h-8 w-8 text-dim mb-3" strokeWidth={1.5} />
      <p className="text-[13px] text-secondary-text">{copy}</p>
    </div>
  );
}

function groupTasks(tasks: Task[]): [string, Task[]][] {
  const today = dateHelpers.today();
  const buckets: Record<string, Task[]> = {
    Overdue: [], Today: [], Tomorrow: [], "This week": [], Later: [], "No date": [], Done: [],
  };
  const tomorrow = (() => {
    const d = new Date();
    d.setDate(d.getDate() + 1);
    return d.toISOString().slice(0, 10);
  })();
  const weekEnd = (() => {
    const d = new Date();
    d.setDate(d.getDate() + 7);
    return d.toISOString().slice(0, 10);
  })();
  for (const t of tasks) {
    if (t.done) { buckets.Done.push(t); continue; }
    if (!t.due) { buckets["No date"].push(t); continue; }
    if (t.due < today) buckets.Overdue.push(t);
    else if (t.due === today) buckets.Today.push(t);
    else if (t.due === tomorrow) buckets.Tomorrow.push(t);
    else if (t.due <= weekEnd) buckets["This week"].push(t);
    else buckets.Later.push(t);
  }
  return Object.entries(buckets).filter(([, v]) => v.length > 0);
}

// ---------------- Calendar view ----------------

function CalendarView({
  day, onOpen, onSelectDay,
}: { day?: string; onOpen: (id: string) => void; onSelectDay: (d: string) => void }) {
  const tasks = useTasks();
  const today = dateHelpers.today();
  const selected = day || today;
  const selectedDate = new Date(selected + "T00:00:00");

  const [cursor, setCursor] = useState(() => {
    const d = new Date(selectedDate);
    d.setDate(1);
    return d;
  });

  const monthStart = new Date(cursor.getFullYear(), cursor.getMonth(), 1);
  const monthName = monthStart.toLocaleDateString(undefined, { month: "long", year: "numeric" });
  // Monday-first
  const startWeekday = (monthStart.getDay() + 6) % 7;
  const daysInMonth = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0).getDate();

  const cells: Array<{ iso: string; day: number } | null> = [];
  for (let i = 0; i < startWeekday; i++) cells.push(null);
  for (let d = 1; d <= daysInMonth; d++) {
    const iso = new Date(cursor.getFullYear(), cursor.getMonth(), d).toISOString().slice(0, 10);
    cells.push({ iso, day: d });
  }
  while (cells.length % 7 !== 0) cells.push(null);

  const byDay = useMemo(() => {
    const m = new Map<string, Task[]>();
    for (const t of tasks) if (t.due) {
      const arr = m.get(t.due) ?? [];
      arr.push(t);
      m.set(t.due, arr);
    }
    return m;
  }, [tasks]);

  const dayTasks = byDay.get(selected) ?? [];

  return (
    <div className="max-w-[1100px] mx-auto px-8 py-8">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-[24px] font-semibold tracking-tight text-foreground">{monthName}</h1>
        <div className="flex items-center gap-1">
          <button
            onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1))}
            className="h-7 w-7 rounded-md flex items-center justify-center text-dim hover:text-foreground hover:bg-hover"
            aria-label="Previous month"
          >
            <ChevronLeft className="h-4 w-4" />
          </button>
          <button
            onClick={() => { const t = new Date(); setCursor(new Date(t.getFullYear(), t.getMonth(), 1)); onSelectDay(dateHelpers.today()); }}
            className="text-[12px] px-2 py-1 rounded-md text-dim hover:text-foreground hover:bg-hover"
          >
            Today
          </button>
          <button
            onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1))}
            className="h-7 w-7 rounded-md flex items-center justify-center text-dim hover:text-foreground hover:bg-hover"
            aria-label="Next month"
          >
            <ChevronRight className="h-4 w-4" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-7 text-[11px] uppercase tracking-wider text-dim mb-2">
        {["Mon","Tue","Wed","Thu","Fri","Sat","Sun"].map((d) => (
          <div key={d} className="px-2 py-1">{d}</div>
        ))}
      </div>

      <div className="grid grid-cols-7 gap-1 rounded-lg overflow-hidden border border-divider bg-divider/40">
        {cells.map((c, i) => {
          if (!c) return <div key={i} className="bg-editor min-h-[96px]" />;
          const items = byDay.get(c.iso) ?? [];
          const isSelected = c.iso === selected;
          const isToday = c.iso === today;
          return (
            <button
              key={i}
              onClick={() => onSelectDay(c.iso)}
              className={`bg-editor min-h-[96px] p-1.5 text-left flex flex-col gap-1 group transition-colors ${
                isSelected ? "ring-1 ring-foreground/60" : "hover:bg-hover/60"
              }`}
            >
              <div className="flex items-center justify-between">
                <span className={`inline-flex h-5 min-w-[20px] items-center justify-center rounded-full text-[11px] ${
                  isToday ? "bg-foreground text-background" : "text-secondary-text"
                }`}>{c.day}</span>
                {items.length > 0 && (
                  <span className="text-[10px] text-dim tabular-nums">{items.length}</span>
                )}
              </div>
              <div className="flex-1 space-y-0.5 overflow-hidden">
                {items.slice(0, 3).map((t) => {
                  const pm = priorityMeta[t.priority];
                  return (
                    <div
                      key={t.id}
                      className={`flex items-center gap-1 text-[11px] truncate px-1 py-0.5 rounded bg-hover/60 ${
                        t.done ? "line-through text-dim" : "text-foreground/90"
                      }`}
                    >
                      <span className={`h-1.5 w-1.5 rounded-full shrink-0 ${pm.dot}`} />
                      <span className="truncate">{t.title}</span>
                    </div>
                  );
                })}
                {items.length > 3 && (
                  <div className="text-[10px] text-dim">+{items.length - 3} more</div>
                )}
              </div>
            </button>
          );
        })}
      </div>

      {/* Day panel */}
      <section className="mt-8">
        <h2 className="text-[13px] text-foreground font-medium mb-3">
          {selectedDate.toLocaleDateString(undefined, { weekday: "long", month: "long", day: "numeric" })}
          <span className="ml-2 text-dim text-[12px]">· {dayTasks.length} tasks</span>
        </h2>
        {dayTasks.length === 0 ? (
          <p className="text-[13px] text-dim">Nothing scheduled.</p>
        ) : (
          <ul className="rounded-lg border border-divider overflow-hidden divide-y divide-divider">
            {dayTasks.map((t) => (
              <TaskRow key={t.id} task={t} onOpen={() => onOpen(t.id)} />
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}