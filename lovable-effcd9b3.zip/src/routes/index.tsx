import { createFileRoute } from "@tanstack/react-router";
import { Inspector } from "@/components/skriuw/Inspector";
import { Toolbar, PropsBar } from "@/components/skriuw/Toolbar";
import { Editor } from "@/components/skriuw/Editor";
import { Shell } from "@/components/skriuw/Shell";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Skriuw — Notes workspace" },
      { name: "description", content: "A calm block-based notes workspace with linked knowledge, tags, and journaling." },
      { property: "og:title", content: "Skriuw — Notes workspace" },
      { property: "og:description", content: "A calm block-based notes workspace with linked knowledge, tags, and journaling." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: App,
});

function App() {
  return (
    <Shell>
      <main className="flex-1 flex flex-col min-w-0 bg-editor">
        <Toolbar />
        <div className="flex-1 overflow-y-auto">
          <div className="max-w-[720px] mx-auto px-10 py-10">
            <PropsBar />
            <Editor />
          </div>
        </div>
      </main>
      <Inspector />
    </Shell>
  );
}
