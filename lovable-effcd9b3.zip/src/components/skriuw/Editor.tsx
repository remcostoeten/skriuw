import { useEffect, useRef, useState } from "react";
import { useCreateBlockNote } from "@blocknote/react";
import { BlockNoteView } from "@blocknote/mantine";
import "@blocknote/core/style.css";
import "@blocknote/mantine/style.css";
import type { PartialBlock } from "@blocknote/core";
import { EphemeralTaskDetail } from "./TaskDetail";
import type { Task } from "@/lib/skriuw/tasks";

const initialContent: PartialBlock[] = [
  { type: "heading", props: { level: 1 }, content: "Welcome to Skriuw" },
  {
    type: "paragraph",
    content: [
      { type: "text", text: "Skriuw is a notes workspace that stays out of your way — scratchpad, journal, or linked knowledge base. This note is tagged ", styles: {} },
      { type: "text", text: "#getting-started", styles: { code: true } },
      { type: "text", text: ". The companion note ", styles: {} },
      { type: "text", text: "Skriuw handbook", styles: { underline: true } },
      { type: "text", text: " goes deeper.", styles: {} },
    ],
  },
  { type: "heading", props: { level: 2 }, content: "Try this in the next two minutes" },
  { type: "paragraph", content: [{ type: "text", text: "Tip — click the ", styles: {} }, { type: "text", text: "↗", styles: { code: true } }, { type: "text", text: " that appears when you hover a task to open its full view.", styles: { italic: true } }] },
  { type: "checkListItem", content: "Press I and open the inspector on this note" },
  { type: "checkListItem", content: "Click Skriuw handbook below, then check Outgoing links and Backlinks" },
  { type: "checkListItem", content: [{ type: "text", text: "Click ", styles: {} }, { type: "text", text: "#getting-started", styles: { code: true } }, { type: "text", text: " in the inspector to filter related notes", styles: {} }] },
  { type: "checkListItem", content: [{ type: "text", text: "Type ", styles: {} }, { type: "text", text: "/", styles: { code: true } }, { type: "text", text: " on a blank line to insert blocks", styles: {} }] },
  { type: "heading", props: { level: 2 }, content: "Block editor" },
  { type: "paragraph", content: "Each paragraph is a block. Hover the handle to reorder. The slash menu gives you headings, lists, quotes, code, tables, and more." },
  { type: "bulletListItem", content: [{ type: "text", text: "Type markdown inline — ", styles: {} }, { type: "text", text: "##", styles: { code: true } }, { type: "text", text: " becomes a heading, ", styles: {} }, { type: "text", text: "[ ]", styles: { code: true } }, { type: "text", text: " becomes a checkbox", styles: {} }] },
  { type: "bulletListItem", content: "Switch to raw MDX in the toolbar when you want source view" },
  { type: "heading", props: { level: 2 }, content: "Link notes" },
  { type: "paragraph", content: [{ type: "text", text: "Type ", styles: {} }, { type: "text", text: "[[ Note title ]]", styles: { code: true } }, { type: "text", text: " to link another note. Unresolved links can be clicked to create the target note.", styles: {} }] },
];

function ClientEditor({ onOpenTask }: { onOpenTask: (t: Task) => void }) {
  const editor = useCreateBlockNote({ initialContent });
  const wrapRef = useRef<HTMLDivElement>(null);
  const [hover, setHover] = useState<{ top: number; block: HTMLElement } | null>(null);

  useEffect(() => {
    const root = wrapRef.current;
    if (!root) return;
    const onMove = (e: MouseEvent) => {
      const target = e.target as HTMLElement | null;
      const block = target?.closest?.('[data-content-type="checkListItem"]') as HTMLElement | null;
      if (!block) { setHover(null); return; }
      const rBlock = block.getBoundingClientRect();
      const rWrap = root.getBoundingClientRect();
      setHover({ top: rBlock.top - rWrap.top + rBlock.height / 2, block });
    };
    const onLeave = () => setHover(null);
    root.addEventListener("mousemove", onMove);
    root.addEventListener("mouseleave", onLeave);
    return () => {
      root.removeEventListener("mousemove", onMove);
      root.removeEventListener("mouseleave", onLeave);
    };
  }, []);

  const openHovered = () => {
    if (!hover) return;
    const block = hover.block;
    const text = (block.querySelector(".bn-inline-content") as HTMLElement)?.innerText?.trim() || "Task";
    const done = !!block.querySelector('input[type="checkbox"]:checked');
    const now = new Date().toISOString().slice(0, 10);
    onOpenTask({
      id: block.getAttribute("data-id") || Math.random().toString(36).slice(2),
      title: text,
      done,
      priority: "medium",
      tags: ["getting-started"],
      assignees: ["S"],
      subtasks: [],
      createdAt: now,
      updatedAt: now,
    });
  };

  return (
    <div ref={wrapRef} className="relative">
      <BlockNoteView editor={editor} theme="dark" className="bn-skriuw" />
      {hover && (
        <button
          onMouseDown={(e) => { e.preventDefault(); openHovered(); }}
          className="task-open-btn"
          style={{ top: hover.top }}
          aria-label="Open task"
        >
          <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M7 17L17 7" />
            <path d="M8 7h9v9" />
          </svg>
          <span>Open</span>
        </button>
      )}
    </div>
  );
}

export function Editor() {
  const [mounted, setMounted] = useState(false);
  const [task, setTask] = useState<Task | null>(null);
  useEffect(() => setMounted(true), []);
  if (!mounted) return <div className="min-h-[400px]" />;
  return (
    <>
      <ClientEditor onOpenTask={setTask} />
      {task && <EphemeralTaskDetail initial={task} onClose={() => setTask(null)} />}
    </>
  );
}
