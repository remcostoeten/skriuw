import { IconRail } from "./IconRail";
import { Sidebar } from "./Sidebar";

export function Shell({ children }: { children: React.ReactNode }) {
  return (
    <div className="dark h-dvh w-dvw flex flex-col overflow-hidden bg-background text-foreground">
      <div className="h-9 shrink-0 flex items-center justify-center gap-2 text-[12px] text-secondary-text border-b border-divider bg-rail">
        <span className="text-amber-300">✦</span>
        <span>You're exploring a demo workspace — changes stay in this browser.</span>
        <button className="text-foreground underline underline-offset-2 hover:text-foreground/80">
          Create an account to save your work
        </button>
      </div>
      <div className="flex-1 flex min-h-0">
        <IconRail />
        <Sidebar />
        {children}
      </div>
    </div>
  );
}