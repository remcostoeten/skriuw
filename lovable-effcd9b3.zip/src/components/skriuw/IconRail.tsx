import { Link, useRouterState } from "@tanstack/react-router";
import {
  FileText, BookOpen, GitBranch, Hash, Users, Activity, Search, LayoutGrid,
  Settings, Bell, Trash2, CheckSquare,
} from "lucide-react";

export function IconRail() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  return (
    <div className="flex flex-col items-center w-12 bg-rail border-r border-divider py-2 gap-0.5 shrink-0">
      <div className="h-8 w-8 rounded-md bg-active flex items-center justify-center mb-2">
        <div className="h-4 w-4 rounded-sm bg-foreground/80" style={{ clipPath: "polygon(0 0, 60% 0, 100% 40%, 100% 100%, 40% 100%, 0 60%)" }} />
      </div>
      <div className="flex flex-col gap-0.5 items-center px-1">
        <RailLink to="/" Icon={FileText} active={pathname === "/"} label="Notes" />
        <RailLink to="/tasks" Icon={CheckSquare} active={pathname.startsWith("/tasks")} label="Tasks" />
        <RailBtn Icon={BookOpen} label="Handbook" />
        <RailBtn Icon={GitBranch} label="Links" />
        <RailBtn Icon={Search} label="Search" />
        <RailBtn Icon={LayoutGrid} label="Widgets" />
      </div>
      <div className="mt-2 pt-2 border-t border-divider w-8 flex flex-col gap-0.5 items-center">
        <RailBtn Icon={Hash} label="Tags" />
        <RailBtn Icon={Users} label="People" />
        <RailBtn Icon={Activity} label="Activity" />
      </div>
      <div className="flex-1" />
      <div className="flex flex-col gap-0.5 items-center">
        <div className="h-6 w-6 rounded-full bg-emerald-500/90 flex items-center justify-center text-[10px] text-black font-medium">S</div>
        <RailBtn Icon={Trash2} label="Trash" />
        <RailBtn Icon={Settings} label="Settings" />
        <RailBtn Icon={Bell} label="Notifications" />
      </div>
    </div>
  );
}

function RailLink({ to, Icon, active, label }: { to: string; Icon: typeof FileText; active?: boolean; label: string }) {
  return (
    <Link
      to={to}
      aria-label={label}
      className={`h-8 w-8 rounded-md flex items-center justify-center transition-colors ${active ? "bg-active text-foreground" : "text-dim hover:text-foreground hover:bg-hover"}`}
    >
      <Icon className="h-[16px] w-[16px]" strokeWidth={1.75} />
    </Link>
  );
}

function RailBtn({ Icon, label }: { Icon: typeof FileText; label: string }) {
  return (
    <button aria-label={label} className="h-8 w-8 rounded-md flex items-center justify-center text-dim hover:text-foreground hover:bg-hover transition-colors">
      <Icon className="h-[16px] w-[16px]" strokeWidth={1.75} />
    </button>
  );
}
