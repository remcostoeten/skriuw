import { ChevronRight, ChevronDown, Folder, FileText, ChevronLeft, Inbox, Sun, CalendarDays, CheckCircle2 } from "lucide-react";
import { useState } from "react";
import { Link, useRouterState, useSearch } from "@tanstack/react-router";
import { useTasks, dateHelpers } from "@/lib/skriuw/tasks";

type NoteItem = { title: string; active?: boolean };
type FolderT = { name: string; count: number; open?: boolean; notes?: NoteItem[]; children?: FolderT[] };

const topNotes: NoteItem[] = [
  { title: "Welcome to Skriuw", active: true },
  { title: "Skriuw handbook" },
];

const tree: FolderT[] = [
  {
    name: "Guides",
    count: 2,
    open: true,
    children: [
      { name: "Workflows", count: 1, open: false, notes: [{ title: "From idea to published note" }] },
    ],
    notes: [{ title: "From idea to published note" }],
  },
];

const monthDays = Array.from({ length: 42 }, (_, i) => {
  // July 2026 starts on Wednesday (index 2 for MO-start = day 3rd position)
  const start = 2; // MO,TU,WE -> July 1 on WE
  const d = i - start + 1;
  if (d < 1 || d > 31) return null;
  return d;
});

export function Sidebar() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  const onTasks = pathname.startsWith("/tasks");
  const tasks = useTasks();
  const counts = {
    inbox: tasks.filter((t) => !t.done).length,
    today: tasks.filter((t) => dateHelpers.isToday(t) && !t.done).length,
    upcoming: tasks.filter((t) => !!t.due && t.due > dateHelpers.today() && !t.done).length,
    done: tasks.filter((t) => t.done).length,
  };
  const activeFilter = onTasks
    ? ((useSearchSafe() as { filter?: string })?.filter ?? "inbox")
    : null;
  return (
    <aside className="w-[248px] shrink-0 bg-sidebar border-r border-divider flex flex-col text-sm">
      <div className="flex-1 overflow-y-auto pt-2">
        <div className="px-2 space-y-0.5">
          {topNotes.map((n) => (
            <Link
              key={n.title}
              to="/"
              className={`w-full flex items-center gap-2 px-2 py-1.5 rounded text-[13px] truncate ${
                !onTasks && n.active ? "bg-active text-foreground" : "text-secondary-text hover:bg-hover"
              }`}
            >
              <FileText className="h-3.5 w-3.5 shrink-0 text-dim" strokeWidth={1.5} />
              <span className="truncate">{n.title}</span>
            </Link>
          ))}
        </div>
        <div className="px-2 mt-1">
          {tree.map((f) => <FolderRow key={f.name} folder={f} depth={0} />)}
        </div>

        <div className="mt-3 border-t border-divider pt-2 px-2">
          <div className="px-2 pb-1 flex items-center gap-1 text-[10px] font-medium tracking-wider text-dim uppercase">
            <ChevronDown className="h-3 w-3" /> Tasks
          </div>
          <div className="space-y-0.5">
            <TaskNav to="/tasks" search={{ filter: "inbox" }} Icon={Inbox} label="Inbox" count={counts.inbox} active={activeFilter === "inbox"} />
            <TaskNav to="/tasks" search={{ filter: "today" }} Icon={Sun} label="Today" count={counts.today} active={activeFilter === "today"} />
            <TaskNav to="/tasks" search={{ filter: "upcoming", view: "calendar" }} Icon={CalendarDays} label="Upcoming" count={counts.upcoming} active={activeFilter === "upcoming"} />
            <TaskNav to="/tasks" search={{ filter: "done" }} Icon={CheckCircle2} label="Completed" count={counts.done} active={activeFilter === "done"} muted />
          </div>
        </div>
      </div>

      <Section title="Journal">
        <div className="px-3 pb-3">
          <div className="flex items-center justify-between text-secondary-text mb-2">
            <button className="h-5 w-5 hover:bg-hover rounded flex items-center justify-center"><ChevronLeft className="h-3 w-3" /></button>
            <span className="text-[11px] tracking-wide text-foreground/80">July 2026</span>
            <button className="h-5 w-5 hover:bg-hover rounded flex items-center justify-center"><ChevronRight className="h-3 w-3" /></button>
          </div>
          <div className="grid grid-cols-7 gap-y-1 text-center text-[10px] text-dim mb-1">
            {["MO","TU","WE","TH","FR","SA","SU"].map(d => <div key={d}>{d}</div>)}
          </div>
          <div className="grid grid-cols-7 gap-y-0.5 text-center text-[11px]">
            {monthDays.map((d, i) => (
              <div key={i} className="relative py-1">
                {d === 11 ? (
                  <span className="inline-flex h-5 w-5 items-center justify-center rounded-full border border-foreground/70 text-foreground">{d}</span>
                ) : (
                  <span className={d ? "text-secondary-text hover:text-foreground cursor-pointer" : "text-dim/30"}>{d ?? ""}</span>
                )}
              </div>
            ))}
          </div>
        </div>
      </Section>
    </aside>
  );
}

// Safe wrapper: useSearch is scoped to a route match, but Sidebar renders in
// every route. Read raw location.search from router state instead.
function useSearchSafe() {
  return useRouterState({ select: (s) => s.location.search });
}

function TaskNav({
  to, search, Icon, label, count, active, muted,
}: {
  to: string;
  search: Record<string, string>;
  Icon: typeof FileText;
  label: string;
  count: number;
  active?: boolean;
  muted?: boolean;
}) {
  return (
    <Link
      to={to}
      search={search as never}
      className={`w-full flex items-center gap-2 px-2 py-1.5 rounded text-[13px] ${
        active ? "bg-active text-foreground" : "text-secondary-text hover:bg-hover"
      }`}
    >
      <Icon className="h-3.5 w-3.5 shrink-0 text-dim" strokeWidth={1.5} />
      <span className="flex-1 truncate">{label}</span>
      {count > 0 && (
        <span className={`text-[11px] ${muted ? "text-dim" : "text-dim"}`}>{count}</span>
      )}
    </Link>
  );
}

function FolderRow({ folder, depth }: { folder: FolderT; depth: number }) {
  const [open, setOpen] = useState(!!folder.open);
  return (
    <div className="mb-0.5">
      <button
        onClick={() => setOpen(!open)}
        className="w-full flex items-center gap-1.5 px-1.5 py-1 rounded hover:bg-hover text-secondary-text"
        style={{ paddingLeft: 6 + depth * 12 }}
      >
        {open ? <ChevronDown className="h-3 w-3 shrink-0 text-dim" /> : <ChevronRight className="h-3 w-3 shrink-0 text-dim" />}
        <Folder className="h-3.5 w-3.5 shrink-0 text-dim" strokeWidth={1.6} />
        <span className="text-[13px] flex-1 text-left text-foreground/90">{folder.name}</span>
        <span className="text-[11px] text-dim">{folder.count}</span>
      </button>
      {open && (
        <div>
          {folder.children?.map((c) => <FolderRow key={c.name} folder={c} depth={depth + 1} />)}
          {folder.children?.flatMap((c) => c.notes ?? []).map((n) => (
            <button
              key={n.title}
              className="w-full flex items-center gap-2 py-1 text-[13px] truncate text-secondary-text hover:bg-hover rounded"
              style={{ paddingLeft: 6 + (depth + 2) * 12 }}
            >
              <FileText className="h-3.5 w-3.5 shrink-0 text-dim" strokeWidth={1.5} />
              <span className="truncate">{n.title}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="border-t border-divider">
      <div className="px-3 pt-2 pb-1 flex items-center gap-1 text-[10px] font-medium tracking-wider text-dim uppercase">
        <ChevronDown className="h-3 w-3" />
        {title}
        <span className="ml-auto text-dim">0</span>
      </div>
      {children}
    </div>
  );
}
