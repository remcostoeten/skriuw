import { ChevronLeft, ChevronRight, PanelLeft, PanelRight, Sparkles, MoreHorizontal, Table2, Plus } from "lucide-react";

export function Toolbar() {
  return (
    <div className="h-11 shrink-0 flex items-center justify-between px-3 border-b border-divider bg-editor">
      <div className="flex items-center gap-1">
        <IconBtn Icon={PanelLeft} />
        <IconBtn Icon={PanelRight} />
        <div className="mx-1 h-4 w-px bg-divider" />
        <IconBtn Icon={ChevronLeft} />
        <IconBtn Icon={ChevronRight} />
        <span className="ml-2 text-[13px] text-foreground">Welcome to Skriuw</span>
      </div>
      <div className="flex items-center gap-1">
        <IconBtn Icon={PanelRight} />
        <IconBtn Icon={Sparkles} />
        <IconBtn Icon={Table2} />
        <IconBtn Icon={MoreHorizontal} />
      </div>
    </div>
  );
}

export function PropsBar() {
  return (
    <div className="flex items-center justify-between text-[11px] uppercase tracking-wider text-dim px-1 pb-3">
      <button className="flex items-center gap-1 hover:text-foreground"><ChevronRight className="h-3 w-3 rotate-90" /> Properties</button>
      <div className="flex items-center gap-3">
        <button className="flex items-center gap-1 hover:text-foreground"><Plus className="h-3 w-3" /> Add property</button>
        <button className="flex items-center gap-1 hover:text-foreground"><Table2 className="h-3 w-3" /> Templates</button>
      </div>
    </div>
  );
}

function IconBtn({ Icon }: { Icon: typeof PanelLeft }) {
  return (
    <button className="h-7 w-7 rounded-md flex items-center justify-center text-dim hover:text-foreground hover:bg-hover">
      <Icon className="h-4 w-4" strokeWidth={1.75} />
    </button>
  );
}
