import { ChevronDown, ChevronRight, Link2, Hash, Users, History, FileText, ArrowUpRight, Plus, Info, Image as ImageIcon, Smile } from "lucide-react";

const outline = ["Welcome to Skriuw", "Try this in the next two minutes", "Block editor", "Link notes", "Tags", "Handy shortcuts"];
const tags = ["getting-started", "tag"];
const outgoing = ["Skriuw handbook", "Note title", "From idea to published note"];

export function Inspector() {
  return (
    <aside className="w-[300px] shrink-0 bg-inspector border-l border-divider text-[13px] overflow-y-auto">
      <Section icon={<FileText className="h-3.5 w-3.5" />} title="Outline" count={6} defaultOpen>
        <div className="pl-6 pr-3 pb-1 space-y-0.5">
          {outline.map((o, i) => (
            <button key={o} className={`block w-full text-left py-0.5 text-[13px] ${i === 0 ? "text-foreground border-l-2 border-foreground pl-2 -ml-2" : "text-secondary-text hover:text-foreground pl-2 -ml-2 border-l-2 border-transparent"}`}>
              {o}
            </button>
          ))}
        </div>
      </Section>

      <PropRow label="Page icon" trailing={<Smile className="h-3.5 w-3.5 text-dim" />} />
      <PropRow label="Page cover" trailing={<ImageIcon className="h-3.5 w-3.5 text-dim" />} />

      <Section icon={<Hash className="h-3.5 w-3.5" />} title="Tags" count={2} defaultOpen>
        <div className="pl-6 pr-3 pb-2 flex flex-wrap gap-1.5">
          {tags.map(t => (
            <span key={t} className="text-[12px] px-1.5 py-0.5 rounded bg-tag text-foreground/90">#{t}</span>
          ))}
        </div>
      </Section>

      <Section icon={<Users className="h-3.5 w-3.5" />} title="People" count={0} defaultOpen>
        <div className="pl-6 pr-3 pb-2 text-[12px] text-dim leading-relaxed">
          No people mentioned yet. Type $ in the editor.
        </div>
      </Section>

      <Section icon={<Link2 className="h-3.5 w-3.5" />} title="Links" count={3} defaultOpen>
        <div className="pl-6 pr-3 pb-1">
          <div className="flex items-center justify-between text-[11px] text-dim uppercase tracking-wider py-1">
            <div className="flex items-center gap-1"><ArrowUpRight className="h-3 w-3" /> Outgoing</div>
            <span>3</span>
          </div>
          <div className="space-y-0.5 pb-2">
            {outgoing.map((l, i) => (
              <button key={l} className="w-full flex items-center gap-2 py-1 px-1.5 -mx-1.5 rounded hover:bg-hover text-secondary-text hover:text-foreground group">
                <FileText className="h-3.5 w-3.5 text-dim" strokeWidth={1.5} />
                <span className="flex-1 text-left truncate">{l}</span>
                {i === 1 && <span className="text-[10px] text-dim uppercase tracking-wider mr-1">Create</span>}
                {i === 1 && <Plus className="h-3 w-3 text-dim" />}
              </button>
            ))}
          </div>
        </div>
      </Section>

      <Section icon={<Users className="h-3.5 w-3.5" />} title="Collaborators" />
      <Section icon={<History className="h-3.5 w-3.5" />} title="History" count={1} defaultOpen>
        <div className="pl-6 pr-3 pb-2 flex items-start gap-2">
          <span className="mt-1.5 h-1.5 w-1.5 rounded-full bg-emerald-400 shrink-0" />
          <div className="min-w-0">
            <div className="text-foreground text-[13px]">Now</div>
            <div className="text-dim text-[12px] truncate">Welcome to Skriuw</div>
          </div>
        </div>
      </Section>

      <Section icon={<Info className="h-3.5 w-3.5" />} title="Details" count={9} defaultOpen>
        <div className="pl-6 pr-3 pb-3 space-y-1.5 text-[12px]">
          <Detail k="Created" v="27 days ago" />
          <Detail k="Modified" v="27 days ago" />
          <Detail k="File Size" v="1.4 KB" />
          <Detail k="Characters" v="1,436" />
          <Detail k="Words" v="257" />
          <Detail k="Read Time" v="2m" />
          <div className="flex justify-between items-center">
            <span className="text-dim">Format</span>
            <div className="flex gap-2">
              <span className="text-foreground">Block</span>
              <span className="text-dim">Raw</span>
            </div>
          </div>
          <Detail k="Share link" v={<span className="text-foreground">Create link</span>} />
          <Detail k="Send note" v={<span className="text-foreground">Send note</span>} />
        </div>
      </Section>
    </aside>
  );
}

function PropRow({ label, trailing }: { label: string; trailing?: React.ReactNode }) {
  return (
    <div className="flex items-center justify-between px-3 py-2 border-b border-divider">
      <span className="text-[11px] uppercase tracking-wider text-dim">{label}</span>
      {trailing}
    </div>
  );
}

function Section({ icon, title, count, defaultOpen, children }: { icon: React.ReactNode; title: string; count?: number; defaultOpen?: boolean; children?: React.ReactNode }) {
  return (
    <div className="border-b border-divider">
      <button className="w-full flex items-center gap-2 px-3 py-2 text-[11px] uppercase tracking-wider text-dim hover:text-foreground">
        {defaultOpen ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
        {icon}
        <span className="flex-1 text-left">{title}</span>
        {count !== undefined && <span className="text-dim">({count})</span>}
      </button>
      {defaultOpen && children}
    </div>
  );
}

function Detail({ k, v }: { k: string; v: React.ReactNode }) {
  return (
    <div className="flex justify-between items-center">
      <span className="text-dim">{k}</span>
      <span className="text-foreground">{v}</span>
    </div>
  );
}
