import { useEffect, useState } from "react";
import {
  X, CheckCircle2, Circle, Clock, Flag, User, Calendar, GitBranch,
  Paperclip, MessageSquare, Link2, MoreHorizontal, ChevronDown, Plus,
  AtSign, Hash, Trash2,
} from "lucide-react";
import {
  type Task, type Priority, type Subtask,
  priorityMeta, taskActions, useTask, dateHelpers,
} from "@/lib/skriuw/tasks";

// Re-export so legacy imports keep working.
export type { Task } from "@/lib/skriuw/tasks";

type Handlers = {
  onToggleDone: () => void;
  onSetPriority: (p: Priority) => void;
  onAddSubtask: (title: string) => void;
  onToggleSubtask: (subId: string) => void;
  onRemoveSubtask: (subId: string) => void;
};

/**
 * Drawer connected to the shared task store — pass a task id.
 */
export function TaskDetail({ taskId, onClose }: { taskId: string; onClose: () => void }) {
  const task = useTask(taskId);
  useEffect(() => {
    if (!task) onClose();
  }, [task, onClose]);
  if (!task) return null;
  return (
    <TaskDetailView
      task={task}
      onClose={onClose}
      onToggleDone={() => taskActions.toggleDone(task.id)}
      onSetPriority={(p) => taskActions.setPriority(task.id, p)}
      onAddSubtask={(title) => taskActions.addSubtask(task.id, title)}
      onToggleSubtask={(subId) => taskActions.toggleSubtask(task.id, subId)}
      onRemoveSubtask={(subId) => taskActions.removeSubtask(task.id, subId)}
    />
  );
}

/**
 * Ephemeral drawer — takes a Task object and local handlers.
 * Used by the block editor to preview a checklist item as a task.
 */
export function EphemeralTaskDetail({
  initial, onClose,
}: { initial: Task; onClose: () => void }) {
  const [task, setTask] = useState<Task>(initial);
  return (
    <TaskDetailView
      task={task}
      onClose={onClose}
      onToggleDone={() => setTask((t) => ({ ...t, done: !t.done }))}
      onSetPriority={(priority) => setTask((t) => ({ ...t, priority }))}
      onAddSubtask={(title) =>
        setTask((t) => ({
          ...t,
          subtasks: [...t.subtasks, { id: `s${Date.now()}`, title, done: false }],
        }))
      }
      onToggleSubtask={(subId) =>
        setTask((t) => ({
          ...t,
          subtasks: t.subtasks.map((s) => (s.id === subId ? { ...s, done: !s.done } : s)),
        }))
      }
      onRemoveSubtask={(subId) =>
        setTask((t) => ({ ...t, subtasks: t.subtasks.filter((s) => s.id !== subId) }))
      }
    />
  );
}

function TaskDetailView({
  task, onClose, onToggleDone, onSetPriority, onAddSubtask, onToggleSubtask, onRemoveSubtask,
}: { task: Task; onClose: () => void } & Handlers) {
  const [newSub, setNewSub] = useState("");
  const [priorityOpen, setPriorityOpen] = useState(false);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const done = task.subtasks.filter((s) => s.done).length;
  const pm = priorityMeta[task.priority];

  return (
    <div className="fixed inset-0 z-50 flex justify-end" role="dialog" aria-modal>
      <button
        aria-label="Close task"
        onClick={onClose}
        className="absolute inset-0 bg-black/50 backdrop-blur-sm"
      />
      <aside className="relative w-[560px] max-w-[92vw] h-full bg-editor border-l border-divider flex flex-col animate-in slide-in-from-right duration-200">
        {/* Header */}
        <div className="h-11 shrink-0 flex items-center justify-between px-3 border-b border-divider">
          <div className="flex items-center gap-2 text-[12px] text-dim">
            <button className="hover:text-foreground flex items-center gap-1">
              <Hash className="h-3.5 w-3.5" /> {task.id}
            </button>
            {task.project && (
              <>
                <span>·</span>
                <button className="hover:text-foreground">{task.project}</button>
              </>
            )}
          </div>
          <div className="flex items-center gap-1">
            <IconBtn Icon={Link2} label="Copy link" />
            <IconBtn Icon={MoreHorizontal} label="More" />
            <button
              onClick={onClose}
              className="h-7 w-7 rounded-md flex items-center justify-center text-dim hover:text-foreground hover:bg-hover"
              aria-label="Close"
            >
              <X className="h-4 w-4" />
            </button>
          </div>
        </div>

        {/* Body */}
        <div className="flex-1 overflow-y-auto">
          <div className="px-8 pt-8 pb-6">
            <div className="flex items-start gap-3">
              <button
                onClick={onToggleDone}
                aria-label={task.done ? "Mark not done" : "Mark done"}
                className={`mt-1.5 h-5 w-5 rounded-full flex items-center justify-center transition-colors ${
                  task.done ? "bg-emerald-500 text-black" : "border border-dim hover:border-foreground"
                }`}
              >
                {task.done && <CheckCircle2 className="h-4 w-4" />}
              </button>
              <div className="flex-1">
                <h1 className={`text-[26px] font-semibold tracking-tight leading-snug text-foreground ${task.done ? "line-through text-dim" : ""}`}>
                  {task.title}
                </h1>
                <div className="mt-1 flex items-center gap-2 text-[12px] text-dim">
                  <span className={task.done ? "text-emerald-400" : "text-amber-400"}>
                    {task.done ? "Done" : "In progress"}
                  </span>
                  <span>·</span>
                  <span>Updated {dateHelpers.formatDue(task.updatedAt).toLowerCase()}</span>
                </div>
              </div>
            </div>

            {/* Property grid */}
            <div className="mt-6 grid grid-cols-[110px_1fr] gap-y-2 text-[13px]">
              <PropLabel Icon={Circle} text="Status" />
              <PropValue>
                <button
                  onClick={onToggleDone}
                  className="inline-flex items-center gap-2 px-2 py-1 rounded-md hover:bg-hover text-foreground"
                >
                  <span className={`h-2 w-2 rounded-full ${task.done ? "bg-emerald-400" : "bg-amber-400"}`} />
                  {task.done ? "Done" : "In progress"}
                  <ChevronDown className="h-3 w-3 text-dim" />
                </button>
              </PropValue>

              <PropLabel Icon={Flag} text="Priority" />
              <PropValue>
                <div className="relative">
                  <button
                    onClick={() => setPriorityOpen((o) => !o)}
                    className="inline-flex items-center gap-2 px-2 py-1 rounded-md hover:bg-hover text-foreground"
                  >
                    <span className={`h-2 w-2 rounded-full ${pm.dot}`} />
                    {pm.label}
                    <ChevronDown className="h-3 w-3 text-dim" />
                  </button>
                  {priorityOpen && (
                    <div className="absolute z-10 mt-1 w-40 rounded-md bg-sidebar border border-divider shadow-lg py-1">
                      {(Object.keys(priorityMeta) as Priority[]).map((p) => (
                        <button
                          key={p}
                          onClick={() => { onSetPriority(p); setPriorityOpen(false); }}
                          className="w-full flex items-center gap-2 px-2 py-1.5 text-[13px] hover:bg-hover text-foreground"
                        >
                          <span className={`h-2 w-2 rounded-full ${priorityMeta[p].dot}`} />
                          {priorityMeta[p].label}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </PropValue>

              <PropLabel Icon={Calendar} text="Due" />
              <PropValue>
                <button className="inline-flex items-center gap-2 px-2 py-1 rounded-md hover:bg-hover text-foreground">
                  {dateHelpers.formatDue(task.due)}
                </button>
              </PropValue>

              <PropLabel Icon={User} text="Assignee" />
              <PropValue>
                <div className="flex items-center gap-1.5">
                  {task.assignees.map((a, i) => (
                    <div
                      key={i}
                      className={`h-6 w-6 rounded-full text-black text-[11px] font-medium flex items-center justify-center ${
                        i % 2 === 0 ? "bg-emerald-500/90" : "bg-sky-500/90"
                      }`}
                    >
                      {a}
                    </div>
                  ))}
                  <button className="h-6 w-6 rounded-full border border-dashed border-divider text-dim hover:text-foreground hover:border-foreground flex items-center justify-center">
                    <Plus className="h-3 w-3" />
                  </button>
                </div>
              </PropValue>

              {task.project && (
                <>
                  <PropLabel Icon={GitBranch} text="Project" />
                  <PropValue>
                    <span className="inline-flex items-center gap-2 px-2 py-1 rounded-md bg-tag text-foreground">
                      <span className="h-1.5 w-1.5 rounded-full bg-accent-blue" />
                      {task.project}
                    </span>
                  </PropValue>
                </>
              )}

              <PropLabel Icon={Hash} text="Tags" />
              <PropValue>
                <div className="flex flex-wrap gap-1.5">
                  {task.tags.map((t) => <Tag key={t}>#{t}</Tag>)}
                  <button className="text-[12px] text-dim hover:text-foreground px-1.5 py-0.5">+ Add</button>
                </div>
              </PropValue>

              <PropLabel Icon={Clock} text="Created" />
              <PropValue><span className="text-secondary-text">{dateHelpers.formatDue(task.createdAt)}</span></PropValue>
            </div>

            {/* Description */}
            {task.description && (
              <section className="mt-8">
                <h2 className="text-[11px] uppercase tracking-wider text-dim mb-2">Description</h2>
                <p className="text-[14px] leading-relaxed text-secondary-text">{task.description}</p>
              </section>
            )}

            {/* Subtasks */}
            <section className="mt-8">
              <div className="flex items-center justify-between mb-2">
                <h2 className="text-[11px] uppercase tracking-wider text-dim">
                  Subtasks {task.subtasks.length > 0 && (
                    <span className="text-dim/70">· {done}/{task.subtasks.length}</span>
                  )}
                </h2>
              </div>
              {task.subtasks.length > 0 && (
                <div className="h-1 w-full bg-hover rounded-full overflow-hidden mb-3">
                  <div className="h-full bg-emerald-500/80 transition-[width]" style={{ width: `${(done / task.subtasks.length) * 100}%` }} />
                </div>
              )}
              <ul className="space-y-0.5">
                {task.subtasks.map((s: Subtask) => (
                  <li key={s.id} className="flex items-center gap-2 px-1.5 py-1.5 rounded-md hover:bg-hover text-[13px] group">
                    <button
                      onClick={() => onToggleSubtask(s.id)}
                      aria-label={s.done ? "Uncheck subtask" : "Check subtask"}
                      className={`h-4 w-4 rounded-[4px] flex items-center justify-center ${s.done ? "bg-emerald-500 text-black" : "border border-dim hover:border-foreground"}`}
                    >
                      {s.done && <CheckCircle2 className="h-3 w-3" />}
                    </button>
                    <span className={`flex-1 ${s.done ? "text-dim line-through" : "text-foreground"}`}>{s.title}</span>
                    <button
                      onClick={() => onRemoveSubtask(s.id)}
                      aria-label="Remove subtask"
                      className="opacity-0 group-hover:opacity-100 text-dim hover:text-rose-400"
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                    </button>
                  </li>
                ))}
              </ul>
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (newSub.trim()) {
                    onAddSubtask(newSub);
                    setNewSub("");
                  }
                }}
                className="mt-1 flex items-center gap-2 px-1.5 py-1.5 rounded-md text-[13px]"
              >
                <Plus className="h-3.5 w-3.5 text-dim" />
                <input
                  value={newSub}
                  onChange={(e) => setNewSub(e.target.value)}
                  placeholder="Add subtask"
                  className="flex-1 bg-transparent outline-none text-foreground placeholder:text-dim"
                />
              </form>
            </section>

            {/* Attachments row */}
            <section className="mt-8 flex items-center gap-4 text-[12px] text-dim">
              <button className="flex items-center gap-1.5 hover:text-foreground"><Paperclip className="h-3.5 w-3.5" /> Attach</button>
              <button className="flex items-center gap-1.5 hover:text-foreground"><Link2 className="h-3.5 w-3.5" /> Link note</button>
              <button className="flex items-center gap-1.5 hover:text-foreground"><AtSign className="h-3.5 w-3.5" /> Mention</button>
            </section>
          </div>
        </div>

        {/* Comment box */}
        <div className="shrink-0 border-t border-divider p-3 bg-editor">
          <div className="flex items-start gap-2 rounded-lg bg-sidebar border border-divider px-3 py-2 focus-within:border-foreground/40">
            <MessageSquare className="h-4 w-4 mt-0.5 text-dim" />
            <textarea
              rows={1}
              placeholder="Comment or type @ to mention"
              className="flex-1 bg-transparent resize-none outline-none text-[13px] placeholder:text-dim text-foreground"
            />
            <button className="text-[12px] px-2 py-1 rounded-md bg-foreground text-background hover:opacity-90">
              Send
            </button>
          </div>
        </div>
      </aside>
    </div>
  );
}

function PropLabel({ Icon, text }: { Icon: typeof Circle; text: string }) {
  return (
    <div className="flex items-center gap-2 text-dim pt-1.5">
      <Icon className="h-3.5 w-3.5" strokeWidth={1.75} />
      <span className="text-[12px]">{text}</span>
    </div>
  );
}

function PropValue({ children }: { children: React.ReactNode }) {
  return <div className="flex items-center min-h-[28px]">{children}</div>;
}

function Tag({ children }: { children: React.ReactNode }) {
  return (
    <span className="px-2 py-0.5 rounded-md bg-tag text-[12px] text-foreground/90 font-mono">
      {children}
    </span>
  );
}

function IconBtn({ Icon, label }: { Icon: typeof X; label: string }) {
  return (
    <button aria-label={label} className="h-7 w-7 rounded-md flex items-center justify-center text-dim hover:text-foreground hover:bg-hover">
      <Icon className="h-4 w-4" />
    </button>
  );
}