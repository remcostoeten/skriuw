---
id: "3b0b7c417a164e7f93558767b0dc7c82"
tags: []
sortOrder: 202
preferredEditorMode: "block"
createdAt: 1728444248249
modifiedAt: 1728444320891
---
Was je in je eentje op reis dan? Achteraf toch niet zo’n geweldige ervaring gehad door de mensen om je heen?

Wat heb je zoal uitgespookt, hoogtepunt(en)?