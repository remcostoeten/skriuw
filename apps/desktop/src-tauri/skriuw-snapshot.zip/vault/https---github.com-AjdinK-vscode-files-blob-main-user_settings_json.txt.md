---
id: "3f3c751b-bc67-4dba-b9b8-e3341fe87fd7"
tags: []
sortOrder: 175
preferredEditorMode: "raw"
createdAt: 1734470845089
modifiedAt: 1734470851067
---
https://github.com/AjdinK/vscode-files/blob/main/user_settings_json.txt