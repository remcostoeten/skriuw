---
id: "57920fb328ad4c298e7d13203e0a3575"
tags: []
sortOrder: 315
preferredEditorMode: "raw"
createdAt: 1675298496104
modifiedAt: 1675303348645
---
Gedachtes.

- [ ] Manier van uitmaken-communicatie.
3 december: er moet wat veranderen (vooral Eti). Ik werk eraan, ondertussen wou je niet met me afspreken of tijd maken. vervolgens met oud en nieuw krijgen we ruzie en wil je niet verder praten. In het hotel ook nog half, daarna ga je naar huis en ontloop je me paar weken. Ik geef aan me niet gewaardeerd te voelen, lelijk, onzeker en nog meer dingen als ik mis je. Dat loopt uit op ruzie maar daarover wil je bij me komen praten. Eindstand kom je en hebben we het geen een moment gehad over waar ik zo verdrietig over ben om vervolgens te zeggen ik maak het uit want…(ik ben niet gelukkig, maar meer dan dat kan je me niet vertellen). - en dat terwijl JIJ mij het zo kwalijk nam en bleef hameren op dat ik niet kon communiceren.

-De timing: we spreken dingen af als we gaan naar een notaris. Ik stem in om vakanties te doen, oo m’n verjaardag zeg je tegen al m’n vrienden dat wij maar met z’n tweeën naar een hypotheekadviseur moeten gaan. Vervolgens vraag ik jou om komende tijd mij wat te steunen en geen ruzie maken ivm m’n Eti en mij te helpen met de gym etc wat je allemaal zou doen, maar even later komt dit uit het niets.

-opmerking nu pas moeite doen nu het uit is, deed pijn. Ik heb nog nooit in onze relatie nee gezegd op iets wat jij me vroeg. Alles wat van mij is is van jou, ik heb jou geregeld een kleinigheidje gegeven, of het nou materialistisch is of niet het ging om moeite doen en jou speciaal laten voelen. Remember dat ik elke mogelijk optie voor een mobiel heb uitgezocht voor je en vervolgens een nieuwe voor je regel? Of al die herinneringen om jou wat te ontlasten, je helpen met je belasting, je laptop, trainen, zorgen dat als jij hier komt er is wat jij wilt, je help met brieven schrijven, toch maar ga koken omdat jij moe bent. En zo kan ik nog wel even door gaan. Ik heb nog nooit m’n hand meedraaide of gezegd “nee nu even niet”, ongeacht het tijdstip of grootte van het moeite doen.

Naast zulke dingen kreeg je honderden veren in je reet. Het laatste jaar ondanks dat je geen een keer het bij mij deed heb ik je talloze keren benoemd hoe mooi ik je vind, hoe trots ik op je ben wbt school en nu je carrière, hoe goed je bezig bent in de gym, complimenteer ik je op je lifts, spreek ik uit hoe verschrikkelijk lekker ik je fysiek vind en laat ik je weten dat ik wel opgewonden word van jou. Het ging me niet om een bootypic of blowjob. Het ging me om jou Daphne. 

Ik heb dit maanden lang zonder een periode van chagrijnig zijn gedaan. Ondanks dat ik van jou- zo lang dat ik me het niet meer kan herinneren geen oprecht compliment heb gekregen, uitspraak van waardering, opmerking over m’n innerlijk (ja negatieve) of uiterlijk. Zelfs inkoppertjes kwamen er met moeite uit (kaaklijn). Ik kan het me serieus niet herinneren. En als je al reageerde op iets wat ik lief zien of had gemaakt/gedaan is het meest enthousiaste wat je zei: ja mooi of goed bezig.

-onzeker.
Doordat er geen affectie was. M’n fysiek minder is, jij die alles afkaatste wat kon lijden tot flirten, ik ab-so-luut niet op je Snapchat of bereal mocht komen, ik geen insta posts over ons mocht maken, jij nooit wat poste over ons (TERWIJL JE DAT ZO BELANGRIJK VOND EN WOU DAT IK DAT DEED) nooit mijn story over jou/ons reposte, herhaaldelijk uitspreekt hoe knap sommige BNN’ers wel niet zijn of wel zou doen terwijl ik dat al een jaar niet heb gehoord.  ….. ben ik fucking onzeker geworden. Ik durf niet naar de gym, met Cassiers maak ik geen oogcontact en voel me gewoon een loser.

-beloftes, kleine leugens en niet om mij denken.

je vergat nooit wat, tot een jaar of anderhalf terug? Eerst was het vergeten maar op een duur wist me dondersgoed dat je me beloftes deed die je niet van plan was te doen. Als je niet kon of wou komen of wat moest vertellen expres tot last minute wachten om mij het te vrrfellen(als je dat al deed). Geld overboeken kan je gewoon vooruit plannen (heeft vaal me laten zien). Een paar keer vergeten vind ik niet erg maar zeggen dat ik jd mag herinneren zodra je loon hebt en dan daarover boos worden vind ik kut. Mij beloven dat ik de eerste ben zodra je loon hebt om vervolgens te gaan shoppen en daarna wederom niks overmaakt. Mij blij maken met de woorden dat je ook wel eens wat voor mij wou doen dus een luchtje wou geven, en een paar samples voor me hebt besteld maar daar heb ik nooit meer wat over gehoord.(?) Mij een vape beloven zodra je nieuwe besteld maar elke keer een excuusje verzint of geïrriteerd doen als ik er om vraag. Mij al een halfjaar verteld voor me te willen koken en eindelijk zou je hef doen om vervolgens te zeggen: nee ik ben moe dus ga niet koken. Aka moeite, beloftes? Fuck jou. En dan de gene die het meest pijn doet. Voor m’n verjaardag mij beloven dat we de week erop gaan winkelen en ik wat mag uitzoeken, om vervolgens daar nooit op terug te komen terwijl je voor jezelf wel kleding besteld en werk bonus hebt. Ik die vervolgens een keer of drie jou erom herinner waarop je geïrriteerd antwoord en zegt “we zien wel ff” of “ik ben druk ja” terwijl je gewoon de moeite niet wou doen om mij gewaardeerd te laten voelen. Met als klap op de vuurpijl het twee maanden later uit te maken, tsja zo kan je ook onder een belofte uitkomen. Het is pijnlijk duidelijk geworden hoe weinig moeite je voor me wou doen en om me gaf. Cadeautje kunnen me gestolen worden. Het ging me alleen maar om geliefd te voelen en wetende dat iemand een opoffering voor mij over had.


Ondanks al dit heb ik 