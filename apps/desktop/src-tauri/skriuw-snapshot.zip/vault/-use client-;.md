---
id: "0940c750-3ef0-4a8e-b7a1-b75f8f4db595"
tags: ["ccc"]
sortOrder: 52
preferredEditorMode: "raw"
createdAt: 1762556076423
modifiedAt: 1762557679384
---
"use client";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Kbd } from "../kbd";

export type TreeItemData = {
  id: string;
  label: string;
  href: string;
  current?: boolean;
  items?: TreeItemData[];
};

export type TreeGroupData = {
  title: string;
  items: TreeItemData[];
};

export type TreeData = {
  label: string;
  groups: TreeGroupData[];
};

type TreeItemProps = {
  item: TreeItemData;
  level: number;
  setSize: number;
  posInSet: number;
  parentId?: string;
  currentFocus: string | null;
  onFocus: (id: string) => void;
  onToggle: (id: string) => void;
  expandedIds: Set<string>;
  onActivate: (id: string) => void;
  filtering: boolean;
  searchTerm: string;
  matchedIds: Set<string>;
  relatedIds: Set<string>;
  keyboardShortcut?: number;
};

export type SidebarTreeProps = {
  data: TreeData;
  onSearch?: (term: string, matches: number) => void;
  onActivate?: (id: string) => void;
};

const TreeItem = ({
  item,
  level,
  setSize,
  posInSet,
  parentId,
  currentFocus,
  onFocus,
  onToggle,
  expandedIds,
  onActivate,
  filtering,
  searchTerm,
  matchedIds,
  relatedIds,
  keyboardShortcut,
}: TreeItemProps) => {
  const hasChildren = item.items && item.items.length > 0;
  const isExpanded = expandedIds.has(item.id);
  const isFocused = currentFocus === item.id;
  const itemId = `tree-item-${item.id}`;
  const groupId = hasChildren ? `tree-group-${item.id}` : undefined;

  const getDataAttributes = () => {
    if (!filtering) return {};
    if (matchedIds.has(item.id)) {
      return { "data-search-match": "true" };
    }
    if (relatedIds.has(item.id)) {
      return { "data-search-related": "true" };
    }
    return { "data-filtered": "true" };
  };

  return (
    <li role="none">
      <a
        id={itemId}
        role="treeitem"
        href={item.href}
        tabIndex={isFocused || item.current ? 0 : -1}
        aria-level={level}
        aria-setsize={setSize}
        aria-posinset={posInSet}
        aria-current={item.current ? "page" : undefined}
        aria-expanded={hasChildren ? isExpanded : undefined}
        aria-owns={groupId}
        onFocus={() => onFocus(item.id)}
        onKeyDown={(e) => {
          // Allow Tab key to navigate naturally
          if (e.key === "Tab") {
            return;
          }
          // Handle other keys in parent component
        }}
        onClick={(e) => {
          const isIcon = (e.target as HTMLElement).closest(".tree-icon");
          if (isIcon && hasChildren) {
            e.preventDefault();
            onToggle(item.id);
          } else if (!isIcon) {
            onActivate(item.id);
          }
        }}
        {...getDataAttributes()}
      >
        <span>{item.label}</span>
        <div style={{ display: "flex", alignItems: "center", gap: "0.5rem" }}>
          {keyboardShortcut && keyboardShortcut <= 9 && (
            <Kbd size="sm" variant="outline" className="opacity-75">
              {keyboardShortcut}
            </Kbd>
          )}
          {hasChildren && (
            <span className="tree-icon" aria-hidden="true">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                fill="none"
                viewBox="0 0 24 24"
                strokeWidth="1.5"
                stroke="currentColor"
                style={{ width: "16px", height: "16px" }}
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M12 4.5v15m7.5-7.5h-15"
                />
              </svg>
            </span>
          )}
        </div>
      </a>
      {hasChildren && (
        <div inert={!isExpanded ? true : undefined}>
          <ul id={groupId} role="group">
            {item.items!.map((child, idx) => (
              <TreeItem
                key={child.id}
                item={child}
                level={level + 1}
                setSize={item.items!.length}
                posInSet={idx + 1}
                parentId={item.id}
                currentFocus={currentFocus}
                onFocus={onFocus}
                onToggle={onToggle}
                expandedIds={expandedIds}
                onActivate={onActivate}
                filtering={filtering}
                searchTerm={searchTerm}
                matchedIds={matchedIds}
                relatedIds={relatedIds}
                keyboardShortcut={undefined}
              />
            ))}
          </ul>
        </div>
      )}
    </li>
  );
};

export const SidebarTree = ({
  data,
  onSearch,
  onActivate,
}: SidebarTreeProps) => {
  const [currentFocus, setCurrentFocus] = useState<string | null>(null);
  const [expandedIds, setExpandedIds] = useState<Set<string>>(new Set());
  const [searchTerm, setSearchTerm] = useState("");
  const [matchedIds, setMatchedIds] = useState<Set<string>>(new Set());
  const [relatedIds, setRelatedIds] = useState<Set<string>>(new Set());
  const treeRef = useRef<HTMLUListElement>(null);
  const searchInputRef = useRef<HTMLInputElement>(null);

  const allItems = useMemo(() => {
    const items: TreeItemData[] = [];
    const traverse = (itemList: TreeItemData[]) => {
      itemList.forEach((item) => {
        items.push(item);
        if (item.items) traverse(item.items);
      });
    };
    data.groups.forEach((group) => traverse(group.items));
    return items;
  }, [data]);

  const nodeMap = useMemo(() => {
    const map = new Map<
      string,
      { level: number; hasChildren: boolean; parentId?: string; label: string }
    >();
    const buildMap = (items: TreeItemData[], level = 1, parentId?: string) => {
      items.forEach((item) => {
        map.set(item.id, {
          level,
          hasChildren: !!item.items?.length,
          parentId,
          label: item.label,
        });
        if (item.items) buildMap(item.items, level + 1, item.id);
      });
    };
    data.groups.forEach((group) => buildMap(group.items));
    return map;
  }, [data]);

  const getVisibleItems = useCallback(() => {
    const items: TreeItemData[] = [];
    const traverse = (itemList: TreeItemData[]) => {
      itemList.forEach((item) => {
        items.push(item);
        if (item.items && expandedIds.has(item.id)) {
          traverse(item.items);
        }
      });
    };
    data.groups.forEach((group) => traverse(group.items));
    return items;
  }, [data, expandedIds]);

  useEffect(() => {
    const currentItem = allItems.find((item) => item.current);
    if (currentItem) {
      setCurrentFocus(currentItem.id);
      ensureItemVisible(currentItem.id);
    } else if (allItems.length > 0) {
      setCurrentFocus(allItems[0].id);
    }
  }, []);

  const ensureItemVisible = (itemId: string) => {
    const node = nodeMap.get(itemId);
    if (!node) return;

    const ancestors: string[] = [];
    let currentParentId = node.parentId;
    while (currentParentId) {
      ancestors.push(currentParentId);
      currentParentId = nodeMap.get(currentParentId)?.parentId;
    }

    setExpandedIds((prev) => {
      const next = new Set(prev);
      ancestors.forEach((id) => next.add(id));
      return next;
    });
  };

  const handleToggle = (id: string) => {
    setExpandedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) {
        next.delete(id);
      } else {
        next.add(id);
      }
      return next;
    });
  };

  const handleActivate = (id: string) => {
    setCurrentFocus(id);
    onActivate?.(id);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    // Handle number key shortcuts
    if (e.key >= "1" && e.key <= "9") {
      e.preventDefault();
      const shortcutNumber = parseInt(e.key);
      const flatItems = allItems.filter((item) => {
        // Only include top-level items (items without parents)
        return !nodeMap.get(item.id)?.parentId;
      });

      if (shortcutNumber <= flatItems.length) {
        const targetItem = flatItems[shortcutNumber - 1];
        onActivate(targetItem.id);
      }
      return;
    }

    if (!currentFocus) return;

    // Allow Tab and Shift+Tab to navigate naturally
    if (e.key === "Tab") {
      return;
    }

    const visibleItems = getVisibleItems();
    const currentIndex = visibleItems.findIndex(
      (item) => item.id === currentFocus,
    );
    const currentItem = visibleItems[currentIndex];

    switch (e.key) {
      case "ArrowDown":
        e.preventDefault();
        if (currentIndex < visibleItems.length - 1) {
          setCurrentFocus(visibleItems[currentIndex + 1].id);
        }
        break;
      case "ArrowUp":
        e.preventDefault();
        if (currentIndex > 0) {
          setCurrentFocus(visibleItems[currentIndex - 1].id);
        }
        break;
      case "ArrowRight":
        e.preventDefault();
        if (currentItem.items?.length) {
          if (!expandedIds.has(currentItem.id)) {
            handleToggle(currentItem.id);
          } else {
            setCurrentFocus(currentItem.items[0].id);
          }
        }
        break;
      case "ArrowLeft":
        e.preventDefault();
        if (currentItem.items?.length && expandedIds.has(currentItem.id)) {
          handleToggle(currentItem.id);
        } else {
          const node = nodeMap.get(currentItem.id);
          if (node?.parentId) {
            setCurrentFocus(node.parentId);
          }
        }
        break;
      case "Home":
        e.preventDefault();
        setCurrentFocus(visibleItems[0].id);
        break;
      case "End":
        e.preventDefault();
        setCurrentFocus(visibleItems[visibleItems.length - 1].id);
        break;
      case "Enter":
      case " ":
        e.preventDefault();
        handleActivate(currentItem.id);
        document.getElementById(`tree-item-${currentItem.id}`)?.click();
        break;
      case "*": {
        e.preventDefault();
        const node = nodeMap.get(currentFocus);
        const siblingsToExpand: string[] = [];
        if (node?.parentId) {
          const parent = allItems.find((item) => item.id === node.parentId);
          parent?.items?.forEach((sibling) => {
            if (sibling.items?.length) siblingsToExpand.push(sibling.id);
          });
        } else {
          data.groups.forEach((group) => {
            group.items.forEach((item) => {
              if (item.items?.length) siblingsToExpand.push(item.id);
            });
          });
        }
        setExpandedIds((prev) => {
          const next = new Set(prev);
          siblingsToExpand.forEach((id) => next.add(id));
          return next;
        });
        break;
      }
      default:
        if (e.key.length === 1 && /[a-zA-Z]/.test(e.key)) {
          e.preventDefault();
          const char = e.key.toLowerCase();
          for (let i = currentIndex + 1; i < visibleItems.length; i++) {
            if (visibleItems[i].label.toLowerCase().startsWith(char)) {
              setCurrentFocus(visibleItems[i].id);
              return;
            }
          }
          for (let i = 0; i <= currentIndex; i++) {
            if (visibleItems[i].label.toLowerCase().startsWith(char)) {
              setCurrentFocus(visibleItems[i].id);
              return;
            }
          }
        }
    }
  };

  const handleSearch = (value: string) => {
    setSearchTerm(value);

    if (!value || value.length < 3) {
      setMatchedIds(new Set());
      setRelatedIds(new Set());
      setExpandedIds(new Set());
      const currentItem = allItems.find((item) => item.current);
      if (currentItem) ensureItemVisible(currentItem.id);
      onSearch?.(value, 0);
      return;
    }

    const term = value.toLowerCase();
    const matches = new Set<string>();
    const related = new Set<string>();

    allItems.forEach((item) => {
      if (item.label.toLowerCase().includes(term)) {
        matches.add(item.id);

        let currentParentId = nodeMap.get(item.id)?.parentId;
        while (currentParentId) {
          related.add(currentParentId);
          currentParentId = nodeMap.get(currentParentId)?.parentId;
        }

        const addDescendants = (items: TreeItemData[]) => {
          items.forEach((child) => {
            related.add(child.id);
            if (child.items) addDescendants(child.items);
          });
        };
        if (item.items) addDescendants(item.items);
      }
    });

    setMatchedIds(matches);
    setRelatedIds(related);

    setExpandedIds((prev) => {
      const next = new Set(prev);
      related.forEach((id) => next.add(id));
      return next;
    });

    onSearch?.(value, matches.size);
  };

  useEffect(() => {
    const handleSlash = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      const isEditable =
        target.isContentEditable ||
        ["INPUT", "TEXTAREA", "SELECT"].includes(target.tagName);

      if (e.key === "/" && !isEditable) {
        e.preventDefault();
        searchInputRef.current?.focus();
        searchInputRef.current?.select();
      }
    };

    document.addEventListener("keydown", handleSlash);
    return () => document.removeEventListener("keydown", handleSlash);
  }, []);

  const filtering = searchTerm.length >= 3;

  const treeStyles = `
    .sidebar-tree-container {
      font-family: system-ui, -apple-system, sans-serif;
      width: 100%;
      height: 100vh;
      border: none;
      border-radius: 0;
      background: hsl(var(--background));
      color: hsl(var(--foreground));
      display: flex;
      flex-direction: column;
      overflow: hidden;
    }

    .tree-search-container {
      padding: 0.5rem;
      border-bottom: 1px solid hsl(var(--border));
    }

    .tree-search-input-container {
      position: relative;
      display: flex;
      align-items: center;
    }

    .tree-search-input-container svg {
      position: absolute;
      left: 0.5rem;
      width: 14px;
      height: 14px;
      color: #666;
      pointer-events: none;
    }

    .tree-search-input {
      width: 100%;
      padding: 0.3rem 0.5rem 0.3rem 1.8rem;
      background: hsl(var(--card));
      border: 1px solid hsl(var(--border));
      border-radius: 4px;
      color: hsl(var(--foreground));
      font-size: 12px;
      outline: none;
    }

    .tree-search-input:focus {
      border-color: hsl(var(--ring));
    }

    .tree-search-container kbd {
      position: absolute;
      right: 0.75rem;
      padding: 0.125rem 0.25rem;
      background: #333;
      border-radius: 3px;
      font-size: 11px;
      font-family: monospace;
      color: #999;
    }

    .tree-nav {
      flex: 1;
      overflow-y: auto;
      padding: 0.3rem;
    }

    .tree-nav ul {
      list-style: none;
      margin: 0;
      padding: 0;
    }

    .tree-nav a {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 0.3rem 0.4rem;
      color: hsl(var(--muted-foreground));
      text-decoration: none;
      border-radius: 4px;
      font-size: 12px;
      transition: all 0.2s ease;
    }

    .tree-nav a:hover {
      background: hsl(var(--accent));
      color: hsl(var(--accent-foreground));
    }

    .tree-nav a:focus {
      outline: 2px solid hsl(var(--ring));
      outline-offset: -2px;
    }

    .tree-nav a[aria-current="page"] {
      background: hsl(var(--secondary));
      color: hsl(var(--secondary-foreground));
      font-weight: 500;
    }

    .tree-nav a[data-search-match="true"] {
      background: #1e3a1e;
      color: #90ee90;
      font-weight: 500;
    }

    .tree-nav a[data-search-related="true"] {
      background: #1a1a2e;
      color: #ccc;
    }

    .tree-nav a[data-filtered="true"] {
      opacity: 0.3;
    }

    .tree-icon {
      display: flex;
      align-items: center;
      justify-content: center;
      margin-left: 0.5rem;
      opacity: 0.6;
      transition: transform 0.2s ease;
    }

    .tree-nav a[aria-expanded="true"] .tree-icon {
      transform: rotate(45deg);
    }

    .tree-nav div[inert] {
      display: none;
    }
  `;

  return (
    <>
      <style>{treeStyles}</style>
      <div className="sidebar-tree-container">
        <div className="tree-search-container">
          <div className="tree-search-input-container">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              viewBox="0 0 20 20"
              fill="currentColor"
            >
              <path
                fillRule="evenodd"
                d="M9 3.5a5.5 5.5 0 1 0 0 11 5.5 5.5 0 0 0 0-11ZM2 9a7 7 0 1 1 12.452 4.391l3.328 3.329a.75.75 0 1 1-1.06 1.06l-3.329-3.328A7 7 0 0 1 2 9Z"
                clipRule="evenodd"
              />
            </svg>
            <input
              ref={searchInputRef}
              type="text"
              placeholder="Find (press /)"
              className="tree-search-input"
              value={searchTerm}
              onChange={(e) => handleSearch(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Escape") {
                  handleSearch("");
                  e.target.blur();
                }
                // Allow Tab and Shift+Tab to navigate naturally
                if (e.key === "Tab") {
                  return;
                }
              }}
              tabIndex={0}
            />
            <Kbd size="sm" variant="ghost">
              /
            </Kbd>
          </div>
        </div>
        <nav className="tree-nav" aria-label={data.label}>
          <ul
            ref={treeRef}
            role="tree"
            aria-label={data.label}
            data-filtering={filtering || undefined}
            onKeyDown={handleKeyDown}
            tabIndex={0}
          >
            {data.groups.map((group, groupIndex) => (
              <li key={`group-${groupIndex}`} role="none">
                <ul role="group" id={`tree-group-toplevel-${groupIndex}`}>
                  {group.items.map((item, idx) => (
                    <TreeItem
                      key={item.id}
                      item={item}
                      level={1}
                      setSize={group.items.length}
                      posInSet={idx + 1}
                      currentFocus={currentFocus}
                      onFocus={setCurrentFocus}
                      onToggle={handleToggle}
                      expandedIds={expandedIds}
                      onActivate={handleActivate}
                      filtering={filtering}
                      searchTerm={searchTerm}
                      matchedIds={matchedIds}
                      relatedIds={relatedIds}
                      keyboardShortcut={idx + 1}
                    />
                  ))}
                </ul>
              </li>
            ))}
          </ul>
        </nav>
      </div>
    </>
  );
};
