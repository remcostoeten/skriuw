---
id: "5fc4a208-b419-4fe5-8770-027430a8fa33"
tags: []
sortOrder: 117
preferredEditorMode: "raw"
createdAt: 1745935796226
modifiedAt: 1745935812421
---
import { IResource } from '../Utils/Resource';

export interface ThemeConfig {
  useStyling: boolean;
  colors: {
    [key: string]: string | undefined;
  };
  styles: {
    [key: string]: string | undefined;
  };
  assets: {
    logo?: string | null;
    styles?: string[];
    [key: string]: unknown;
  };
}

export interface Theme extends IResource<'themes'> {
  theme: string;
  primary: ThemeConfig;
}

export interface ThemeCreateInput {
  theme: string;
}

export interface ThemeUpdateInput extends ThemeCreateInput {}

export enum ThemeIncludes {
  COLORS = 'colors',
  STYLES = 'styles',
  ASSETS = 'assets',
}

export interface ThemeFilters {
  version?: number;
  hasLogo?: boolean;
}

export enum ThemeSorts {
  VERSION_ASC = 'version',
  VERSION_DESC = '-version',
}


Oke, ik ben bezig geweest met de themeing `feature/admin-custom-theme` en hij functioneert prima. Ik heb development gelijk kunnen trekken (diff had 150+ files, dus gemerged ipv gerebased). Heb pre-merge just to be sure de branch `backup/admin-theme-pre-dev-nerge` gemaakt, wat de versie voor de merge is, maar alles lijkt op te gaan.

Ik heb naast de merge nog het volgende gedaan:
- Storybook 
