---
id: "69f35ab5-08cf-4c81-9009-523d72c96663"
tags: []
sortOrder: 135
preferredEditorMode: "raw"
createdAt: 1742147300203
modifiedAt: 1742147369755
---
Got it! Here's the revised version, each under 1000 characters:

---

**Part 1:**

Can you create a dark-themed Vercel-looking widget (similar to https://resend.com, https://midday.ai, or https://vercel.com) for a Next.js app? The widget should be scoped into one folder located at "src/modules/widgets/calculator/", with the following structure:

```
%/api    <-- Server logic
%/api/queries/  <-- Server functions
%/api/mutations/  <-- Mutations (e.g., `post`, `put`)
%/api/models/    <-- Zod schemas (`z.some-name.ts`)
%/api/schemas/  <-- Drizzle schemas if needed
%/components
%/hooks
%/state
%/styles
%/helpers
%/views/calculator-widget-view.tsx
%/views/calculator-view   <-- If it’s a full page
```

---

**Part 2:**

The widget should have a settings button for:

- Resizing the widget (width/height)
- Locking the widget (disabling resizing/movement)
- Changing opacity

Must-have features:

- Project-agnostic (everything in one folder)
- Clean separation of concerns
- Quick/performance
- Fully keyboard accessible:
    - Numbers work
    - `Ctrl`/`Cmd + C` copies output
    - `Backspace` deletes one number
    - `Enter` submits calculation
    - `Ctrl`/`Cmd + Backspace` returns to previous screen
    - History tab for past entries/results
- Supports basic operators: `+`, `-`, `x` (or `*`), `/`
- Accessible: remembers memory, includes shortcuts and micro-interactions, settings menu for visual customization.

---

Both parts are now under the 1,000-character limit!