---
id: "11598297-5066-4412-af19-2e8090d2a203"
tags: []
sortOrder: 358
preferredEditorMode: "raw"
createdAt: 1660482129430
modifiedAt: 1660643617786
---
Pimshop mijn overfzicht -> mijn adressen

-De search is statisch, moet werkend worden.
-De tabs (mijn adressen en overige adressen) moeten de juiste adressen ophalen (en dus ook het nummertje erachter wijzigen, die staat nu hard inde HTML).
