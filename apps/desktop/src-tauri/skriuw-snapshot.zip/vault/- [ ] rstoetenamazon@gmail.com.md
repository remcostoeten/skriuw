---
id: "d49f5a0908b14750aff29126b4405193"
tags: []
sortOrder: 3
preferredEditorMode: "block"
createdAt: 1686182047720
modifiedAt: 1778537424143
---
- [ ] rstoetenamazon@gmail.com
Mhca6r4g1!

julianarends11@gmail.com


Houdt van (dikke)billen 


653434619
Gg



Why do the workspace pages work in /dashboard but not /panel? We want to make it work in /panel…