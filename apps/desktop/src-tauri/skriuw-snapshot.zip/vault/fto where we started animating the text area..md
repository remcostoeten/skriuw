---
id: "e857eb7e0cc84e59b05fd4c238e8d871"
tags: []
sortOrder: 118
preferredEditorMode: "block"
createdAt: 1728348023107
modifiedAt: 1745864140265
---
fto where we started animating the text area.

-We had textarea with character and like count below it
-Radio buttons to select “profile id only”,”username only” or “both”
- A paste button 
- A clear button 
- A submit button 

-on  submit a syntax highlighted with line numbers and collapse if more thank 100 likes or so appeared
- a box with statistics of how many likes left and potentially  what failed 
-save Lisr button which. Showed a pop-up with optional  title, calendar and title preview plus submit btn
-a sidebar with the saved entry with date + lime count clickable to view the result 

All stored in stowage and global state  