---
id: "a70a1ec7-03d1-458d-bfcf-d3d6772f3cb6"
tags: []
sortOrder: 372
preferredEditorMode: "raw"
createdAt: 1658062180369
modifiedAt: 1658062489314
---
Via whapp was kut en zei wou niks meer, ik zou in avond naar haar toe en vtv belde ze me op omdat haar appjes niet binnen kwamen om te zeggen dat ik wel kon komen, toen eerst al bijnna 2,5 uur gebeld over small talk dingen, daarna daarheen gereden en eerst ff gepraat en gefeliciteerd over school/studie halen en gaandeweg eigenlijk alles op tafel geegooid wat we hadden voor problemen en zij begreep mij wel in alles, ze vond alleen dat  dat als ik op whapp discussier ik haar  liet denken aan haar vader (niet echt contact mee, heb ik nog noooit gezien) omdat die ook altijd zo doorpushde en ze dan dichtklapt, maar ze weet irl wel dat ik niet iemand ben die ruzie maakt etc

 Daarna ook gewoon veel smalltalk en eigenlijk in afgelopen jaar geen een keer zoveel gelachen en gepraat als eergister dus leek wel alsopf we beide wel anders wouden proberen, ze zei wel ik wil eerst een maand aankijken en  als het dan nog kut is dan stoppen we er ook gewoon mee, maar wel afspraken gemaakt dat we als we niet afspreken wat vaker bellen om dingen te bespreken ipv via app want dat was grootste probleem, gisteravond toen ik thuis was zou ze ook nog ff 10 min bellen maar eindstand ook 2 uur geworden met fucking veel lachen etc, dus lijkt nu for once misschien wel wat te veranderen, ook omdat ze niet meer zo   bizar druk is met school elke dag, of nouja helemaal geen school meer. Net nieuw jaarcontract gekeregen, hogere loonschaal en naar 32 uur geswithhed dus die s tabiliteit doet ook wel wat dingen verbeteren i guess
