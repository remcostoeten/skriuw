---
id: "8b64757f-0476-4c34-b729-4e9c2a19d48d"
tags: []
sortOrder: 38
preferredEditorMode: "raw"
createdAt: 1766156830839
modifiedAt: 1766157069202
---
At the top of the application we have a bar  which says untitled with at the left side naviation arrows, split editor at the right at succh

On not pages the unnitled gets replaced with the note title, but on pages like trash or settings the untitled is useless, it should either act as a breadcrumb final destionation, and the icons should be conditionally rendered, for example not on pages whih has no notes to navigate to.

Further, can u typecheck and build via bun 
_________________________________________________________________-
saves all the nodes. But we have to have a good debouncing system for that. And also keep in mind that we are, we want to build a history system in the future with basically some kind of a git system where you can refer every changes you want. So we have to make sure we don't save when it's not needed, because every save will be shown in the tree, so to say, in the save tree. And we have to maybe ignore white space. Only if the formatting is really changed a lot, but if there's only added a couple of spaces here and there, then we shouldn't save. But if there's really done formatting to prettier or something, we will have to save. And besides that, we want a option under the settings, under the settings modal, to not have autosaving on. And if that is on, then when the, when the,When there are changes in the node, and you have auto-save or disabled, it should show a save button, which is just a manual action to save that particular state you are on, which obviously should be a disabled state, or it has a dirty check state if there are no changes. And if you navigate to a different tab, or a different node, it should add a 1 or 2, a quantity indicator that you have different files not saved yet. And if you try to exit all the program, it should say that you have unsaved changes. Do you want to save them? And if you press yes, you go one by one over all the files, and you can click save all, or do a one by one saving, and you get a diff view like Git.