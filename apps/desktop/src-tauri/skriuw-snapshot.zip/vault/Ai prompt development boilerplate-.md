---
id: "98dd27b83ef24b45ba2855e98e79cda8"
tags: ["ai","boilerplate","developmemt","prompt"]
sortOrder: 208
preferredEditorMode: "block"
createdAt: 1727585069656
modifiedAt: 1727589960242
---
Ai prompt development boilerplate:

I want a *******   App    /    Feature  for my already existing nextjs 15 app router exclusive application. The application is a personal dashboard with already a database setup, authentication and components.

## Tech:

-Nextjs 15
-React 19 (hooks like “use” “useTransition” “useoptimistic”) prevent usage of unecisarry use effects.
-Tailwinds CSS
-Server actions only, no API-routes. Exempt if a very good reason
-Drizzle orm with PostgreSQL (Neon)
-Lucia authentication with sessions
-Framed motion if needs 
-Zustand if needed
-Shadcn.  I have an alias called ui which links to ui/index.ts so u can import all shading domponents in  1 line from. ‘Ui’

## ui

Dark, black pure theme like vervel or resend.com. Not dark blue, way darker.
Modern clean aesthetic UI

## Code style:

-Try to utilize SSR with pre skeleton loaders and spinners. Try to keep client components at a minimum .
-Checking auth Lucia session needs headers which won’t work in a client component.
-Use newest hooks from latest react updates 
-prevent usage of use effect only if no other options 
-revalidatie the page instantly after update without refreshing
-use types, not interfaces
-use functions where possible instead of const.
-make use of seperate of concerns. Small single usage files.
Use kebab style file convention 
Co-locate components directly related to the feature next to its page.tsx in a _components folders 
-use types instead of interfaces. If there are alof of types in the feature consider a feature.types.d.ts file

## Folded structure ;

Like I said shadcn imported from ui

-App will live under app src dashboard FEATURE_NAME. 

- FEATURE/page.tsx
- FEATURE/_components (co-locate components 
-Feature/utils if needed

-Src/core/hooks if needed
-Server actions are exported:  ‘into src/core/server/actions/index.ts’
But are written individually into ‘src/core/server/actions/FEATURE/action-name.ts’
Each ‘actions/FEATURE’ has an ‘index.ts’ which exports all files in its own directory so we can export the ‘index.ts’ to the alias index.ts in ‘src/core/server/actions/index.ts’

-Server actions must prefix with “use server” and contain adequate error handling. All Errors and success messages must be able to be translated into a Toast (we use Sonner).

into src/core/server/actions/Feature/index.ts and export in there, which we then export in the actions/index.ts

## import aliases: 
-shadcn index.ts exports all components and I made tsconcig alias to that index.ts called “ui”
-Any zustnax store can be imported from “stores”
-All server actions are imported from “actions” which links to src/core/server/actions/index.ts
-Db can be imported from “db”
-Schema can be imported from “db”
<Flex> can be imported from @/components/atoms/Flex (<flex dir=col gap=10 justify=between etc)
-Hooks are src/core/hooks
-Lucia with is src/lib/auth/lucia.ts

## Feature:

## feature one
      - consistoff
      - consisfsoff
      - Consisfsoff
 
## feature two 
        -  consistsoff
        -  consistsoff
## feature three
        - consistsoff
        - consistsoff

