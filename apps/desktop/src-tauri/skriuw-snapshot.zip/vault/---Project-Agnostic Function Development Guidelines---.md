---
id: "f9c32b8d-c36e-44bb-8dd7-63c78358662d"
tags: []
sortOrder: 128
preferredEditorMode: "raw"
createdAt: 1742925085034
modifiedAt: 1742925145603
---
///Project-Agnostic Function Development Guidelines///
Objective
Create a collection of highly reusable, clean TypeScript functions that can be easily copied and pasted into any project with minimal dependencies.
Folder Structure
///
src/
└── core/
└── functions/
├── function-name/
│   ├── index.ts         # Main barrel file for the function
│   ├── utils.ts         # Utility functions
│   ├── types.ts         # Type definitions
│   └── tests.ts         # Unit tests
│
├── index.ts             # Root barrel file for all functions
└── standalone-function.ts
///
Key Requirements
1. Function Characteristics

Aim for zero external dependencies
When necessary, limit to essential packages (e.g., nuqs, framer motion, zustand)
Pure TypeScript functions (.ts)
Not tied to specific UI components
Designed for maximum portability and reusability

2. Function Design Principles

Prioritize small, focused functions
Avoid nested function structures
Minimize potential re-render triggers
Create independent, modular code blocks
Always use function declarations over constants
Prefer pure functions with predictable outputs

3. Typing and Interface Guidelines

Use interfaces for type extension and complex type definitions
Implement interface extension when additional functionality is needed
Demonstrate type inheritance in examples
Use precise, descriptive type naming
Avoid any type (use unknown if type is uncertain)
Showcase type composition and extension

4. File Structure and Naming

Use kebab-case for file and folder names
Prefix files with their primary action (get-, set-, create-, update-)
Each function should be in its own file or directory
Create barrel files (index.ts) for easy importing
Separate concerns with additional files (types.ts, utils.ts, tests.ts)

Example File Contents
types.ts
///typescript
export type TProps = { /* type definitions / }
export interface IConfig { / interface definitions */ }
///
utils.ts
///typescript
export function helperFunction() { /* utility logic */ }
///
index.ts (main function file)
///typescript
/**

@author [Your Name]
@description [Clear, concise description of the function's purpose]
@param {ParamType} paramName - Description of the parameter
@returns {ReturnType} Description of the return value
*/
export function mainFunction(props: TProps): ReturnType {
// Core logic implementation
return processedResult
}

/**

@author Remco Stoeten
@description Returns the current date in YYYY-MM-DD format
@returns {string} Current date in YYYY-MM-DD format
*/
export function getCurrentDate(): string {
return new Date().toISOString().split('T')[0]
}

// Re-export types and utilities
export type { TProps, IConfig }
export { helperFunction }
///
tests.ts
///typescript
describe('mainFunction', () => { /* unit tests */ })
///
Docstring Guidelines

Always include @author
Provide a clear @description
Use @param for each parameter (if applicable)
Specify @returns with the return type and description
Keep descriptions concise and meaningful
Place docstring immediately before the function declaration

Example Code Writing Guidelines
Preferred Example Format
///typescript
/**

@author [Your Name]
@description Processes user permissions based on role
@param {ExtendedUser} user - User object with extended properties
@returns {string} Determined access level
*/
function processUserPermissions(user: ExtendedUser): string {
const accessLevel = determineAccessLevel(user);
console.log(User Access Level: ${accessLevel});
return accessLevel;
}
///

Strict Example Writing Rules

No unnecessary comments
No 'use client' directive
Minimal imports (implied/obvious imports omitted)
Use descriptive but concise type names
Always use function declarations
Avoid function constants or arrow function assignments
Provide clear type definitions
Demonstrate type extension and composition
Focus on core functionality
Show practical, real-world usage scenarios
Keep functions small and focused
Ensure functions are standalone and independent

Importing Best Practices
///typescript
// Good: Explicit, clear imports
import {
processUserPermissions,
type ExtendedUser
} from '@/core/functions/user-permissions'
// Avoid: Wildcard imports
import * as UserFunctions from '@/core/functions/user-permissions'
///
Additional Notes

Prioritize readability and simplicity
Create modular, independent code blocks
Minimize cognitive overhead for developers using the function
Use interfaces to extend and compose types effectively
Include comprehensive documentation
Write unit tests for each function

Suggested Improvements and Future Considerations

Consider adding a common error handling utility
Create a standardized logging mechanism
Develop a consistent approach to optional dependencies
Implement a lightweight validation library if needed

Contribution Guidelines

Ensure all functions follow the outlined principles
Document any external package dependencies
Provide clear examples of function usage
Write comprehensive unit tests
Keep functions pure and predictable