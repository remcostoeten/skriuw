---
id: "0b949d24-cf5a-4f31-9d06-d3d849241ed2"
tags: []
sortOrder: 130
preferredEditorMode: "raw"
createdAt: 1742784832302
modifiedAt: 1742798385942
---
# Theme Feature Implementation Guide

This document provides a specification for implementing the theme customization feature with improved code quality following established project standards.

## Feature Overview

The theme feature allows users to customize the application's color scheme. It includes:
- A theme preview page showing example UI elements with the current theme
- A theme configuration page for selecting and customizing colors
- Storage of theme preferences in session storage
- Real-time updating of CSS variables as colors are changed

## Code Structure

Follow this structure for organizing the feature, which aligns with project conventions:

```
/src
  /pages
    /admin
      /dashboard
        theme.tsx        # Theme configuration page
        theme-preview.tsx # Theme preview page
  /Views
    /Admin
      /Dashboard
        /Theme
          /components
            ColorPicker.tsx
            ColorScheme.tsx
          /hooks
            useThemeManager.ts
          ThemeView.tsx         # The main view for theme preview
          ThemeConfigView.tsx   # The config page view
          ExamplePage.tsx       # Component showing theme examples
          types.ts              # Types used across the theme components
          config.ts             # Theme configuration constants
```

## Component Implementation Guidelines

### 1. General Coding Standards

- Use TypeScript interfaces for props that extend other interfaces, otherwise use type
- Use TProps naming convention for component prop types
- Avoid separate type files when not extending - include types in the component file
- Avoid redundant/self-explanatory comments
- Avoid nested ternaries
- Use CSS variables consistently
- Prefer functional components with arrow function syntax
- Organize imports in groups (React core imports, external libraries, internal components)
- Use import statements ordered alphabetically within each group

### 2. ThemeView Component

```tsx
import { Button } from '@brainstud/ui/Buttons/Button';
import { Title } from 'Components/Title';
import { ExamplePage } from './ExamplePage';
import styles from './ThemeView.module.css';

/**
 * ThemeView
 * 
 * Displays a preview of the current theme with an example page
 * and provides a link to the theme configuration page.
 */
export const ThemeView = () => (
  <div className={styles.container}>
    <header className={styles.header}>
      <div className={styles.titleWrapper}>
        <Title style={{ margin: '0' }}>Theme Preview</Title>
      </div>
      <Button href="/admin/dashboard/theme">Configure Theme</Button>
    </header>
    <div className={styles.preview}>
      <ExamplePage />
    </div>
  </div>
);
```

### 3. ThemeConfigView Component

```tsx
import { useGoBack } from 'Hooks/GoBack';
import { ColorScheme } from './ColorScheme';
import { ColorPicker } from './components/ColorPicker';
import { COLOR_VARIANT_GROUPS, THEME_CONFIG } from './config';
import { ExamplePage } from './ExamplePage';
import { useThemeManager } from './hooks/useThemeManager';
import styles from './ThemeConfigView.module.css';
import { useApi } from 'Hooks/useApi';
import { UploadBox } from 'Components/UploadBox';
import { FileCard } from 'Components/FileCard';
import { Button } from '@brainstud/ui/Buttons/Button';

/**
 * ThemeConfigView
 * 
 * Provides a UI for configuring the theme colors with live preview.
 * Shows color pickers and color variants for each configurable color.
 */
export const ThemeConfigView = () => {
  const goBack = useGoBack('/admin/dashboard');
  const { colors, logo, handleColorChange, handleLogoChange } = useThemeManager();
  const { baseUrl, apiHeaders } = useApi();

  const handleLogoUpload = (file: any, response: any) => {
    if (response?.data) {
      handleLogoChange({
        id: response.data.id,
        downloadUrl: response.data.downloadUrl,
        originalFileName: file.name
      });
    }
  };

  const handleLogoRemove = async () => {
    handleLogoChange(null);
  };

  return (
    <div className={styles.container}>
      <div className={styles.header}>
        <button 
          onClick={goBack} 
          className={styles.backButton} 
          type="button"
        >
          Back to Dashboard
        </button>
        <h1>Theme Configuration</h1>
      </div>

      <div className={styles.logoSection}>
        <h2>Logo Configuration</h2>
        {!logo ? (
          <UploadBox
            url={`${baseUrl}/v1/services/media_upload`}
            headers={{ ...apiHeaders, 'Content-Type': undefined }}
            paramName="file"
            maxFiles={1}
            accept="image/*"
            quiet
            onAfterUpload={handleLogoUpload}
            className={styles.uploadBox}
          >
            <Button type="button">
              Upload Logo
            </Button>
          </UploadBox>
        ) : (
          <div className={styles.currentLogo}>
            <h4>Current Logo</h4>
            <FileCard
              name={logo.originalFileName}
              thumbnail={logo.downloadUrl}
              downloadUrl={logo.downloadUrl}
              onRemove={handleLogoRemove}
            />
          </div>
        )}
      </div>

      <div className={styles.preview}>
        <ExamplePage 
          key={JSON.stringify({ colors, logo })}
          background={colors?.[THEME_CONFIG.COLOR_SCHEMES.LIGHT_BG]}
          logo={logo?.downloadUrl}
        />
      </div>

      <div className={styles.colorPickers}>
        {Object.entries(THEME_CONFIG.COLOR_SCHEMES).map(([name, key]) => (
          <ColorPicker
            key={key}
            colorKey={key}
            value={colors?.[key] || ''}
            onChange={handleColorChange}
          />
        ))}
      </div>

      <div className={styles.colorVariants}>
        <h2>Color Variants</h2>
        <div className={styles.variantsGrid}>
          {Object.entries(COLOR_VARIANT_GROUPS).map(([groupKey, group]) => (
            <div key={groupKey} className={styles.schemeGroup}>
              <h4>{group.title}</h4>
              {group.schemes.map((scheme) => (
                <ColorScheme
                  key={scheme}
                  scheme={scheme}
                  values={THEME_CONFIG.DEFAULT_VARIANTS}
                />
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
```

### 4. ExamplePage Component

```tsx
import { CSSProperties, ReactNode } from 'react';
import { Button } from '@brainstud/ui/Buttons/Button';
import { Panel } from '@brainstud/ui/Static/Panel';
import cx from 'classnames';
import Image from 'next/image';
import styles from './ExamplePage.module.css';

/**
 * Props for the ExamplePage component
 */
type TProps = {
  children?: ReactNode;
  background?: string;
  className?: string;
  style?: CSSProperties;
  logo?: string;
};

/**
 * ExamplePage
 * 
 * Displays a sample page layout that showcases the current theme
 * with various UI elements like buttons, text, and panels.
 */
export const ExamplePage = ({
  children,
  background = 'primary-background-color',
  className,
  style,
  logo = 'https://cdn-a.unlimited.farm/course-content/files/iseOcUFZxqY1elDADmO5MF8dtlaF1Rc9FIuyp3Fq.svg',
}: TProps) => (
  <div className={cx(styles.base, 'example-page')}>
    <header className={styles.header}>
      <div className={styles.logo}>
        <Image src={logo} alt="Logo" width={100} height={40} priority />
      </div>
      <div className={styles.buttons}>
        <Button
          type="button"
          quiet
          style={{ color: 'rgb(var(--brand-color-text))' }}
        >
          Register
        </Button>
        <Button type="button">Login</Button>
      </div>
    </header>
    <div
      className={cx(styles.content, className)}
      style={{
        backgroundColor: `rgb(var(--${background}))`,
        color: `rgb(var(--${background}-text))`,
        ...style,
      }}
    >
      {children || (
        <>
          <Button type="button">Primary button</Button>
          <Button outline type="button" style={{ margin: '0 .5rem' }}>
            Outline button
          </Button>
          <Button quiet type="button">
            Quiet button
          </Button>
          <p style={{ padding: '1rem', color: `rgb(var(--${background}-text))` }}>
            Text in body <a href="#">with a link</a>. Or with an{' '}
            <span
              style={{
                display: 'inline-block',
                fontWeight: 'bold',
                borderBottom: '2px solid rgb(var(--accent-color, var(--primary-color)))',
              }}
            >
              accent
            </span>.
          </p>
          <Panel pad>
            <p>
              Text in body <a href="#">with a link</a>. Or with an{' '}
              <span
                style={{
                  display: 'inline-block',
                  fontWeight: 'bold',
                  borderBottom: '2px solid rgb(var(--accent-color, var(--primary-color)))',
                }}
              >
                accent
              </span>.
            </p>
          </Panel>
        </>
      )}
    </div>
  </div>
);
```

### 5. ColorPicker Component

```tsx
import { ChangeEvent } from 'react';
import { hexToRgbString } from 'Modules/admin-panel/Utils/colorUtils';
import styles from './ColorPicker.module.css';
import { ColorKey } from '../../types';

/**
 * Props for the ColorPicker component
 */
type TProps = {
  /** Color key from the theme configuration */
  colorKey: ColorKey;
  /** Current RGB value as a string */
  value: string;
  /** Callback function when a color is changed */
  onChange: (key: ColorKey, value: string) => void;
};

/**
 * Converts an RGB string to a hex color value
 */
const rgbToHex = (rgbString = ''): string => {
  try {
    const [r = 0, g = 0, b = 0] = rgbString
      .split(',')
      .map((n) => parseInt(n.trim(), 10));
    return `#${r.toString(16).padStart(2, '0')}${g.toString(16).padStart(2, '0')}${b.toString(16).padStart(2, '0')}`;
  } catch {
    return '#000000';
  }
};

/**
 * ColorPicker
 * 
 * Provides a color input field for selecting colors
 * with label and color preview.
 */
export const ColorPicker = ({
  colorKey,
  value,
  onChange,
}: TProps) => {
  const handleColorChange = (e: ChangeEvent<HTMLInputElement>) => {
    onChange(colorKey, hexToRgbString(e.target.value));
  };

  return (
    <div className={styles.colorField}>
      <label htmlFor={colorKey}>{colorKey.replace(/-/g, ' ')}</label>
      <div className={styles.colorInputWrapper}>
        <input
          type="color"
          id={colorKey}
          value={rgbToHex(value)}
          onChange={handleColorChange}
        />
        <input
          type="text"
          value={value || ''}
          readOnly
          className={styles.rgbInput}
        />
      </div>
    </div>
  );
};
```

### 6. ColorScheme Component

```tsx
import styles from './ColorScheme.module.css';

/**
 * Props for the ColorScheme component
 */
type TProps = {
  /** The color scheme to display variants for */
  scheme: string;
  /** Percentage values for color variants */
  values?: number[];
};

/**
 * ColorScheme
 * 
 * Displays a set of color variants based on a base color
 * and percentage values.
 */
export const ColorScheme = ({
  scheme,
  values = [10, 20, 30, 50, 75, 0, 110, 115],
}: TProps) => (
  <div className={styles.base}>
    {values.map((colorValue) => {
      const variable =
        colorValue === 0 ? `--${scheme}` : `--${scheme}-${colorValue}`;
      const variableName = colorValue === 0 ? 'default' : `-${colorValue}`;

      return (
        <div
          key={variable}
          className={styles.color}
          style={{
            background: `rgb(var(${variable}))`,
            color: `rgb(var(--${scheme}-text))`,
          }}
        >
          {variableName}
        </div>
      );
    })}
  </div>
);
```

### 7. useThemeManager Hook

```tsx
import { useCallback, useEffect, useMemo } from 'react';
import { useSessionStorage } from 'Hooks/BrowserStorage/useSessionStorage';
import { hexToRgbString, updateThemeColors } from 'Modules/admin-panel/Utils/colorUtils';
import { useThemeProvider } from 'Providers/ThemeProvider/useThemeProvider';
import { DEFAULT_THEME, THEME_CONFIG } from '../config';
import { ColorKey, THEME_STORAGE_KEY, ThemeColors, ThemeDispatch } from '../types';

/**
 * Generates color variants based on a base color and percentage values
 */
const generateColorVariants = (
  color: string,
  variants: ReadonlyArray<number>
): ThemeColors => {
  const [r, g, b] = color.split(',').map((n) => parseInt(n.trim(), 10));
  const variantsObj: ThemeColors = {};

  variants.forEach((variant) => {
    const factor = variant / 100;
    const newR = Math.min(255, Math.round(r * factor));
    const newG = Math.min(255, Math.round(g * factor));
    const newB = Math.min(255, Math.round(b * factor));
    variantsObj[`${variant}`] = `${newR}, ${newG}, ${newB}`;
  });

  return variantsObj;
};

/**
 * useThemeManager
 * 
 * Custom hook for managing theme colors, including:
 * - Loading theme from session storage or provider
 * - Updating theme colors and CSS variables
 * - Handling color changes
 */
export const useThemeManager = () => {
  const { colors: providerColors, dispatch } = useThemeProvider();
  const [storedTheme, setStoredTheme] = useSessionStorage<ThemeConfig>(
    THEME_STORAGE_KEY,
    { colors: DEFAULT_THEME }
  );

  const colors = useMemo(
    () => providerColors || storedTheme?.colors || DEFAULT_THEME,
    [providerColors, storedTheme]
  );

  const logo = useMemo(
    () => storedTheme?.logo,
    [storedTheme]
  );

  const updateCSSVariables = useCallback((newColors: ThemeColors) => {
    Object.entries(newColors).forEach(([key, value]) => {
      document.documentElement.style.setProperty(`--${key}`, value);

      if (THEME_CONFIG.DEFAULT_VARIANTS.length > 0) {
        const variants = generateColorVariants(
          value,
          THEME_CONFIG.DEFAULT_VARIANTS
        );
        
        Object.entries(variants).forEach(([variant, variantValue]) => {
          document.documentElement.style.setProperty(
            `--${key}-${variant}`,
            variantValue
          );
        });
      }
    });
  }, []);

  const handleColorChange = useCallback(
    (key: ColorKey, value: string) => {
      try {
        const rgbValue = hexToRgbString(value);
        const newColors: ThemeColors = {
          ...colors,
          [key]: rgbValue,
        };

        updateThemeColors(newColors);
        setStoredTheme(prev => ({
          ...prev,
          colors: newColors
        }));
        updateCSSVariables(newColors);

        requestAnimationFrame(() => {
          dispatch({
            type: 'UPDATE_THEME',
            payload: { 
              colors: newColors,
              logo: storedTheme?.logo
            },
          } as ThemeDispatch);
        });
      } catch (error) {
        console.warn('Invalid color value:', value);
      }
    },
    [colors, dispatch, setStoredTheme, updateCSSVariables, storedTheme?.logo]
  );

  const handleLogoChange = useCallback(
    (logoData: ThemeConfig['logo'] | null) => {
      setStoredTheme(prev => ({
        ...prev,
        logo: logoData || undefined
      }));

      requestAnimationFrame(() => {
        dispatch({
          type: 'UPDATE_THEME',
          payload: { 
            colors,
            logo: logoData || undefined
          },
        } as ThemeDispatch);
      });
    },
    [colors, dispatch, setStoredTheme]
  );

  useEffect(() => {
    if (colors) {
      updateCSSVariables(colors);
    }
  }, [colors, updateCSSVariables]);

  return {
    colors,
    logo,
    storedTheme,
    handleColorChange,
    handleLogoChange,
  };
};
```

### 8. types.ts

```tsx
/**
 * List of available color keys for theming
 */
export const colorList = [
  'primary-color',
  'brand-color',
  'focus-color',
  'accent-color',
  'light-background-color',
  'dark-background-color',
  'error-color',
  'success-color',
  'warning-color',
] as const;

/**
 * Type for color keys based on the color list
 */
export type ColorKey = (typeof colorList)[number];

/**
 * Storage key for theme settings in session storage
 */
export const THEME_STORAGE_KEY = 'theme-settings';

/**
 * Theme colors dictionary mapping CSS variable names to RGB values
 */
export interface ThemeColors {
  [key: string]: string;
}

/**
 * Theme configuration object
 */
export interface ThemeConfig {
  colors: ThemeColors;
  logo?: {
    id: string;
    downloadUrl: string;
    originalFileName: string;
  };
}

/**
 * Dispatch action for updating theme in context
 */
export interface ThemeDispatch {
  type: 'UPDATE_THEME';
  payload: {
    colors: ThemeColors;
    logo?: {
      id: string;
      downloadUrl: string;
      originalFileName: string;
    };
  };
}
```

### 9. config.ts

```tsx
/**
 * Theme configuration values
 */
export const THEME_CONFIG = {
  /** Key for storing theme in session storage */
  STORAGE_KEY: 'theme-settings',
  /** Default color variant percentages */
  DEFAULT_VARIANTS: [10, 20, 30, 50, 75, 0, 110, 115],
  /** Available color schemes with their CSS variable names */
  COLOR_SCHEMES: {
    PRIMARY: 'primary-color',
    SECONDARY: 'secondary-color',
    BRAND: 'brand-color',
    FOCUS: 'focus-color',
    ACCENT: 'accent-color',
    LIGHT_BG: 'light-background-color',
    DARK_BG: 'dark-background-color',
    ERROR: 'error-color',
    SUCCESS: 'success-color',
    WARNING: 'warning-color',
  },
} as const;

/**
 * Default theme colors as RGB values
 */
export const DEFAULT_THEME = {
  'primary-color': '0, 122, 255',
  'brand-color': '64, 64, 64',
  'focus-color': '0, 95, 204',
  'accent-color': '255, 149, 0',
  'light-background-color': '242, 242, 247',
  'dark-background-color': '28, 28, 30',
  'error-color': '255, 59, 48',
  'success-color': '52, 199, 89',
  'warning-color': '255, 149, 0',
} as const;

/**
 * Groups of color schemes for the theme configuration UI
 */
export const COLOR_VARIANT_GROUPS = {
  PRIMARY: {
    title: 'Primary Colors',
    schemes: ['primary-color'],
  },
  SECONDARY: {
    title: 'Secondary Colors',
    schemes: ['secondary-color'],
  },
  ACCENT: {
    title: 'Accent Colors',
    schemes: ['accent-color'],
  },
  BACKGROUND: {
    title: 'Background Colors',
    schemes: ['light-background-color', 'dark-background-color'],
  },
  STATUS: {
    title: 'Status Colors',
    schemes: ['error-color', 'success-color', 'warning-color'],
  },
} as const;
```

### 10. Page Implementation

#### theme.tsx
```tsx
import { ThemeConfigView } from 'Views/Admin/Dashboard/Theme/ThemeConfigView';

/**
 * Theme configuration page component
 */
export default function ThemePage() {
  return <ThemeConfigView />;
}
```

#### theme-preview.tsx
```tsx
import { ThemeView } from 'Views/Admin/Dashboard/Theme/ThemeView';

/**
 * Theme preview page component
 */
export default function ThemePreviewPage() {
  return <ThemeView />;
}
```

## CSS Guidelines

- Use CSS modules for component-specific styling
- Use descriptive class names that indicate the component and purpose
- Use CSS variables for theme colors following the format: `--color-name`
- Create variations using the format: `--color-name-variant`
- Group related CSS properties and keep a consistent order
- Use responsive design principles for all components

## Storage/State Management

- Use session storage for persisting theme settings between page refreshes
- Use the ThemeProvider context for sharing theme state across components
- Update CSS variables in real-time as colors change
- Use memoization with useMemo and useCallback to prevent unnecessary re-renders
- Follow the unidirectional data flow pattern

## Improvements Over Current Implementation

1. Consistent prop type naming (TProps)
2. No separate type files where not needed - types and components stay together
3. Proper organization of components and subcomponents
4. Simplified code with cleaner syntax
5. Consistent use of CSS variables
6. Better folder structure following project conventions
7. Improved type safety
8. More efficient rendering with better callback and memo usage
9. Improved documentation for components and types
10. Better state management with proper dependencies in hooks

## Storybook Integration

To ensure the theme feature can be tested in storybook:

1. Create a copy of ExamplePage in the Docs/Stories directory
2. Add stories for Theme components in the Docs/Stories/Themes directory
3. Ensure the storybook examples use the same theme provider and variables
4. Create documentation for theme components in Storybook
5. Add controls for adjusting theme values in Storybook

## Testing

Add appropriate unit tests for:
1. Theme color utilities
2. Theme hook behaviors
3. Component rendering with different theme values

```css
.logoSection {
  margin: 2rem 0;
  padding: 2rem;
  background: rgb(var(--light-background-color));
  border-radius: var(--border-radius);
}

.logoSection h2 {
  margin-bottom: 1.5rem;
  color: rgb(var(--primary-color-text));
}

.uploadBox {
  max-width: 300px;
}

.currentLogo {
  max-width: 300px;
}

.currentLogo h4 {
  margin-bottom: 1rem;
  color: rgb(var(--primary-color-text));
}
```
