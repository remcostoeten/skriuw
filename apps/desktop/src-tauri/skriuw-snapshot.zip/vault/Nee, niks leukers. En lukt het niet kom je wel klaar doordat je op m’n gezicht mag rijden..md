---
id: "0ac132c653384161bc06c2ae3ed1207a"
tags: []
sortOrder: 141
preferredEditorMode: "block"
createdAt: 1741574251381
modifiedAt: 1741578366426
---
Nee, niks leukers. En lukt het niet kom je wel klaar doordat je op m’n gezicht mag rijden.

En anders is een relatief grote kans wanneer je doggy geneukt wordt of keihard cowgirl  kijk vorm van en dikte/vrij grote lengte je er vooralsnog kletsnat en trillend vanaf komt.

Staat wel tegenover dat jij op mijn gezicht is dat je tegen het einde ook gehoorzaal op je knietjes moet zitten 👅l lijk