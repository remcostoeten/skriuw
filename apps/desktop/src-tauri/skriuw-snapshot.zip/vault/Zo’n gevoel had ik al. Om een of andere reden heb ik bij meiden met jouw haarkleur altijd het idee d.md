---
id: "fb479f23b62f43f5afdf6ab0dcded8fe"
tags: []
sortOrder: 285
preferredEditorMode: "block"
createdAt: 1681776578803
modifiedAt: 1681779903834
---
Zo’n gevoel had ik al. Om een of andere reden heb ik bij meiden met jouw haarkleur altijd het idee dat ze stiekem smerig pijpen of onder gespoten willen worden 🫢

En de mijne, ik wou tot m’n huwelijk maagd blijven maar dat is helaas niet gelukt. Ik heb van horen zeggen dat ik wel goed kan beffen, en zo voelt het ook 🤪w op