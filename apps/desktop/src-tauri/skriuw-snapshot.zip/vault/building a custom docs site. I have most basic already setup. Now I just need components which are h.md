---
id: "b1b0e5b0a7aa4974bccbe362a4bb818f"
tags: []
sortOrder: 192
preferredEditorMode: "block"
createdAt: 1731467609010
modifiedAt: 1731468154717
---
building a custom docs site. I have most basic already setup. Now I just need components which are highly reusable.

Add here strictly to the following requirements:

- SOLID
- Seperste of concerns
- Tailwind, possibly shad n, framed motion  only allowed package wise
- kbab case
- All filed will go in the same shared/xxx/ dir
- Focus on the design but also implement light theme 
- Type perfectly, also with JSDOC Strings 
- Amimate oh so slightly.

You’re tasked to build the component from the screenshot. It is a big visual representation of props/tyles/interfsces 

The reusable api should allow to set a title which is the big heading.
- a name which is the badge. 
- A type which is enum behind the badge
- Optional required prop
- Description prop
- optional allowed values prop Boolean which fenders that text
- Then an array of Allowed values rendered inside those badges 
- Then a divider
- Then the filter design where u see the badge provider_user_id which is , I imagine when I click on a value extra information.

Make sure it looks like the screenshot. I attached close up details. 

Make sure it is reusable in slof of scenarios 