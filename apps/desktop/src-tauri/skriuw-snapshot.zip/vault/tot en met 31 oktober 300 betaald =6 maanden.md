---
id: "e301de72-00b0-49d3-ab19-95789972f904"
tags: []
sortOrder: 323
preferredEditorMode: "raw"
createdAt: 1672086480618
modifiedAt: 1672086732593
---
 tot en met 31 oktober 300 betaald =6 maanden
6e maand +50

1 -50 40
2-50 80
3-50 120 
4-50 160 
5-50 200
6-50  +50 240
7 - 50 280 
8 - 50 + 50 = 0 320
9 - 40 - 50 360 


490 390