---
id: "5173d5b9-1a12-421c-8931-50ee43d67a43"
tags: []
sortOrder: 363
preferredEditorMode: "raw"
createdAt: 1653682368032
modifiedAt: 1660090939012
---
Brave wallet recovery phrases
Write down or copy these words in the exact order shown below, and save them somewhere safe. Your recovery phrase is the only way to regain account access in case of forgotten password, lost or stolen device, or you want to switch wallets.
WARNING: Never share your recovery phrase.
Anyone with this phrase can take your assets forever.
1. spring
2. chat
3. bench
4. develop
5. awake
6. soup
7. neutral
8. grocery
9. hub
10. supreme
11. tip
12. mask
Copy
I have backed up my phrase somew



spring chat bench develop awake soup neutral grocery hub supreme tip mask