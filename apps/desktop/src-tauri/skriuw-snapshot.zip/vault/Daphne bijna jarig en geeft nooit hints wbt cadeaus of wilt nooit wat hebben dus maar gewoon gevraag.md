---
id: "4c7db4da-ff37-4b03-ab9d-d6a9f85450ca"
tags: []
sortOrder: 349
preferredEditorMode: "raw"
createdAt: 1663275269535
modifiedAt: 1663275702946
---
Daphne bijna jarig en geeft nooit hints wbt cadeaus of wilt nooit wat hebben dus maar gewoon gevraagd en toen gaf ze ringen, paar opties maar liet wel merken dat die linker mooiste vond,., is alleen maar 34 euro dus vind dat zo lame aanvoelen Laatst wou ze hier een of twee boeken bestellen maar toen deed ideal het niet ofzo en weet dat ze nu nog niet heeft gehaald.

 Laatst wou ze hier een of twee boeken bestellen maar toen deed ideal het niet ofzo en weet dat ze nu nog niet heeft gehaald.