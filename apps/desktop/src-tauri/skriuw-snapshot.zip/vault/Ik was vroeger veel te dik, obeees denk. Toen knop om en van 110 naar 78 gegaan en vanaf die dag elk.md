---
id: "2a3b4e12-9927-44f1-9d9d-600b861d185e"
tags: []
sortOrder: 266
preferredEditorMode: "raw"
createdAt: 1686677102715
modifiedAt: 1686677254983
---
Ik was vroeger veel te dik, obeees denk. Toen knop om en van 110 naar 78 gegaan en vanaf die dag elke keer stuk serieuzer sporten, beetje tot autistisch aan toe dat ik al jaren niet meer met ouders mee at en elke dag m'n voeding bijhield etc. Leefde in. principe voor dike sport, maar toen met corona ineens van een op de andere dag  viel m'n weekbesteding(sport) en weekend (fissas) weg.

Na lockdowns wel geweest uiteraard maar toen kwam een periode met prive veel opstapelingen. Toxic werkgever / tegen burn out aan zitten, relatie die kut was en  achteraf best veel dingen veroorzaakt hebben in m'n hoofd, medicatie die ik aan het afbouwen was die neveneffecten gaven en m'n moeder is een jaar terug overleden. Dat is. In principe alles wat me bezig hikeld in m'n leven viel weg. Toen m'n moeder overleed was 
de eerste week ooit sinds m'n 18e dat ik niet geweest ben en sindsdien gewoon niet meer gegaan, eigenlijk misde ik het eerst niet maar vooral iets wat me tegenhoudt is het gevoell dat ik me moet verantwoorden waarom ik niet geweest ben, waarom ik dik 20kg afgevallen. Beetje ons kent ons angst en vooral anxiety. Volg die sport nog wel echt elke dag en heb nul minder passie maar idk