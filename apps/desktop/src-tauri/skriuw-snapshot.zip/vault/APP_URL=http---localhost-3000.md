---
id: "24b77cd6-e631-4ebf-ad71-5c747146212b"
tags: []
sortOrder: 166
preferredEditorMode: "raw"
createdAt: 1735405116181
modifiedAt: 1735405116605
---
APP_URL=http://localhost:3000

# Database - Turso.tech
DATABASE_URL=libsql://zsh-config-builder-dev-remcostoeten.turso.io
DATABASE_AUTH_TOKEN=eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.eyJhIjoicnciLCJpYXQiOjE3MzUzNTMxNzUsImlkIjoiMjQ3YWE1NDEtYWM0OS00NmE2LWE4NDAtYzk0MzQ2NzdmZTlmIn0.WLoULb1UcawPO6-z23437lEZZsG7qOxgeMeULSkSQCDWR8Uj2VAHyoQonGVMif5ijssAFBIr2VudD0BeaLLYDQ

# GitHub OAuth
GITHUB_CLIENT_ID=Ov23liUKrB6teZm1YAig
GITHUB_CLIENT_SECRET=59f5e6f26b53f1b85fe65071e4543dd7e03dacc6

# Misc
ADMIN_EMAIL=remcostoeten@hotmail.com