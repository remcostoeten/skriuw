---
id: "74496c2e-0bf0-488a-b8ca-dabcb8346266"
tags: []
sortOrder: 275
preferredEditorMode: "raw"
createdAt: 1684610328663
modifiedAt: 1684610332665
---
https://chat.openai.com/?model=text-davinci-002-render-sha

I have a component in NextJS where a div follows my cursor. That is made like this:a
