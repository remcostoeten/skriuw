---
id: "f7325e9b-bf80-44fd-9e61-b264c1c1efc4"
tags: []
sortOrder: 318
preferredEditorMode: "raw"
createdAt: 1674922801690
modifiedAt: 1674922892252
---
Gister stelde je komende vrijdag voor wat maybe wat is, voor m'n gevoel nog lichtjaren weg :joy: maar qua planning wel goed. Zat er ook nog over na te denken maar waar ik zo van baal is dat we voor m'n gevoel eigenlijk niet echt gepraat hebben en alleen verdrietig zijn geweest