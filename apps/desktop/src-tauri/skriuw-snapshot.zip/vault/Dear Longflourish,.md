---
id: "3e4efd70-0d7d-4c58-a9ab-0d7075a2ba01"
tags: []
sortOrder: 367
preferredEditorMode: "raw"
createdAt: 1659518716930
modifiedAt: 1659519609603
---
Dear Longflourish,

On 23th of martch I've placed an order containing 5 grams of 25b-NBOH at your webshop. I paid through BTC and the package was supposedly shipped the day after. Yet to this date I have not received any package. This is regarding ordernumber 22032305180315 *(check dit zelf nog even)*.

I have bought multiple times at your webshop and also have fowarded quite some connections to your shop so I find it a bit strange that this package seemed to be lost. I have not received a love letter or notification from customs. Tracking: 02655043890927

Quite bummed out since we we're thriled to finally aquire 25b-NBOH which for some reason no one seems to stock in Europe. Shipping to NL shouldn't be any problem since we've done it multiple times, also with other wholesalers.  Especially since we've asked for smaller QTY's but you we're only willing to sell 5g minimum. If I would've gotten a letter from customs than it would be less of a problem, but now it just seems liket here hasn't been shipped anything.

I've fowarded quite some customers to your shop and waited long enough to conclude the package isn't comming. I hope you can reship the package, or if the 25b-NBOH isn't in stock at least pay me back. If you don't want to do a full reship I would agree with shipping 75% off the initial five grams. I hope we can fix this order, I will place a proper review once the reship is done. Same goes for if you won't, i'll make sure to place reviews on all the fora/review sites explaining no service being given and also no package being deliverd.

I guess i'll se e the new  tracking. Thanks in advance and have a nice day,

Albert