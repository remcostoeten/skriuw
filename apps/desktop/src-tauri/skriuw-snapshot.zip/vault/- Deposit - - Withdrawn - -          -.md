---
id: "255c12a3-c690-49f7-a9b2-c2219093d5a9"
tags: []
sortOrder: 243
preferredEditorMode: "raw"
createdAt: 1699754961577
modifiedAt: 1699755168614
---
| Deposit | | Withdrawn | |          |
|---------|-|------------|-|----------|
|   25    | |     -      | |    75    |
|   50    | |     -      | |    25    |
|    25    | |     -      | |    25    |
