---
id: "8e2144d4-31f0-4424-803b-8287f725a7db"
tags: []
sortOrder: 427
preferredEditorMode: "raw"
createdAt: 1640031152934
modifiedAt: 1640031733023
---
Ik heb een browser extension gemaakt die op bybit (crypto exchange) btc waardes via een api omzet naar realtime dollar waardes. Je hebt een pagina genaamd PNL waar je winsten staan, hier werkt het prima. Aan de rechter kant zie je een kolom met dollars, die komt door mijn extension.
https://gyazo.com/5f46f86a787ae77da1a31bc708fb04ae

Nu wil ik dit alleen nog werkend hebben als je in een trade zit. Dan staat er: "your estimated profit wil be xxx btc" en daaronder wil ik dan een regel met xxx btc = xx dollar. Het probleem is is dat die popup (waar die estimated in zit) pas geladen wordt in de DOM nadat je er op klikt. Van wat ik begrepen hebt moet dat met mutation observer, maar daar kom ik dus niet uit.

Dit is de URL waar ik hem werkend wil hebben (kan je helaas alleen zien als je in een trade zit: https://www.bybit.com/trade/inverse/BTCUSD
Dit is de DOM hoe hij eruit ziet als je in een trade zit. Aan de rechter kant zie je een <strong> tag die ik er zelf ff neer had gezet. En daar wil ik dus de dollar value zoals ik in eerste screenshot heb gemaakt. Dus via regex die btc value scrapen en dan omzetten middels die api. Al die logicia is al klaar in init.js voor andere pagina, maar nu moet je hem dus opnieuw aanmaken en dan inladen na een mutation obeserver (als ik het zo goed zeg).

Foldertje downloaden. Chrome/brave extensions -> developer modus aan -> load unpacked en dan mapje aanklikken en dan werkt hij.
https://github.com/remcostoeten/btc-to-dollar-browser-extension

Je hebt eventueel testnet waar je traden kan oefenen (of in dit geval testen als de DOM hetzelfde is https://testnet.bybit.com/trade/inverse/BTCUS
Als je in een trade zit zie je linksonder positions, en dan kan je op take profit/stoploss zitten en dan krijg je dat scherm van m'n tweede Gyazo link