---
id: "05efb756-7cf6-4a54-a13e-3608e98c4d21"
tags: []
sortOrder: 329
preferredEditorMode: "raw"
createdAt: 1668703076841
modifiedAt: 1668704549454
---
Kpn modem inloggen
192.168.2.254
Old password:
M2d]U9f}s3

New password:
Kotter128531cs!

Wifi naam:
Kotter 12

Wachtwoord
Kotter128531cs