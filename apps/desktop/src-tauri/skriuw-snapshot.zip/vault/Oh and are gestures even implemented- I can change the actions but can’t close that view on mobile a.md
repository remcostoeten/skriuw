---
id: "d94b328ac6c04d8e89a45f628855a0f4"
tags: []
sortOrder: 47
preferredEditorMode: "raw"
createdAt: 1763524659418
modifiedAt: 1763524711062
---
Oh and are gestures even implemented? I can change the actions but can’t close that view on mobile and none of them seem to work? Or should they? Im on iPhone 13