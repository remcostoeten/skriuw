---
id: "e7b97759-5b63-4278-b6da-f601e8b0cdb6"
tags: []
sortOrder: 258
preferredEditorMode: "raw"
createdAt: 1690665681485
modifiedAt: 1690665682150
---
NEXT_PUBLIC_PASSWORD=Mhca6r4g1!257Wds4k

# -----------------------------------------------------------------------------
# App
# -----------------------------------------------------------------------------
NEXT_PUBLIC_APP_URL=http://localhost:3000

# -----------------------------------------------------------------------------
# Authentication (NextAuth.js)
# -----------------------------------------------------------------------------
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=ob7xIBiRgB1KUZKnUL7DcNh2LbUx1gwOCEeRtkOVeKY

GITHUB_CLIENT_ID=88381add49504fb02745
GITHUB_CLIENT_SECRET=d83cc4cbffdff4be3aae767192e288809deefc32 
GITHUB_ACCESS_TOKEN=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

# -----------------------------------------------------------------------------
# Database (MySQL - PlanetScale)
# -----------------------------------------------------------------------------
DATABASE_URL='mysql://yn31v67jknngbqxh7ld0:pscale_pw_8FNOIRsjUhchTAA2IgZ2xWdjInsQ1uc4YYixeWNQCK2@aws.connect.psdb.cloud/remcostoeten?sslaccept=strict'

# -----------------------------------------------------------------------------
# Email (Postmark)
# -----------------------------------------------------------------------------
SMTP_FROM=1
POSTMARK_API_TOKEN=1
POSTMARK_SIGN_IN_TEMPLATE=1
POSTMARK_ACTIVATION_TEMPLATE=1

# -----------------------------------------------------------------------------
# Subscriptions (Stripe)
# -----------------------------------------------------------------------------
STRIPE_API_KEY=1
STRIPE_WEBHOOK_SECRET=1
STRIPE_PRO_MONTHLY_PLAN_ID=1