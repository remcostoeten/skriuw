---
id: "286e8471-7739-4bb0-91b5-a3a7677d8d47"
tags: []
sortOrder: 54
preferredEditorMode: "raw"
createdAt: 1762218886111
modifiedAt: 1762219113537
---
DISPLAY= /opt/google/chrome-remote-desktop/start-host --code="4/0Ab32j93-5RoNbpAwZfqByAtqp0vhJW3QuBSzGlxRn1rG--jB04QRs6Eo36gutBCl8ywMxw" --redirect-url="https://remotedesktop.google.com/_/oauthredirect" --name=$(hostname)


https://dl.google.com/linux/direct/chrome-remote-desktop_current_amd64.deb