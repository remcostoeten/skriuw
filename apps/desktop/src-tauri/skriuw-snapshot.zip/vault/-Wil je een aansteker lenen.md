---
id: "38a0fcdb-d242-4e93-914d-96a5e397b7c0"
tags: []
sortOrder: 184
preferredEditorMode: "raw"
createdAt: 1706459485954
modifiedAt: 1733106424323
---
>Wil je een aansteker lenen
>Waar praten jullie over
<wie is dat?
>Homooo, je moeder
>remco je bent een homo
<laat die jongen met rust
>donder op bemoei je er niet mee
>doe je gordijnen open 
>open maken
- [ ] >open maken remco
- [ ] >hij woont met z'n vader
>neefje van valentijn
<Oh echt di remco??
>ja
< oh neeee
< stoeten
> rmeco woont daar helemaal niet
> jawel
> helmaal niet
< helemaal wel
x 10



> zn vader is een handelaar x10
< hou nou eens op
> zn vader is een handelaar..... (is hij niet)
> je moet je bed opmaken
> maak gewoon je bed op
> doe het raam open dan hoor je wat ik zeg (net dicht gedaan
>homoo

....

> remco je vader is er
> je vader is er 
> hij roept je
..

> je moeder is er
> je meoder is er 
> doe de deur gewoon open
> komop man


> de moeder van valentijn roept je (zus van mn mem) x 10 (zij komt soms met sleutel onaangekondigt binnen)
