---
id: "628e3652-e5ad-412f-b060-e9e4103c12cc"
tags: []
sortOrder: 121
preferredEditorMode: "raw"
createdAt: 1743639308686
modifiedAt: 1743639321880
---
dashboard https://v0.dev/chat/fork-of-dash-end-ntoficiation-21-40-zofLVPv8SkT?b=b_sZ5fRKDGaR2

working auth: jwtt