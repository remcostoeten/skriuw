---
id: "7a3ba80d0ec44d5aa7b3e5f061194d37"
tags: []
sortOrder: 205
preferredEditorMode: "block"
createdAt: 1728344964478
modifiedAt: 1728345234302
---
Can u make it so that on a single substance there is this option to hide it until your secret passcode  is filled in (use OOTP component from shadcn)

It should be totally blurred in the overview of that specific substance so also all the entry’s linked to that substance. Once. Passcode is filled in it’s free to view infill the hide btn is paclicked again 