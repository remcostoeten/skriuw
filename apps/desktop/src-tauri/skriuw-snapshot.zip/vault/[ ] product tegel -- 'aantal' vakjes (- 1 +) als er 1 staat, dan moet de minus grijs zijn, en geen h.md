---
id: "f7b4c6a2-684c-4e59-bd73-d7e3fbfe5c3c"
tags: []
sortOrder: 316
preferredEditorMode: "raw"
createdAt: 1675178438737
modifiedAt: 1675182289166
---
 [ ] product tegel -> 'aantal' vakjes (- 1 +) als er 1 staat, dan moet de minus grijs zijn, en geen hover erop. Je kan niet lager gaan dan 1.
 -Kan ik niet doen, bij Daniel neergelegd.

[x] product tegel -> categorie linkje (boven producttitel) en producttitel hebben underline bij hover, maar moet niet.
-Alle anchors hovers weg

[x ] - er mist cursor pointer op knopje 'Voeg toe aan winkelwagen'.
-Ik heb alle buttons cursor:pointer op hover gegeven.

[x] - breadcrumbs -> er zit underline op bij hover, moet niet.
done

[x]]- breadcrumbs -> current page, is die klikbaar? want dat moet niet, er zit cursor pointer op nu.
Gefixt. Op last child in de lijst pointer-events:none gezet.

[x]- pagina titel moet een h1 zijn, niet h2.

done

[x] - voor h1, h2 etc staat er font-family: "Open Sans-Bold", m......
Dit was alleen de titel die zo heette, echte font was Open Sans. Maar ik heb find en replace Open Sans Bold voor Open Sans gedaan in het hele project.

[x]- category brands -> 'Op zoek naar een merk' heeft nu een vaste width/height (nooit doen, wat als er andere tekst in moet? of moet wrappen op mobiel?). Weghalen en padding gebruiken.
-eens, fixed.

[x]- category brands -> blauwe border is nu 2px dik, maar moet 3px zijn.
done

[x] wise alle filters underline,
[x]- filter pill -> kruisje om de filter weg te klikken: er mist cursor pointer.
done

[x]- paginering: er mist border radius bij 'prev'.
Done, was al klaar overigens maar de class was uit de JS om een of andere reden.


[x]- paginering: waarom zijn er borders tussen de pagina's, design heeft ze niet.
Geen idee. fixed.

[]- paginering: current page -> moet geen border hebben, alleen blauwe achtergrond, ziet er raar uit, wazig.
?


[x ]- paginering: hover -> er mist achtergrondkleur. Ook zou er geen grijze border-bottom moeten zijn, alleen de blauwe lijn.
Done, denk ik?

[x]- filters: als ze gewoon opengeklapt staan, moet pijltje toch andersom staan?
Correct. Fixed

[x] - filters: 'Toon meer' heeft underline bij hover, maar moet niet. 
Done.

[x]- filters: zoek naar zoekterm -> in het filmpje verschijnt de 'x' pas als je geen resultaten hebt. Maar moet verschijnen als je iets al typt. Je moet je zoekterm altijd kunnen weghalen.
Done.

[] kan je de dropdowns stylen
De select boxes bedoel je neem ik aan? Bij mij leken die prima, maar in Firefox is hij grijs zie ik inderdaad. Ik heb hem een bg-color: white gegeven.