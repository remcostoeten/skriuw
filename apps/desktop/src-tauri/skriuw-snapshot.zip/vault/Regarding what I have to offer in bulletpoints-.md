---
id: "af61ff9e93004f998480209e0918510e"
tags: []
sortOrder: 9
preferredEditorMode: "raw"
createdAt: 1776862503780
modifiedAt: 1776862901857
---
Regarding what I have to offer in bulletpoints:
- a Frontend engineer with a degree in graphic design and good feeling for UX/Ui and have worked with government accessibility requirements 
- A very eager and enthousastic colleague who loves sharing tech and find discussions, brainstorming regarding architecture choices fun. I stay up to date with all the latest tech, wether it’s frameworks or ai. I test them out as a hobby and if I see potential I share it with colleagues 
- Not shy to involve myself in discussions and present certain ideas, but humble enough to not be triggered if my choice is not the one we pick.
- having worked fulltime in officie at an agency, years of 100% remote and autonomic for large scale enterprise and open source government as well as small hybrid themes
- Main priority is Frontend but Very willing to keep evolving in a backend stack and infra/cloud/ops