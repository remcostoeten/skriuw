---
id: "f67f1800af184997b44a56e8f6346325"
tags: []
sortOrder: 207
preferredEditorMode: "block"
createdAt: 1727590110920
modifiedAt: 1727591133254
---
Ai prompt: reusable server action & form:

I want a reusable, scalable, efficient, easy in use, good DX, logic, quick to develop form component and served action which prevents me from having to recreate actions and forms that look a like very much

## Tech:

-Nextjs 15
-React 19 (hooks like “use” “useTransition” “useoptimistic”) prevent usage of unecisarry use effects.
-Tailwinds CSS
-Server actions only, no API-routes. Exempt if a very good reason
-Drizzle orm with PostgreSQL (Neon)
-Lucia authentication with sessions
-Framed motion if needs 
-Zustand if needed
-Shadcn.  I have an alias called ui which links to ui/index.ts so u can import all shading domponents in  1 line from. ‘Ui’
zod
React hook form 
## ui

Dark, black pure theme like vervel or resend.com. Not dark blue, way darker.
Modern clean aesthetic UI

## Code style:

-Try to utilize SSR with pre skeleton loaders and spinners. Try to keep client components at a minimum .
-Checking auth Lucia session needs headers which won’t work in a client component.
-Use newest hooks from latest react updates 
-prevent usage of use effect only if no other options 
-revalidatie the page instantly after update without refreshing
-use types, not interfaces
-use functions where possible instead of const.
-make use of seperate of concerns. Small single usage files.
Use kebab style file convention 
Co-locate components directly related to the feature next to its page.tsx in a _components folders 
-use types instead of interfaces. If there are alof of types in the feature consider a feature.types.d.ts file

## Folded structure ;

Like I said shadcn imported from ui

. 

- FEATURE/page.tsx
- FEATURE/_components (co-locate components 
-Feature/utils if needed

-Src/core/hooks if needed
-Server actions are exported:  ‘into src/core/server/actions/index.ts’
But are written individually into ‘src/core/server/actions/FEATURE/action-name.ts’
Each ‘actions/FEATURE’ has an ‘index.ts’ which exports all files in its own directory so we can export the ‘index.ts’ to the alias index.ts in ‘src/core/server/actions/index.ts’

-Server actions must prefix with “use server” and contain adequate error handling. All Errors and success messages must be able to be translated into a Toast (we use Sonner).

into src/core/server/actions/Feature/index.ts and export in there, which we then export in the actions/index.ts

## import aliases: 
-shadcn index.ts exports all components and I made tsconcig alias to that index.ts called “ui”
-Any zustnax store can be imported from “stores”
-All server actions are imported from “actions” which links to src/core/server/actions/index.ts
-Db can be imported from “db”
-Schema can be imported from “db”
<Flex> can be imported from @/components/atoms/Flex (<flex dir=col gap=10 justify=between etc)
-Hooks are src/core/hooks
-Lucia with is src/lib/auth/lucia.ts

## Feature:

## reusable server action
      - must be a modular. Scalable server action that can be re-used in many scenarios
      -  it should be able to submit any data to an database (drizzle orm, postgress)

## reusable form
    - data must be posted  through only <form acfion={server action)
    -the component should allow to post input field dafa
    -the component should allow to post text area data
    -the component should allow to post checkbox data 
    -the component should allow to post select option data (shadcn)
    - the component should allow to post input data 
    - The component should allow a image ddopzome
    - The component should gather used id id possible
    - created at
    - Option for uuid
    - show toast on submit
    - 
## feature two 
        -  consistsoff
        -  consistsoff
## feature three
        - consistsoff
        - consistsoff

