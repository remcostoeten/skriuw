---
id: "df298ff7-fd36-43ee-8e77-73d518d73da2"
tags: []
sortOrder: 29
preferredEditorMode: "block"
createdAt: 1768630028089
modifiedAt: 1768630028679
---
https://lovable.dev/projects/6a8588a6-b78a-4e2e-a81f-fd327caaaa05