---
id: "b7c773e80603473892cecd56f4886545"
tags: []
sortOrder: 123
preferredEditorMode: "block"
createdAt: 1741948253548
modifiedAt: 1743373675983
---
Sorry dat ik er niet meer op terug ben gekomen. Maar ik heb dit tegen niemand verteld omdat ik iedereen probeer te ontloepn, maar heb jaar terug dat gok fisco gehad toch, nou laatst veel gezeur, stress enzo en toen toch weer laten gaan met als gevolg.. je kan het werl raden. Ik heb me nu wel voor het leven uitgeschreven maar het is gewoon beschamend en ik kan niks, hele tijd excuusjes zien te verzinnen om op werk te kunnen komen (of beter gezegd niet kan komen door benzine). Telefoon die het niet meer doet blabla. Was ook de reden dat ik wel wat wou doen maar het gewoon niet kan betalen tot ik loon heb en het gewoon kut is omdat ik hier thuis er niet echt mee kan aankloppen en anderen me ook weer aan zien komen.

Weet niet zo goed wat jij er mee moet maar ergens heb ik het idee dat jij itt tot anderen me niet zwart maakt en alleen maar verder de grond in trappen 

