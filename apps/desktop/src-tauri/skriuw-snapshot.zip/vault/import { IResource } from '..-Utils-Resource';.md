---
id: "075186d0-8dba-4327-a68b-d0015e6f77ca"
tags: []
sortOrder: 96
preferredEditorMode: "raw"
createdAt: 1750247559774
modifiedAt: 1750248930544
---
import { IResource } from '../Utils/Resource';
import { Account } from './Account';
import { Answer } from './Answer';
import { AnswerFeedback } from './AnswerFeedback';
import { Comment } from './Comment';
import { Shareable } from './Shareable';

export interface Activity extends IResource<'activities'> {
    activityAt: string;
    timeAt: string;
    source?: () => AnswerFeedback | Answer | Comment | Shareable;
    causer?: () => Account;
    reactions?: () => Comment[];
}

export interface ActivityCreateInput {
    activity_at?: string;
    time_at?: string;
    relationships?: {
        source: { id: string; type: string };
        causer: { id: string; type: string };
        reactions?: Array<{ id: string; type: string }>;
    };
}

export interface ActivityUpdateInput extends Partial<ActivityCreateInput> { }

export enum ActivityIncludes {
    'source',
    'causer',
    'reactions',
    'source.account',
    'reactions.account',
}

export interface ActivityFilters {
    enrollment?: string;
    learning_object?: string;
    concept?: boolean;
}

export enum ActivitySorts {
    'activity_at',
    'time_at',
    'created_at',
}
