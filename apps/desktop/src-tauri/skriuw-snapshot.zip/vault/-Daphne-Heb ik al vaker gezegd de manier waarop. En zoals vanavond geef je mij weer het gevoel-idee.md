---
id: "f2d4bdcd-6477-453e-a019-b12ab3500348"
tags: []
sortOrder: 351
preferredEditorMode: "raw"
createdAt: 1662668525882
modifiedAt: 1662674466378
---
*Daphne*Heb ik al vaker gezegd de manier waarop. En zoals vanavond geef je mij weer het gevoel/idee dat ik fout zit door de manier hoe je het brengt en het omdraait

->Drie vragen
    -Maar in hoeverre is jou het een gevoel geven rechtvaardig om ruzie te maken? Denk eens vanaf het begin     over de situatie na en vervang stufi dan voor wat anders
    -En dan is nu het enige wat gezegd is vanuit mijn kant: Ik heb ook die studiregeling gehad. 

Als dat al genoeg is om jou het gevoel te geven dat ik alles naar mezelf trek en jij overal de schuld van krijg. Waar ligt dan de grens in wat ik wel en niet kan doen? Ik vroeg het je zonet en antwoord nooit op de vraag hoe ik het anders had moeten doen. Ik hoor alleen: "De manier waarop en het voelt voor mij

-Waar ligt de grens van wat ik wel kan zeggen zonder jou te triggeren of het gevoel te
geven dat jij het niet goed doet? (In dit geval had ik de grens al overscheden met te
zeggen dat ik ook een studiefinanciering heb gehad blijkbaar)

Aanvulling:
Wat kan ik wel zeggen en wat niet?

 -Hoeverre is het rechtvaardig om boos te worden op de ander door een manier hoe je wat
 opvat/(wat als je het aan een buitenstaander laat lezen diegene het op geen enkele
 manier zo kan opvatten). 

 -Wat zou jij ervan vinden als ik wat vertel en jij vertelt tijdens het verhaal een zin
 over je eigen ervaring waarop ik vervolgens pissig word? Heel simpel voporbeeld was "ik
 heb ook slecht geslapen" Het is rechtvaardig als ik vanaf nu elke ochtend boos word
 omdat jij het zelfde geslapen hebt als mij?

Moeite voor elkaar doen. 


En ik neem aan dat je nu na een nacht slapen wel een keer eerlijk m’n vragen kan reageren in plaats van altijd te zeggen ik ga slapen, reageer morgen om vervolgens dat niet te doen op mijn vragen. Zo ging dat de laatste ruzies iig. d