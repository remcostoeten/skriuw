---
id: "023b9f87-01ce-4005-90c6-a20a9926bc38"
tags: []
sortOrder: 103
preferredEditorMode: "raw"
createdAt: 1748214713810
modifiedAt: 1748215643223
---
sudo mv /Users/remcostoeten /Users/oldremcostoeten && sudo dscl . -change /Users/remcostoeten RecordName remcostoeten oldremcostoeten && sudo dscl . -change /Users/oldremcostoeten NFSHomeDirectory /Users/remcostoeten /Users/oldremcostoeten


dscl . -read /Users/oldremcostoeten | grep -E 'RecordName|NFSHomeDirectory'


https://icons.pqoqubbw.dev/