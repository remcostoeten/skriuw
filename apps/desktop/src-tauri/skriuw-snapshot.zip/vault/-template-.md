---
id: "fbbaf064-b5e1-4ce4-ad69-3052ff74a1fe"
tags: []
sortOrder: 173
preferredEditorMode: "raw"
createdAt: 1734514365170
modifiedAt: 1734514742435
---
<template>
    <div
        class="employee-planning-action-bar"
        :class="{sticky: sticky}"
        :style="{top: sticky ? `${stickyTopHeight}px` : 'auto'}"
    >
        <a-button
            @click="$emit('go-to-today')"
            :label="$t('calendar.go_to_today')"
            type="cta-tertiary"
            :disabled="disabled"
        />
        <div class="filter-header-divider-container" />
        <div class="employee-planning-action-bar-content">
            <employee-planning-view-select
                :value="planningView"
                @input="changeView"
                :show-day-week-view="true"
                :disabled="disabled"
            />
            <a-button
                :disabled="disabled"
                type="cta-secondary"
                @click="$emit('previous')"
                @click.stop=""
                icon-name="chevron-left"
                text-color="var(--a-fg-color)"
            />

            <a-input-group
                style="width: 240px; max-width: 240px"
            >
                <a-input-date-picker
                    :date-label-format-options.prop="dateDisplayFormat"
                    :value="startDateString"
                    hide-icon
                />
                <a-input-date-picker
                    :date-label-format-options.prop="dateDisplayFormat"
                    :value="endDateString"
                    icon-name="calendar-range"
                />
            </a-input-group>

            <a-button
                :disabled="disabled"
                type="cta-secondary"
                @click="$emit('next')"
                @click.stop=""
                icon-name="chevron-right"
                text-color="var(--a-fg-color)"
            />
            <a-button
                type="cta-secondary"
                :disabled="disableZoomIn || disabled"
                @click="$emit('zoom-in')"
                @click.stop=""
                icon-name="magnifying-glass-minus"
                text-color="var(--a-fg-color)"
            />
            <a-button
                type="cta-secondary"
                :disabled="disableZoomOut || disabled"
                @click="$emit('zoom-out')"
                @click.stop=""
                icon-name="magnifying-glass-plus"
                text-color="var(--a-fg-color)"
            />
        </div>
        <div class="filter-header-divider-container" />
        <a-button
            :disabled="disabled"
            type="cta-secondary"
            icon-name="arrows-rotate"
            @click="planningRefreshService.requestRefresh()"
            text-color="var(--a-fg-color)"
        />
        <employee-planning-export-dialog
            :disabled="disabled"
            @export="$emit('export');"
            :root-project="rootProject"
            :scheduler="scheduler"
        />

        <employee-planning-settings-dialog
            :disabled="disabled"
            ref="planning-settings"
            @change="onSettingsChange"
            @apply-settings-to-scheduler="$emit('apply-settings-to-scheduler')"
        />

        <div class="filter-header-divider-container" />
        <a-button
            :disabled="disabled"
            type="cta-primary"
            :label="$t('plan.new_planitem')"
            @click="$emit('create-planitem')"
        />
    </div>
</template>

<script lang="ts">
import type {Project}                        from '@/types/heimdall';
import {VueComponent, Component, Prop}       from '@/VueComponent';
import BryntumScheduler                      from '@frontend/components/Planning/BryntumScheduler.vue';
import EmployeePlanningExportDialog          from '@frontend/pages/planning-employee-bryntum/components/EmployeePlanningExportDialog.vue';
import EmployeePlanningViewSelect            from './EmployeePlanningViewSelect.vue';
import {Inject}                              from '@b7/simple-inject-lib';
import {PlanningRefreshService}              from '@frontend/components/Planning/Common/PlanningRefreshService';
import {TUserLinkParameters}                 from '@frontend/common/user-parameters/TUserLinkParameters';
import EmployeePlanningSettingsDialog
    from '@frontend/pages/planning-employee-bryntum/views/vue/planningSettings/EmployeePlanningSettingsDialog.vue';
import {PlanningViewTypeEnum}                from '@frontend/common/enums/PlanningViewTypeEnum';

@Component({
    components: {
        EmployeePlanningSettingsDialog,
        EmployeePlanningExportDialog, EmployeePlanningViewSelect},
})
export default class EmployeePlanningActionBar extends VueComponent
{
    @Inject private readonly planningRefreshService: PlanningRefreshService;

    @Prop({required: true})
    public readonly planningView: string;

    @Prop({default: null})
    public scheduler: BryntumScheduler;

    @Prop({default: false})
    public disabled: boolean;

    @Prop({default: false})
    public disableZoomIn: boolean;

    @Prop({default: false})
    public disableZoomOut: boolean;

    @Prop({default: true})
    public readonly sticky: boolean;

    @Prop({default: 0})
    public readonly stickyTopHeight: number;

    @Prop({default: null})
    public readonly rootProject: Project;

    private dateDisplayFormat: Intl.DateTimeFormatOptions = {
        day:   '2-digit',
        month: '2-digit',
        year:  'numeric',
    };

    private changeView(e: Event): void
    {
        const selectedView = (e.target as HTMLSelectElement).value;
        this.$emit('change-planning-view', selectedView);
        this.scheduler.planningView = selectedView as keyof typeof PlanningViewTypeEnum;
        this.scheduler.updateFillTicks();
    }

    private get startDateString(): string | null
    {
        return this.scheduler?.instance.startDate?.toLocaleDateString();
    }

    private get endDateString(): string | null
    {
        return this.scheduler?.instance.endDate?.toLocaleDateString();
    }

    private onSettingsChange(prev: TUserLinkParameters['PLANNING_EMPLOYEE']['SETTINGS'], cur: TUserLinkParameters['PLANNING_EMPLOYEE']['SETTINGS']): void
    {
        this.$emit('change-settings', cur);

        if (this.planningRefreshService.shouldSettingsChangeRequireRefresh(prev, cur)) {
            this.planningRefreshService.requestRefresh();
        }
    }
}
</script>

<style lang="scss" scoped>
.employee-planning-action-bar {
    display: flex;
    padding: 16px;
    border-top: 1px solid var(--a-border-input-color);
    gap: 10px;
    background-color: var(--a-panel-color);
    z-index: 7;

    &.sticky {
        position: sticky;
        top: auto;
    }

    .filter-header-divider-container {
        margin: 8px;
        width: 1px;
        background-color: var(--a-border-input-color);
    }

    .employee-planning-action-bar-content {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: inherit;
        flex-grow: 1;
    }
}
</style>
WARP