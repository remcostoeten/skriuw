---
id: "dedf01b3-4573-4d8b-a328-dba5ed17148c"
tags: []
sortOrder: 223
preferredEditorMode: "raw"
createdAt: 1719771258416
modifiedAt: 1720532808992
---
PLEIO IPHoNe 13 TELEFOON NUMMER
649825210

0649825210

Betreft mijn 16220 vintag rolex datejuist uit '88. Aanschaf bij Amsterdam Vintage watches. Zonder box & papers, wel het officiele aanschaf certificaat (met serie no. etc) geleverd vanuit AVW. Horloge is in principe identieke staat als toen ik hem kocht doordat ik thuis werk en hen nauwelijks droeg. Idealiter heb ik de aansschaf, maar ik snap dat de markt verandert is. Dus zakken is niet een probleem (tot zekere hoogte). Horloge is netjes, clasp heeft wat puntjes en that's it

Goedendag, Betreft een Roelx datejust 16220 uit Goedendag, Ik ben op zoek naar een eerlijke koper voor mijn 16620 uit 1988. Hij is kaal- als in geen box en papers, echter heb ik wel het originele aanschaf voucher(certificaat) die ik gekregen heb bij Amsterdam Vintage Watches. Het horloge heb ik daar dus ook zo'n vier jaar geleden gekocht. In principe is het horloge nog identieke staat als toen ik hem daar kocht aangezien ik