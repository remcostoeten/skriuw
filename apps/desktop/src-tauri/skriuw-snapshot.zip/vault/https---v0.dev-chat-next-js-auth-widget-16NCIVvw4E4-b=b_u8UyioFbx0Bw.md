---
id: "56f549ef-ebc6-424f-9b97-d9e2657eca80"
tags: []
sortOrder: 119
preferredEditorMode: "raw"
createdAt: 1742153512735
modifiedAt: 1745863349390
---
https://v0.dev/chat/next-js-auth-widget-16NCIVvw4E4?b=b_u8UyioFbx0Bw



supabase dashboard + fncs 
https://bolt.new/~/github-6lwe6ay1

Prompt tryout 
https://v0.dev/chat/custom-prompt-builder-BVx4yzlZLxZ

another prompt tryout??:
https://bolt.new/~/sb1-7jpbr3bc

https://v0.dev/chat/custom-prompt-builder-4W3qXditCz6?b=b_UsdaLkIrcQO


 Maybe have some miscelnaious options like

Asectionfile nameconvention whereu can piock
Kebab case,snakecase,pcamelcaseetc

SSR yes / no
seperate of concerns yes no 
if yes > How strong 

     EVEryfunctionmust be e 1 file for examplecould e a option

Do u wnatjsdoc/codcstirng yes no

if yes, fore everyfile yes  or no < or onlybusiness files

Howshould thedocstringlook (allow. template insertion)


DO u want apiroutes oronly server functions?

if serverfunctions pointthemto filetreetemplate w