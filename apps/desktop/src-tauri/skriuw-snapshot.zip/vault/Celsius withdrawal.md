---
id: "8cdb0c67-205f-4870-b58e-647b4a17b3cc"
tags: []
sortOrder: 426
preferredEditorMode: "raw"
createdAt: 1640739570750
modifiedAt: 1640739640321
---
Celsius withdrawal
ADA main: addr1vx7r3376zyahhgzq8k9gv26fnshkxe6z23ugxvrmn5uzjzc9jmd4x

BTC main: 
bc1qxew2ghaak7yem2z795g9uk7y2ed69uah6e7ck9

Usdt main:
0xA82511b3A42e3561E41aB11A0eB4d8206C465C6f

eth main
0xA82511b3A42e3561E41aB11A0eB4d8206C465C6f

bnb main
0x87451942616C46906857299420Fa0fA0404c0601