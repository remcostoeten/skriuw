---
id: "2713277d-f15e-4214-8496-f032f8ad271f"
tags: []
sortOrder: 398
preferredEditorMode: "raw"
createdAt: 1651870249995
modifiedAt: 1651931327763
---
D   Maar verder zijn er wel momenten dat ik/we er aan denken maar m'n vader en ik zijn beide gfewoon direct verder gegaan met werken en hobbys, ik ben m,n kamer al tijdje aan het verbouwen en m'n vader is veel naar de voetbal enzo. Klinkt misschien een beetje raar maar we vinden het wel goed zo, misschien ook omdat we er zo lang naat toe hebben geleefd dus eigenlijk wel heel goed. Wel kut nieuws gekregen dat m'n tante (vrouw van de broer van m'n vader) kanker zo groot als een ei in haar hersenen heeft dus dat is wat minder

En is goed :-p Straks met het mooie weer motor van stal moet dat vast een keer kunnen