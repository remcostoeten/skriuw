---
id: "96679f08-4874-4780-9b92-c074862396d3"
tags: []
sortOrder: 79
preferredEditorMode: "block"
createdAt: 1752336175119
modifiedAt: 1752340022255
---
cat .env
# Next.js
NEXT_PUBLIC_APP_URL=http://localhost:3005
NODE_ENV=development

# NextAuth Configuration
NEXTAUTH_URL=http://localhost:3005
NEXTAUTH_SECRET=your-nextauth-secret-key-here

# Database (Neon)
DATABASE_URL=postgresql://neondb_owner:npg_Jh84BewfICvD@ep-snowy-salad-adtgj7pi-pooler.c-2.us-east-1.aws.neon.tech/neondb?sslmode=require &
channel_binding=require
NEON_DATABASE_URL=postgresql://neondb_owner:npg_Jh84BewfICvD@ep-snowy-salad-adtgj7pi-pooler.c-2.us-east-1.aws.neon.tech/neondb?sslmode=require &
channel_binding=require

# Authentication Providers
# GitHub OAuth
GITHUB_ID=your-github-client-id
GITHUB_SECRET=your-github-client-secret

# Google OAuth
GOOGLE_ID=your-google-client-id
GOOGLE_SECRET=your-google-client-secret

# Email Configuration (Nodemailer)
EMAIL_SERVER_HOST=smtp.gmail.com
EMAIL_SERVER_PORT=587
EMAIL_SERVER_USER=your-email@gmail.com
EMAIL_SERVER_PASSWORD=your-app-password
EMAIL_FROM=your-email@gmail.com

# Optional: Additional Configuration
# Encryption key for sensitive data
ENCRYPTION_KEY=your-32-character-encryption-key-here

# API Keys (if needed)
# OPENAI_API_KEY=your-openai-api-key
# STRIPE_PUBLIC_KEY=your-stripe-public-key
# STRIPE_SECRET_KEY=your-stripe-secret-key

# Development/Debug
DEBUG=false
LOG_LEVEL=info