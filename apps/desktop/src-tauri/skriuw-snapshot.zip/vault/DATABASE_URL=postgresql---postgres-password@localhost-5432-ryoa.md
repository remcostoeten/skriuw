---
id: "e70cf64c-1ff0-43aa-b856-da37983f1ee2"
tags: []
sortOrder: 115
preferredEditorMode: "raw"
createdAt: 1746656270026
modifiedAt: 1746656270503
---
DATABASE_URL=postgresql://postgres:password@localhost:5432/ryoa


JWT_SECRET="replace_this_with_a_real_strong_secret_key"

# Admin Email (See hint in src/env/schema.ts)
# Uncomment and set if you want a default admin user on registration
ADMIN_EMAIL="remcostoeten@hotmail.com"

# REDIS_URL="redis://redis:6379"

# Node Environment (Usually set by Next.js automatically)
# NODE_ENV="development"


GEMINI_API_KEY=AIzaSyCmbWvqXXkYapOVDMn5XBskv1toOiBNJi8
