---
id: "d994aac8-8abe-4672-a2d5-7dc058ad7a3e"
tags: []
sortOrder: 299
preferredEditorMode: "raw"
createdAt: 1678985737160
modifiedAt: 1678986489692
---
Mja mss heb je ergens gelijk en zal er proberen te denken, doe het niet perse met opzet maar is nu al mss een jaar geleden dat ik oprechte aandacht heb gekregen van iemand terwijl ik eigenlijk afgelopen 8 jaar bijna non stop in rela heb gezeten waar alleen laatste jaar dan ik dat miste 

Kan me niet voorstellen dat jij daar geen behoefte aan zou hebben als je nu geen aandacht van anderen kreeg of in onze rela door mij de hemel in geprezen werd 


Idem voor waarom ik altijd zoveel wil praten of doorgaan, al helemaal omdat ik thuis ook niet meer kan praten, het ongelukkige voor jou is dan dat ik helaas geen alternatieven voor het oprapen heb :crazy:                  

Het is voor vrouwen gewoon compleet anders omdat het aan komt waaien en je als maar ego boost krijgt                                       