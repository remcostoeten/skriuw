---
id: "009b9e1c-3ed9-41a3-b710-5c3135a15d10"
tags: []
sortOrder: 98
preferredEditorMode: "raw"
createdAt: 1750237144710
modifiedAt: 1750242189210
---
import type { Meta, StoryObj } from '@storybook/react';
import {
  ActivityCard,
  ActivityRating,
  TActivityRatingProps,
} from './ActivityCard';
import styles from './ActivityCard.module.css';

const meta: Meta<typeof ActivityCard> = {
  title: 'Components/ActivityCard',
  component: ActivityCard,
  parameters: {
    layout: 'padded',
    docs: {
      description: {
        component:
          'ActivityCard component displays grading information with clean background colors. Cards use green backgrounds for success states and yellow backgrounds for warning states, with no borders for a clean, modern design.',
      },
    },
  },
  argTypes: {
    activity: {
      control: 'object',
    },
    description: {
      control: 'text',
    },
  },
};

export default meta;
type Story = StoryObj<typeof ActivityCard>;

const mockThread = {
  id: 'thread_1',
  type: 'assessment',
  resourceType: 'comment',
  commentableType: 'assessment',
  content: '',
  createdAt: '2023-12-01T10:00:00Z',
  updatedAt: '2023-12-01T10:00:00Z',
  comments: () => [
    {
      id: 'comment_1',
      content: 'Bedankt!',
      createdAt: '2023-12-01T10:05:00Z',
      updatedAt: '2023-12-01T10:05:00Z',
      type: 'comment',
      commentableType: 'comment',
      resourceType: 'comment',
      account: () => ({
        id: 'user_1',
        resourceType: 'accounts',
        firstName: 'Dylan',
        fullName: 'Dylan Hoekstra',
        roles: ['student'],
      }),
    },
  ],
};

const mockAttachments = [
  {
    id: '1',
    originalFileName: 'Document.pdf',
    downloadUrl: '/document.pdf',
  },
];

export const ThumbsUpSuccess: Story = {
  args: {
    activity: {
      id: '1',
      activity_at: '2023-12-01',
      time_at: '2023-12-01T19:53:00Z',
      relationships: {
        source: {
          type: 'thumbs_up',
          result: 'success',
          comment: 'Deze opdracht heb je echt goed uitgevoerd.',
          resourceType: 'assessments',
        },
        causer: {
          id: '1',
          fullName: 'Peter de Lange',
          avatarUrl: '',
        },
      },
    },
    description: 'Deze opdracht heb je echt goed uitgevoerd.',
    thread: mockThread,
  },
  parameters: {
    docs: {
      description: {
        story:
          'Success state with thumbs up icon and clean green background. No borders for a modern, clean appearance.',
      },
    },
  },
};

export const ThumbsDownWarning: Story = {
  args: {
    activity: {
      id: '2',
      activity_at: '2023-12-01',
      time_at: '2023-12-01T19:53:00Z',
      relationships: {
        source: {
          type: 'thumbs_down',
          result: 'warning',
          comment:
            'Deze opdracht moet je op een aantal punten nog bijwerken. En er missen onderdelen...',
          resourceType: 'assessments',
        },
        causer: {
          id: '1',
          fullName: 'Peter de Lange',
          avatarUrl: '',
        },
      },
    },
    description:
      'Deze opdracht moet je op een aantal punten nog bijwerken. En er missen onderdelen...',
    thread: mockThread,
  },
  parameters: {
    docs: {
      description: {
        story:
          'Warning state with thumbs down icon and clean yellow background. The borderless design maintains focus on the content.',
      },
    },
  },
};

export const NumericGradeSuccess: Story = {
  args: {
    activity: {
      id: '3',
      activity_at: '2023-12-01',
      time_at: '2023-12-01T19:53:00Z',
      relationships: {
        source: {
          type: 'numeric_grade',
          value: 8.8,
          result: 'success',
          comment: "Geweldig gedaan! Mag je trots op zijn, zo'n hoog cijfer!",
          resourceType: 'assessments',
        },
        causer: {
          id: '1',
          fullName: 'Peter de Lange',
          avatarUrl: '',
        },
      },
    },
    description: "Geweldig gedaan! Mag je trots op zijn, zo'n hoog cijfer!",
    thread: mockThread,
  },
  parameters: {
    docs: {
      description: {
        story:
          'High numeric grade with success state. Clean green background highlights the positive feedback without visual clutter.',
      },
    },
  },
};

export const NumericGradeWarning: Story = {
  args: {
    activity: {
      id: '4',
      activity_at: '2023-12-01',
      time_at: '2023-12-01T19:53:00Z',
      relationships: {
        source: {
          type: 'numeric_grade',
          value: 4.5,
          result: 'warning',
          comment: 'Hier staat de feedback van de coach',
          resourceType: 'assessments',
        },
        causer: {
          id: '1',
          fullName: 'Peter de Lange',
          avatarUrl: '',
        },
      },
    },
    description: 'Hier staat de feedback van de coach',
    thread: mockThread,
  },
  parameters: {
    docs: {
      description: {
        story:
          'Lower numeric grade with warning state. Yellow background provides clear visual feedback while maintaining clean aesthetics.',
      },
    },
  },
};

export const WithAttachments: Story = {
  args: {
    activity: {
      id: '5',
      activity_at: '2023-12-01',
      time_at: '2023-12-01T19:53:00Z',
      relationships: {
        source: {
          type: 'thumbs_up',
          result: 'success',
          comment:
            'Mooi gedaan! Ik heb nog aanvullende informatie over dit onderwerp toegevoegd. Interessant leesvoer!',
          resourceType: 'assessments',
        },
        causer: {
          id: '1',
          fullName: 'Peter de Lange',
          avatarUrl: '',
        },
      },
    },
    description:
      'Mooi gedaan! Ik heb nog aanvullende informatie over dit onderwerp toegevoegd. Interessant leesvoer!',
    attachments: mockAttachments,
    thread: mockThread,
  },
  parameters: {
    docs: {
      description: {
        story:
          'Activity card with file attachments. The borderless design keeps focus on the content and attachments.',
      },
    },
  },
};

export const NativeBackgroundNoRating: Story = {
  args: {
    activity: {
      id: '6',
      activity_at: '2023-12-01',
      time_at: '2023-12-01T19:53:00Z',
      relationships: {
        source: {
          type: 'thumbs_up',
          result: 'success',
          comment: 'This is a comment without rating display.',
          resourceType: 'assessments',
        },
        causer: {
          id: '1',
          fullName: 'Peter de Lange',
          avatarUrl: '',
        },
      },
    },
    description: 'This card uses the native background color and has no rating circle.',
    hideRating: true,
  },
  parameters: {
    docs: {
      description: {
        story:
          'Activity card with native background color (primary-color-10) and no rating circle. The success/warning states are completely hidden, showing just the content with the default styling.',
      },
    },
  },
};

export const NeutralWithThread: Story = {
  args: {
    activity: {
      id: '7',
      activity_at: '2023-12-01',
      time_at: '2023-12-01T19:53:00Z',
      relationships: {
        source: {
          type: 'thumbs_up',
          result: 'success',
          comment: 'Ik ga mijn best doen om de opdracht deze week nog na te kijken.',
          resourceType: 'assessments',
        },
        causer: {
          id: '1',
          fullName: 'Peter de Lange',
          avatarUrl: '',
        },
      },
    },
    description: 'Ik ga mijn best doen om de opdracht deze week nog na te kijken.',
    hideRating: true,
    thread: mockThread,
  },
  parameters: {
    docs: {
      description: {
        story:
          'Neutral activity card with native background color and toggleable thread/comments section. No rating circle is shown, maintaining the clean neutral appearance with full thread functionality.',
      },
    },
  },
};

export const FullWidthRating: StoryObj<typeof ActivityRating> = {
  render: (args: TActivityRatingProps) => (
    <ActivityRating {...args} className={styles.full} />
  ),
  args: {
    type: 'thumbs_up',
    result: 'success',
    comment: 'Mooie expositie om met jouw stagebegeleider te delen. Succes!',
  },
  parameters: {
    docs: {
      description: {
        story:
          'Standalone rating component with full-width layout and clean green background. No borders for modern appearance.',
      },
    },
  },
};

export const FullWidthRatingNumeric: StoryObj<typeof ActivityRating> = {
  render: (args: TActivityRatingProps) => (
    <ActivityRating {...args} className={styles.full} />
  ),
  args: {
    type: 'numeric_grade',
    value: 8.8,
    result: 'success',
    comment: 'Hier staat de feedback van de coach',
  },
  parameters: {
    docs: {
      description: {
        story:
          'Standalone numeric rating component with clean background design and no visual borders.',
      },
    },
  },
};
