---
id: "c78fa4ed-1777-4771-8dba-6554d93ca303"
tags: []
sortOrder: 144
preferredEditorMode: "raw"
createdAt: 1740744855084
modifiedAt: 1740744885880
---
APP_ENV=development
NEXT_PUBLIC_APP_ENV=development
NODE_ENV=development

#################
##   BACKEND   ##
# #################
# Local API
# BACKEND_ENDPOINT=http://courseware.test
# BEARER_TOKEN=

# Staging local
# BEARER_TOKEN=

# Staging
BACKEND_ENDPOINT=https://stage.unlimited.software
BEARER_TOKEN=


# Playgrounds
# BACKEND_ENDPOINT=https://playground-one.brainstud.dev
# BACKEND_ENDPOINT=https://playground-two.brainstud.dev

FALLBACK_ENDPOINT=$BACKEND_ENDPOINT
API_ENDPOINT=$BACKEND_ENDPOINT/api


# Change the domain communicated as X-PORTAL-DOMAIN header in API calls:
PORTAL_DOMAIN=$BACKEND_ENDPOINT

##############
##   AUTH   ##
##############
AUTH_COOKIE_NAME=auth_token

##################
##  DEV OAUTH   ##
##################
# Only required during development
OAUTH_CLIENT_ID=23
OAUTH_CLIENT_SECRET=# Ask someone with staging database access


# OAUTH_CLIENT_ID=1
# OAUTH_CLIENT_SECRET=7lW0n0Vjlw5DMzuWunr3taGqblN4ZYFt4HGetprd

# OAUTH_CLIENT_ID=2
# OAUTH_CLIENT_SECRET=zuuAMrv2s30uIPiTv1a6cbBrCpCoAiW76tNSqZcc

# Used to compute the localhost oauth login route during development
NEXT_PUBLIC_DEV_OAUTH_URL=$BACKEND_ENDPOINT
NEXT_PUBLIC_OAUTH_REDIRECT_URL=http://localhost:3000/api/auth/token
NEXT_PUBLIC_OAUTH_CLIENT_ID=23


################
##  New Relic ##
################
NEW_RELIC_ENABLED=false

################
##   Sentry   ##
################
SENTRY_IGNORE_API_RESOLUTION_ERROR=1


#####################  
## MSW API Mocking ##
#####################
NEXT_PUBLIC_API_MOCKING=enabled

#####################
##      OpenAI     ##
#####################
OPENAI_API_KEY=


###################
##   DEBUGGING   ##
###################
NEXT_PUBLIC_REACT_SCAN=false