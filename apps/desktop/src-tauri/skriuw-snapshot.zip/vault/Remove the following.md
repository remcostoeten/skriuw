---
id: "2f09c0be-f6e4-4e2e-be83-e0621b0aa9e4"
tags: []
sortOrder: 149
preferredEditorMode: "raw"
createdAt: 1739907852404
modifiedAt: 1739911294766
---
Remove the following
- The free label behind the organsisation dropdown
- Enabling branching
- Connect button.

Then inside the organisation dropdown can you create a creusable CRUD modal / functionallity for when "new organiszation" is clicked? 

MAke it as agnostic as possible, meaning the functions behind it, the text, the location, the entire module/feature can be easily migrated because its all very seperated and easy to mintain.



drizzle.config.ts

  import { env } from "@/env"
  import type { Config } from "drizzle-kit"

  export default {
    schema: "./src/server/db/schema/index.ts",
    out: "./src/server/db/migrations",
    dialect: "sqlite",
    dbCredentials: {
      url: env.DATABASE_URL.replace("file:", ""),
    },
    verbose: true,
    strict: true,
  } satisfies Config


nev.ts
import { createEnv } from "@t3-oss/env-nextjs"
import { z } from "zod"

export const env = createEnv({
  server: {
    DATABASE_URL: z.string().min(1),
    NODE_ENV: z.enum(["development", "production", "test"]).default("development"),
    JWT_SECRET: z.string().min(1).optional(),
  },
  client: {
    // Add client-side environment variables here if needed
  },
  runtimeEnv: {
    DATABASE_URL: process.env.DATABASE_URL,
    NODE_ENV: process.env.NODE_ENV,
    JWT_SECRET: process.env.JWT_SECRET,
  },
  skipValidation: !!process.env.SKIP_ENV_VALIDATION,
  emptyStringAsUndefined: true,
})

export type Env = typeof env


