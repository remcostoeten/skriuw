---
id: "413d77d3-5fb6-4c1a-bb7d-3d4abc354e9a"
tags: []
sortOrder: 381
preferredEditorMode: "raw"
createdAt: 1656864597451
modifiedAt: 1656865107497
---
Hello,

on may 30th I ordered your 2M RGBIC strip. Whilst it is a fantastic product (i had the 10m and non rgbic version prior which also broke on me a while back but that was quite a old one which I moved alot so that was probably more my own fault) it seem to have broken. I have only attachted the strip to my desk and not cut a part off, all how it came outside the box.

I can understand products break, especially when not that expensive but this is not even 2 months old and already broke which I think should not happen.

When I received the package I installed the strip behind my desk and after that I never toucehd it again. Last week it started to act a little bit weird, flickering and turning off and today it just completely died on me. I have tried different adaptres and also tried plugging the USB into my PC but none work. Lastly I tried another power outlet in the house but also fails.

I have tried all FAQ/Troubleshoot solutions which I could find on your site and also on Reddit but non fail to work. Turning it on through the app wont work, but also on the remote. I've tried pairing it again but also no luck. In the video you can see I have a govee glide next to it which works perfectly fine so power is not the problem, I think it's something inside the strip. I've checked the cable but it don't see any broken bits from the outside. I hope you can help me out.

I purcashed the strip through amazon which is or ordernumber #303-8262054-5911510.

I have made a video of  showing that it does not do anything. In th e video i talk some to explain what's going on. https://www.youtube.com/watch?v=CTAHlAKk-w0

I hope you guys can help me out with some warranty.

Kind regards,

Remco Stoeten