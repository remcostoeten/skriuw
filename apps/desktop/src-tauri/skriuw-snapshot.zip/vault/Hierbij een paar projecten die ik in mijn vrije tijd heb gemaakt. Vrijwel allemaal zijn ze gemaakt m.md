---
id: "15f0f4c337e347f9a5880b6a9a622a92"
tags: []
sortOrder: 6
preferredEditorMode: "raw"
createdAt: 1777554151879
modifiedAt: 1777555936415
---
Hierbij een paar projecten die ik in mijn vrije tijd heb gemaakt. Vrijwel allemaal zijn ze gemaakt middels react/nextjs, typescript, tailwindCss en vaak een nodejs backend of in het geval van de desktop applicatie Rust.

Ze zijn allemaal nog work in progress, dus zullen ongetwijfeld hier en daar bugs voorkomen.

M’n eigen site die ik recentelijk als "af" (nooit helemaal) heb bestempeld. Op de achtergrond zit er een admin, met custom analytics, en een CMS om projecten te tonen op de front-end.
https://remcostoeten.nl

Dan ben ik momenteel bezig met mijn eigen analytics service. Zonder al te technisch te worden bestaat dit uit drie delen. Een API die ergens gehost wordt, een pakket die mensen op hun site kunnen installeren, die vervolgens signalen naar de API stuurt. En dan heb ik een dashboard gebouwd (of eigenlijk net begonnen) die deze data toont. 
https://analytics.remcostoeten.nl/ is het dashboard waar dus de analytics van verschillende projecten van mij sinds vannochtend naar verstuurd worden

Dan heb ik nog https://zentjes.nl. Een portaal/dashboard om financien, schulden, inkomen, uitgaves, wishlists en nog tig andere dingen kan bijhouden , ai geimplementeerd die weet van de financien die je invoert e.d.

Dan heb ik nog https://skriuw.vercel.app/app. Een soort van notion achtige applicatie om dagboek, notities in bij te houden die op mac/windows/linux en web draait, ben echter net begonnen met het opnieuw bouwen  dus is nu nog wat kaal.

En een hele complexe, die ook op Mac, windows linux draait als desktop applicatie die je databases laat beheren. Een demo versie kan hier bekeken worden, maar dat zal een non-developer niet veel zeggen. https://doradb.vercel.app/?view=database-studio&table=customers&connection=demo-ecommerce-001

Verder nog taloze tools en kleine projecten op https://github.com/remcostoeten, cv op https://remcos.cv