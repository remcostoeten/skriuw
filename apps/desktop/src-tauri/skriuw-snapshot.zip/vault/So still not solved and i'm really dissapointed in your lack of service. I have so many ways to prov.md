---
id: "7278b603-41a2-4884-b4b9-a5e369c9a037"
tags: []
sortOrder: 346
preferredEditorMode: "raw"
createdAt: 1664726926846
modifiedAt: 1664728641391
---
So still not solved and i'm really dissapointed in your lack of service. I have so many ways to prove it's my account. I even have a pending Nitro subscription which is linked to my own bank account. That should be more than enough to verify it's me.

If the ban was correctly done and I broke major rules I would've understood but I am 100% certain I did nothing wrong. So basically i'm banned due to your system/algoritm giving out bans wrongly (I know the ban is not a human act), but rather ai/algoritme which in this case failed and obviously is not fool proof 100% of the time. That can happen but if that  happends I should have the right to defend myself instead of litterly punishing me because YOUR OWN system is broken. Breaking multi-year friendships where i have no way in contacting them because of a fault you gus made. It's sad to say the least.

Now the  intressting part which confirms it 100% that the ban was a fault. My friend (discordname) got the same ban as me at the same time. He, did happen to have acces to he's email so he was able to mail. After a lot of mailing foward you  revoked his ban and told him that some servers he was in violated the rules and suggested to report t hem and leave them. (See attachment of the mail he sent me, if you want to verify his ticket number is #28704985). And guess what; I was in exactly the same groups as him (we're talking about community discords of TheRealRc and ChemmicalCollective). He has access back to his account and those servers (1k+ members) seem to have closed. So it looks like your algoritm/AI has banned users who where a member of one of those discords; including me (remco@tickles.nl,Remco#5262).

I am a hundred procent sure that this is the reason you guys banned me. Since I don't have access to that email anymore I can not mail you from there nor can I see the reason (not that you told my friend what the exact reason was expect for some vague answer with "you violated the ToS", which I understand that it;s vague because you have no clue why he and I we're banned because it's' an AI system. Only after continious mailing you guys finally looked into his ban and concluded that indeed your system failed and he was banned for no reason and revoked the ban so now he has access back to his account

So I would sincerely ask you guys to please                                  