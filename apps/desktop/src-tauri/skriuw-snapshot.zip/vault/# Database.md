---
id: "a7e07a57-956e-4ae9-9ccb-227f50328b90"
tags: []
sortOrder: 28
preferredEditorMode: "block"
createdAt: 1768866042670
modifiedAt: 1768866218905
---
# Database
# neon.tech or local postgres
DATABASE_URL=postgresql://neondb_owner:npg_dJc2klP7iunC@ep-dark-surf-ag83l04h-pooler.c-2.eu-central-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require

# Better Auth
# Generate with: openssl rand -base64 32
BETTER_AUTH_SECRET="GuEeGnso9QOcHYQMCTJLXMbESvxytjsLp8yzDwkOIto="
# Base URL for auth, usually your frontend
BETTER_AUTH_URL="http://localhost:6967"

# GitHub OAuth Credentials (Zentjes)

# GitHub OAuth Credentials (Zen)
GITHUB_CLIENT_ID="Ov23li3yMNDncwlatKdp"
GITHUB_CLIENT_SECRET="5c3e2c352a6f9a0932a8a1cf7c08b185aa3a10ca"

GOOGLE_CLIENT_ID=""
GOOGLE_CLIENT_SECRET=""

# Client Side (Public)
NEXT_PUBLIC_API_URL="http://localhost:6967"
NEXT_PUBLIC_APP_URL="http://localhost:6967"

# Environment
NODE_ENV="development"
PORT=6967
SKIP_ENV_VALIDATION=false
                    