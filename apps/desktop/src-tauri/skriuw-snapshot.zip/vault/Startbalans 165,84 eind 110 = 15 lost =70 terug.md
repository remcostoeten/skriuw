---
id: "b59e158f-1ec6-4aec-9891-b124d2dac488"
tags: []
sortOrder: 308
preferredEditorMode: "raw"
createdAt: 1677243404212
modifiedAt: 1677245056957
---
Startbalans 165,84 eind 110 = 15 lost =70 terug
2 = 0.88 terug
3 start = 144  = 0.75
131 =  78
120 64
112 94
1090.6
90  3,62
211.82
197 87
184 0.9 
179

