---
id: "0b58a46695f743e8b6cf9cfb3e6d00e5"
tags: []
sortOrder: 159
preferredEditorMode: "block"
createdAt: 1736733178837
modifiedAt: 1736733878904
---
Meeste heeft m’n ex. Een flashlight voor de zielige dagen en wat dingen als een tuigje/halsband.

Kan je een beetje wat hebben? Lichte tik in je gezicht bijvoorbeeld.

Klaarkomen geil ja? Ik vind in een meid komen niks en spuit vrij ver en als ik echt geil ben wel een keer of 8-10, dus missionaris neuken en dan vervolgens van haar heup over haar borsten en gezicht spuiten vind ik geweldig, vooral als ze het niet verwachten.

Of spiegel bij het bed en dan op je knieën mij je hele gezicht onder laten spuiten om je  vervolgens op je buik op bed te gooien richting de spiegel, je doggy neuk en hard bij je haren omhoog trek zodat je jezelf in de spiegel ziet met nog allemaal sperma over je gezicht

En bucketlist: wil toch wel eens gepijpt worden door 2 vrouwen

En ik wil een filmpje waar dame op haar hurken zit met mooie lingerie en kont recht achter haar en mij pijpt. Dus je haar hoofd niet ziet, enkel komt in spiegel en haar hoort struggelen  met deepthroaten

Feestje afmaken is zij voor de spiegel en ik die over haar spuit en wat op  spiegel komt likt ze eraf.