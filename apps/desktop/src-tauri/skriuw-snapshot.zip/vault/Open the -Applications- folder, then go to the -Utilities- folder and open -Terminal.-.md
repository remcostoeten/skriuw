---
id: "734e8bae-b7e1-4621-8ab1-4731c5c2f0b0"
tags: []
sortOrder: 263
preferredEditorMode: "raw"
createdAt: 1686762803188
modifiedAt: 1686763023806
---
Open the "Applications" folder, then go to the "Utilities" folder and open "Terminal."

In the Terminal window, enter the following command and press Enter:

bash
Copy code
defaults write com.apple.screencapture type -string "png"
Next, enter the following command and press Enter:

bash
Copy code
defaults write com.apple.screencapture location -string "$HOME/Desktop"
This sets the default location for screenshots to the desktop. You can change "$HOME/Desktop" to any desired folder path if you prefer a different location.

Restart the system UI server for the changes to take effect. Enter the following command and press Enter:

bash
Copy code
killall SystemUIServer
Now, when you use the standard 


Automator screenshot to clipboard
#!/bin/bash
screenshot_path="$HOME/Documents/Screenshots/$(date +%Y-%m-%d_%H-%M-%S).png"
screencapture -i "$screenshot_path"
pbcopy < "$screenshot_path"
echo "Screenshot copied to clipboard: $screenshot_path"

