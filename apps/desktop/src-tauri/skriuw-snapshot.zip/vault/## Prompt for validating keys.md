---
id: "7c198cc5-ba21-462f-93bf-07f94fef704f"
tags: []
sortOrder: 26
preferredEditorMode: "block"
createdAt: 1769169203590
modifiedAt: 1769169802528
---
## Prompt for validating keys

Tech stack:
Svelte (kit) - Newest svelte api with remote functions, runes, (see svelte MCP) or $DOCS
TailwindCSS
Usage of semantic types e.g.
type UUID = string
type Timestamp = number

and than trying to achieve a scalable architecture with the least DRY possible. All our entitys should  be based on top of base DTO's e.g.

type BaseEntity = {
	id: UUID
} & {
	createdAt: Timestamp
	updatedAt: Timestamp
	deletedAt?: Timestamp
}

Platform: Tauri 2.0
Ideally api should be possible to work via rust the rust  backend locally or on the web meaning we need some sort of adapter system.

Database options:
web: Turso libsql
local desktop: sqlite (or maybe local turso) - should not have setup for local

There should be a authentication option to allow syncing, for now only github oauth. Either custom oauth2 implementation or via better auth.

(better auth demands user, session account, verification schema, generatable via their cli but lets say only user for easy prompt)

if desktop prompt withdo u want a user or no , user allows for sync and backup

if no create user in dblikeso
anonymous
sqlitepath
created at
updated at
meta :{
     keysAreEncrypted: boolean M000 how  this works idk yet
       startupRequiresPassword: boolean
       startuppassword: encrypted string

}


user : {
    ...githubprofile
     meta: { 
         same as anon meta          
     } 
     createdat
     updatedat
}

keys : {
     key: {
      provider: {
           google

      } ,
      provider: { 
         github {

         }
      }
    } 
}