---
id: "251dd276-6608-4df8-a50f-bd1910a1acf7"
tags: []
sortOrder: 294
preferredEditorMode: "raw"
createdAt: 1679595040851
modifiedAt: 1679595414448
---
Dat wanneer iemand naar je op z'n diepste moment 

Wanneer iemand op z'n diepste moment schreeuwt om hulp o.a. door leugens je er voor kiest om weer te liegen terwijl je op dat moment geneukt wordt door een jongen snap ik gewoon niet, getuigd toch van nul respect of geven om iemand

Dat je het niet verteld dat je aan het neuken bent snap ik volkomen, maar waarom van alles eromheen verzinnen en ook nog beloftes doen daarna