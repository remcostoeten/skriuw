---
id: "140aeb93-16bc-45bc-95f6-e29d0dd0ba0a"
tags: []
sortOrder: 271
preferredEditorMode: "raw"
createdAt: 1685886814815
modifiedAt: 1685886938812
---
Chat-gpt prompt creator

Act as a  *A

*A
-Front-end developer
-Senior Front-end Engineer
-Back-end engineer
-Dev-ops engineer
-Creative UI designer with Front-end knowledge
-Marketing SEO specialist for React

B*
-NextJS
-React
-Vue

C*
Typescript
Framer Motion
Firebase


D*
MUI 
TailwindCSS
