---
id: "7dbf6daf-cbf3-43e0-99c8-c1c05e0c751b"
tags: []
sortOrder: 90
preferredEditorMode: "raw"
createdAt: 1750257370812
modifiedAt: 1751144429330
---
xxhttps://emea01.safelinks.protection.outlook.com/?url=https%3A%2F%2Fastral-field-294621.firebaseapp.com%2F__%2Fauth%2Faction%3FapiKey%3DAIzaSyBdy3O3S9hrdayLJxJ7mriBR4qgUaUygAs%26mode%3DsignIn%26oobCode%3DT54x_QfCL9Hm1Y8ScbP6WKmLyXrd8WUbCxw-umUa3zEAAAGXrkEMNQ%26continueUrl%3Dhttps%3A%2F%2Fapp.warp.dev%2Flogin%2Fremote%3Fscheme%253Dwarp%2526state%253D9021dde8-74bd-4fea-a277-d484d9d98afc%26lang%3Den&data=05%7C02%7C%7Cc1ff59dd13bf4921ce2108ddb4fcc50b%7C84df9e7fe9f640afb435aaaaaaaaaaaa%7C1%7C0%7C638865719899769040%7CUnknown%7CTWFpbGZsb3d8eyJFbXB0eU1hcGkiOnRydWUsIlYiOiIwLjAuMDAwMCIsIlAiOiJXaW4zMiIsIkFOIjoiTWFpbCIsIldUIjoyfQ%3D%3D%7C0%7C%7C%7C&sdata=r2c2AFUZJy5l4CCQ2Yd80ESiDl3Ep4ovc0794wmDk3E%3D&reserved=0wqq