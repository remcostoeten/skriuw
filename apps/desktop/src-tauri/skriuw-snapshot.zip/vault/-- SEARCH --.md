---
id: "7a122f04-c011-4c1d-96c1-931e79a9aebb"
tags: ["bed5eb","c7d2d9","ced7dd","d2d8df","d4dce1","fff","ffffff","product-scroll-to-results","search_filters"]
sortOrder: 327
preferredEditorMode: "raw"
createdAt: 1669203507331
modifiedAt: 1669203584454
---

/* SEARCH */
.facets-list {
    font-weight: bold;
    list-style: none;
    margin: 0;
    color: #364651;
    padding: 0;
}

.facets-list > .facet-header {
    font-family: "Open Sans", sans-serif;
    display: inline-block;
    width: 100%;
    border-bottom: 1px solid #BED5EB;
    padding: 10px 0;
    margin-bottom: 10px;
}

.facets-list > .facet-header > h6 {
    text-transform: uppercase;
    font-weight: bold;
    list-style: none;
    color: #364651;
    margin-bottom: 0;
}

.facets-list .btn-outline-light {
    border-color: #d2d8df !important;
    color: #364651 !important;
}

.facets-list .btn-outline-light.active {
    font-weight: bold;
}

.facets-list label {
    font-weight: normal;
}

.facets-list .facet-list-toggle label {
    font-size: 1em;
}

.search-result-action-buttons {
    height: 50px;
}

.search-results-wrapper {
    -webkit-border-radius: 4px;
    -moz-border-radius: 4px;
    border-radius: 4px;
    display: -webkit-box;
    display: -webkit-flex;
    display: -moz-box;
    display: -ms-flexbox;
    display: flex;
    flex-wrap: wrap;
    width: 100%;

}

.facet-header.d-flex.align-items-center {
    border-bottom: 1px solid #ced7dd;
}

.search-filters-header {
    height: 48px;
    font-size: 16px;
    /*letter-spacing: -0.4px;*/
    /*line-height: 19px;*/
    /*font-weight: bold;*/
}

.search-filters-header h2 {
    padding: 14px 16px;
}

.search-filters #search_filters {
    padding: 0 16px 8px 16px;
}

.search-filters-header h4 {
    padding: 16px 0;
    font-size: 24px;
    font-weight: bold;
}

.product-select-checkbox {
    position: absolute !important;
    left: 8px;
    top: 8px;
}

.page-item.active .page-link {
    background-color: #0092d2;
    border-color: #217fa8;
}

.btn-link {
    color: #0092d2;
    border: 1px solid #9696a3;
    margin: 0 10px 10px 0
}

.btn-remove-facet-filter {
    border: 1px solid #9696a3;
    margin: 0 10px 10px 0;
}
.btn-remove-all-facet-filters {
    border: 1px transparent;
}

.product-search-checked-facets {
    border-bottom: 1px solid #d4dce1;
    padding: 10px 0;
}

.debug {
    display: none;
}

.products {
    display: -webkit-box; /* OLD - iOS 6-, Safari 3.1-6 */
    display: -moz-box; /* OLD - Firefox 19- (buggy but mostly works) */
    display: -ms-flexbox; /* TWEENER - IE 10 */
    display: -webkit-flex; /* NEW - Chrome */
    display: flex; /* NEW, Spec - Opera 12.1, Firefox 20+ */
    flex-flow: row wrap;
    justify-content: flex-start;
}

/* LOADER */
.product-loader-wrapper {
    width: 100%;
    height: 100%;
    position: absolute;
    background: rgba(232, 232, 232, 0.5);
    left:0;
    top:0;
    display: flex;
    color: #0a92cd;
    justify-content: center;
    z-index: 99999;
}
.product-loader {
    width: 60px;
    position: fixed;
    padding-top: 100px;
}

.product-loader-wheel {
    animation: spin 1s infinite linear;
    border: 2px solid rgba(30, 30, 30, 0.5);
    border-left: 4px solid #fff;
    border-radius: 50%;
    height: 50px;
    margin-bottom: 10px;
    width: 50px;
}

.product-loader-text {
    color: #0a92cd;
    font-family: arial, sans-serif;
}

.product-loader-text:after {
    content: 'Loading';
    animation: load 2s linear infinite;
}

@keyframes spin {
    0% {
        transform: rotate(0deg);
    }
    100% {
        transform: rotate(360deg);
    }
}

@keyframes load {
    0% {
        content: 'Laden';
    }
    33% {
        content: 'Laden.';
    }
    67% {
        content: 'Laden..';
    }
    100% {
        content: 'Laden...';
    }
}
/* END LOADER*/


.product-card-container {
    width: 100%;
    display: inline-grid;
    grid-template-columns: repeat(4, 1fr);
}

.product-card {
    display: -webkit-box; /* OLD - iOS 6-, Safari 3.1-6 */
    display: -moz-box; /* OLD - Firefox 19- (buggy but mostly works) */
    display: -ms-flexbox; /* TWEENER - IE 10 */
    display: -webkit-flex; /* NEW - Chrome */
    display: flex; /* NEW, Spec - Opera 12.1, Firefox 20+ */
    /*flex: 1 0 21%;*/
    flex-flow: column;
    text-decoration: none;
    border: 1px solid transparent;
    border-bottom: 2px solid transparent;
    max-width: 396px;
    min-width: 21%;
    min-height: 478px;
    margin-top: 16px;
    margin-bottom: 16px;
    box-shadow: inset -1px 0 0 0 #C7D2D9;
    position: relative;
}

.product-card:hover {
    border: 1px solid #C7D2D9;
    border-bottom: 2px solid #0092D2;
    box-shadow: inset -1px 0 0 0 transparent;
    cursor: pointer;
}

.product-card-shadow {
    box-shadow: inset -1px 0 0 0 #C7D2D9;
}
.product-tile-instance-count {
    position: absolute;
    top: 0;
    right: 0;
    width: 60px;
    height: 36px;
    background: #0092D2;
    border-bottom-left-radius: 4px;
    font-family: 'Open Sans',sans-serif;
    font-weight: bold;
    font-size: 14px;
    color: #FFFFFF;
    letter-spacing: -0.36px;
    text-align: right;
    padding-right: 10px;
    line-height: 36px;
    z-index: 99;
}
.product-tile-instance-icon {
    position: absolute;
    left: 10px;
    top: 12px;
    height: 16px;
    width: 16px;
}

.product-image {
    display: -webkit-box; /* OLD - iOS 6-, Safari 3.1-6 */
    display: -moz-box; /* OLD - Firefox 19- (buggy but mostly works) */
    display: -ms-flexbox; /* TWEENER - IE 10 */
    display: -webkit-flex; /* NEW - Chrome */
    display: flex; /* NEW, Spec - Opera 12.1, Firefox 20+ */
    width: 261px;
    height: 220px;
    margin: 8px auto auto auto;
    text-align: center;
    align-items: center;
    justify-content: center;
}

.product-image img:not(.product-card-standard-icon) {
    display: block;
    max-width: 261px;
    max-height: 220px;
    width: auto;
    height: auto;
    margin: 5px 6px 0 0;}

.product-card-title {
    font-family: 'Open Sans', sans-serif;
    font-weight: 800;
    font-size: 18px;
    color: #0092D2;
    letter-spacing: -0.47px;
    margin: 38px 24px 16px 24px;
    text-decoration: none;
}

.product-card-buy-button-container {
    margin: 12px 24px 4px 24px;
    height: 40px;
    position: relative;
    z-index: 1;
}

.product-card-favorite-button-container {
    margin: 4px 24px 16px 24px;
    height: 40px;
    position: relative;
    z-index: 1;
}

.product-card-buy-button {
    font-size: 16px !important;
}

.product-card-standards-wrapper {
    margin: 0 auto;
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
}

.product-card-standard-icon {
    width: 30px;
    height: 30px;
    padding: 2px;
    box-sizing: content-box;
    background: #fff;
    border-radius: 5px;
    margin-right: 5px;
    margin-top: 5px;
    border: 1px solid #0092d2;
}
#product-scroll-to-results {
    position: sticky; 
    top: 50vh;
}

@media screen and (min-width: 1700px) {
    .home-navigation-tile:nth-child(4n) {
        margin-right: 0px;
    }

    .product-card:nth-child(4n) {
        box-shadow: inset -1px 0 0 0 transparent;
    }

    .mobile {
        display: none;
    }
}

@media screen and (max-width: 1700px) {
    .header-logo-searchbar {
        max-width: 1175px;
    }

    .header-nav-container {
        max-width: 1175px;
    }

    .container {
        max-width: 1175px;
    }

    .layout-container {
        max-width: 1175px;
    }

    .home-usp-container {
        max-width: 1175px;
    }

    a.home-navigation-tile:nth-child(3n) {
        margin-right: 0px;
    }

    .product-card-container {
        grid-template-columns: repeat(3, 1fr);
    }

    .product-card {
        /*flex: 1 0 31%;*/
        /*min-width: 31%;*/
        /*max-width: 390px;*/
    }

    .product-card:nth-child(3n) {
        box-shadow: inset -1px 0 0 0 transparent;
    }

    .shoppingcart-quantity-column {
        width: 50px;
    }

    .mobile {
        display: none;
    }
}

@media screen and (max-width: 1200px) {
    .header-logo-searchbar {
        max-width: 768px;
    }

    .header-nav-container {
        max-width: 768px;
    }

    .container {
        max-width: 768px;
    }

    .layout-container {
        max-width: 768px;
    }

    .localization-container {
        -webkit-flex-flow: column nowrap;
        flex-flow: column nowrap;
    }

    .localization-dropdown {
        margin-bottom: 12px;
    }

    .home-usp-container {
        max-width: 768px;
    }

    a.home-navigation-tile:nth-child(3n) {
        margin-right: 24px;
    }

    a.home-navigation-tile:nth-child(2n) {
        margin-right: 0px;
    }
    .product-card-container {
        grid-template-columns: repeat(2, 1fr);
    }

    .product-card {
        /*flex: 1 0 48%;*/
        /*min-width: 48%;*/
        /*max-width: 383px;*/
    }

        .product-card:nth-child(even) {
            box-shadow: inset -1px 0 0 0 transparent;
        }

        .product-card:nth-child(3n) {
            box-shadow: inset -1px 0 0 0 #C7D2D9;
        }

    .product-detail-title {
        margin-top: 24px;
    }

    .flex-item-2col:nth-child(2) {
        margin-left: 0;
    }

    .shoppingcart-price-column {
        width: 110px;
    }

    .mobile {
        display: none;
    }
}

@media screen and (max-width: 800px) {
    .header {
        margin: 8px;
    }

    .header-logo-searchbar {
        -webkit-flex-flow: column nowrap;
        flex-flow: column nowrap;
        max-width: 375px;
    }

    .header-search {
        margin: 8px 0;
        width: 100%;
    }

    .header-nav-container {
        margin-top: 16px;
        max-width: 375px;
    }

    nav {
        display: none;
    }

    .container {
        max-width: initial;
    }
    .layout-menu, .layout-content {
        width: 100% !important;
    }
    .layout-content {
        padding: 0 30px;
    }

    .layout-container {
        max-width: initial;
    }
    .footer-container.layout-container {
        padding: 0 30px;
        box-sizing: border-box;
    }

    .home-usp-container {
        -webkit-flex-flow: column nowrap;
        flex-flow: column nowrap;
        margin-top: 30px;
        max-width: 375px;
    }

    .home-usp {
        margin-top: 16px;
    }

    a.home-navigation-tile {
        max-width: 100%;
        margin-right: 0px;
    }

        a.home-navigation-tile:nth-child(3n) {
            max-width: 100%;
            margin-right: 0px;
        }

        a.home-navigation-tile:nth-child(2n) {
            max-width: 100%;
            margin-right: 0px;
        }

    .footer-columns {
        -webkit-flex-flow: column nowrap;
        flex-flow: column nowrap;
        margin-top: 54px;
        margin-bottom: 30px;
    }

    .footer-column {
        margin-top: 16px;
    }

    .product-card-container {
        grid-template-columns: repeat(1, 1fr);
    }

    .product-card {
        /*flex: 1 0 51%;*/
        /*min-width: 51%;*/
    }

    .product-card:nth-child(1n) {
        box-shadow: inset 0 -1px 0 0 #C7D2D9;
    }

    .product-detail-image {
        height: 375px;
        width: 375px;
    }

    .product-detail-images {
        max-width: 375px;
    }

        .product-detail-images img {
            max-width: 375px;
            max-height: 375px;
        }

    .product-images-gallery {
        width: 361px;
    }

    .product-images-gallery-image {
        margin: 20px 32px 0px 0px;
    }

        .product-images-gallery-image > img {
            max-width: 86px;
            max-height: 86px;
        }

    .flex-item-2col {
        max-width: 375px;
    }

    .shoppingcart-image-column {
        display: none;
    }

    .shoppingcart-buttons {
        -webkit-flex-flow: column-reverse nowrap;
        flex-flow: column-reverse nowrap;
    }

    .shoppingcart-button {
        margin-top: 24px;
        width: 330px;
    }

    .pc {
        display: none;
    }

    .mobile {
        display: block;
    }
}
.col-25, .col-50, .col-75 {
    padding: 0 16px;
}
.col-25 {
    -webkit-box-flex: 25;
    -webkit-flex: 25;
    -ms-flex: 25;
    flex: 25;
    width: 25% !important;
}.flex-fill {
    -ms-flex: 1 1 auto !important;
    flex: 1 1 auto !important;
}