---
id: "47eb865d-b5ea-4f1f-9a8d-5a3577e7c441"
tags: ["daphne","datewat","eline","heroine","hoofd","julia","lianne","werk","zeena"]
sortOrder: 434
preferredEditorMode: "raw"
createdAt: 1782344346725
modifiedAt: 1782344347027
---
## Date met #eline kaptijn in ...

Weken lang er leuk contact, merkte wel dat zij echt verwachitngen had en me leuk begon te vinden. Ik haar ook overigens, al gaat dat vaak wel snel bij mij..

Ik kan zo slecht tegen mensen die verwachtingen hebben van mij want ik weet dat ik ze toch altijd volledig teleur stel. Althans, dat maak ik mezelf wijs. Ergens ben ik er heilig van overtuigd dat mensen in negatieve zin over bepaalde lichaamsdelen of trekjes die ik heb. Maar ik weet ook wel dat ik het veel groter maak in mijn #hoofd . Ik kan maar niet stoppen met nadenken, alles over-analyseer ik.

Grappig overigens, tijdens de date zei Eline dat zij een analytisch karakter heeft als het gaat om mensen. Non verbaal gedrag door de gaten hebben e.d. bedoeldde ze. Volgens haar een zegen en valkuil tegelijk.

Dat herken ik.

Eerste keer dat ik tijdens een #datewat ging eten. Het was ook nog eens 35 graden buiten, insanity. BIj aankomst een knuffel gegeten, plekje opgezocht en prosecco besteld. ZIj uiteindelijk drie stuks, ik nog een biertje en cola light.

Van hr meid op #werk gehoord over betalen, doe wnaneer zij naar de wc gaat. Dus zij voor de tweede keer naar de wc en toen snel betaald. Ze vond het achteraf smooth. Niet al te lang daarna vertrokken en zij was al erg lang wakker door nachtdienst. Sigaretje gerookt en zij wandelde naar huis nadat we knuffelde ze en "volgens mij" zei ze: Nou was ook leuk om je eens in het echt gezien te hebben".

Klinkt niet echt alsof er iets was van gevoelens nu het IRL was onank

de hartjes op whatsapp afgelopen week.

Tien minuten l ater appte ze dat ze ethuis was en lekker ging slapen. Niets meer. UIteraard moet ik er zelf weer ach teraan. Heb gezegd dat ik het leuk vond en nog wel een keer wil afspreken en benieuwd wat zij vindt.

Het is 1;17am de nacht ( wo op donderdag ) en zij wordt morgen eerder wakker dan iik. Ben benieuwd of ik reactie heb straks. Het is oprecht een leuke meid, knap, super persoonlijkheid, ze heeft hobbys , geen aandachtstrutje, niet preuts en geeft aandacht of laat me speciaal voelen.

MAar eerlijk is eerlijk als ik aan alle meiden terug denk deden ze dat allemaal. Al le maal. Misschien #daphne de eerste jaren nog het minst, wat een relatie was dat.

Het is ergens best zielig. Ik heb gewoon een zwak en val op affectie en aandacht. Zij vallen op mij in het begin omdat ik anders dan anders, ik kom vertrouweljk over en zo gaat het elke fucking keer.

Of ik ben een rebound, of zij willen niks meer en ik blijf maar met de gevoelens zitten en krijg ze niet uit m'n hoofd.

Ik wil niet dagelijksj zeggen maar sowieso wekelijks dat ik aan #zeena , #daphne , #lianne of #julia denk. Afvragend wat zei nu hebben, en wat diegene ze biedt. En of ze nog wel aan mij denken af en toe ook. Kan toch niet anders zou je zeggen.

En weetje ik kan ze allemaal geen ongelijk geven. Ik heb niks te bieden behalve een leuke chat partner.
\- Ik heb geen geld

- Ik rook

- Ik woon thuis bij papa

- Ik heb net nieuw werk

- Ik heb geen vrienden op misschien quinten, sander, vince na. Maarja die zie ik nooit

- Ik sport helemaal niet meer

- Ga laat op bed

En dan weten ze het niet eens dat ik 24/7 `NEP` vape. Ik pshycotisch ben, ik chizofrenie ervaar. Ik vandag weer lekker #heroine heb besteld nasaal en net op omdat ik een zwakke sukkel ben na 5 maanden niks te hebben gehad

### Ik. Snap. Het. Wel

Maar dat neemt niet weg dat het extreem moelijk en kut is. Het is ook gewoon een infinite loop.

ik kan het niet alleen en heb externe motivatie nodig van een persoon die mij accepteerd hoe ik tijdeljk ben en aan mezelf moet werken. Ik ben mezelf verloren, herken mezelf niet meer al weet ik dat de de pressieve Remco altijd in me heeft geschuild. Maarja wie wilt zo iemand nou een kans geven?

Ik wou gewoon dat iemand wat in me zag. Zoals hoe #lianne mij liet voelen destijds. Zo'n spepcaal en mooi gevoel en des te harder was de klap. Drie fucking jaren verder en ik kan er nog steeds niet over ophouden met denken. Sneu eigenlijk.

Ben benieuwd oveerigens als ik morgen gecanceld word of Eline mij onthoud. Ze is lief en opecht en zei op whatsapp dat ik liefde verdien en ze weet dat ik er in mn eentje voor sta. Misschien mem als ze jarig is, of met m'n verjaardag. Ik hoop het ergens, maar kan er niet van uit gaan, ik bedoel we hadden immer niks.

Ik mis het gewoon zo om me normaal te voelen, nuttig, gewild, en alsof ik er toe doe.

Ikzeg dit al lang maar ik kan het niet nog eeuwen volhouden. De emmer begint serieus vol te lopen. Ik durf het toch niet, maar ik wil soms zo graag. Van alle ellende af. Naar mem toe. Ik heb hier gewoon niks meer. Het leven heeft van me gewonnen.

Jup, ik ben DIE sukkel geworden