---
id: "caa3b509900a4c0aa373d32df4ff1468"
tags: []
sortOrder: 292
preferredEditorMode: "raw"
createdAt: 1679623650128
modifiedAt: 1679625093864
---
-17e vrijdag bericht ik jou dat ik het zwaar heb, je wilt niet helpen ok. 
-Vervolgens reageer je fucking sloom na je werk. Claim je niet fit te zijn en zeg je we bellen morgen. --=Vervolgens ga je om 01:30 pas slapen terwijl je ziek bent(?), iemand aan het pijpen bedoel je. 
-Je belt me perongeluk? Oorbel verhaal negeer je (duh omdat iemand bij je is). Vervolgens negeer je me en zeg je volgende dag dat je ziek bent.
-Je zegt dit tegen me, beetje heet onder je voeten dat ik weet dat er wat gaande is. W/e.
[19:35, 18/03/2023] Daphne: Jonge je stelt je vragen tering suggestief
[19:35, 18/03/2023] Daphne: Met je je gaat om half 2 slapen
Goh :') 

-Zaterdag bel je me niet wat je zou doen. Zeg je zondag bellen me, wat je niet doet.

-Daarna op zondag zeg je:[21:10, 19/03/2023] Daphne: 1 concrete date op de planning
[21:10, 19/03/2023] Daphne: Jawel
[21:11, 19/03/2023] Remco Stoeten: En
[21:11, 19/03/2023] Daphne: Ja wel wennen
[21:11, 19/03/2023] Daphne: Maar wel gezellig
[21:11, 19/03/2023] Remco Stoeten: Wat ging je doen dan
[21:11, 19/03/2023] Daphne: Drankje
[21:11, 19/03/2023] Remco Stoeten: En wat gebeurd? 😛
[21:12, 19/03/2023] Daphne: Gezoend

Daarna zeg je dat je met deze dude een 2e date op de planning hebt. Terwijl je dus 2 dagen terug al met hem geneukt hebt. Leugen dus

Stukje verderop zeg je op dit: 
[21:54, 19/03/2023] Remco Stoeten: Ik dacht eergister ook dat je met iemand was en je met diegene beetje over mij aan het trollen was, dat hij op bellen klikteen jij snel weg drukte ofzo 😂
[21:55, 19/03/2023] Daphne: Née
[21:55, 19/03/2023] Daphne: Was alleen
Weer gelogen dus.

Vervolgens vandaag lieg je weer;
[21:20, 23/03/2023] Daphne: Welke dag was dat
[21:20, 23/03/2023] Remco Stoeten: Vrijdag volgens mij
[21:20, 23/03/2023] Daphne: Nee
[21:20, 23/03/2023] Daphne: Oprecht
Oh née toen was ik gewoon aan het appen met iemand