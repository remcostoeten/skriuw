---
id: "9ef08c50-383a-48bf-9ac2-d6977a804ea9"
tags: []
sortOrder: 235
preferredEditorMode: "raw"
createdAt: 1707490334050
modifiedAt: 1707790567562
---
Goedendag, ik heb een brief van jullie gekregen waar ik het zachtsgezegd niet mee eens ben. Dus ik leg graag uit vanwaar, en hoop (eigenlijk neem aan) dat dit komt te vervallen. Ik heb afgelopen november geloof ik bij Amazon een webcam besteld t.w.v 50-55 euro. Bij de levering zat een brrief met dat ik in mijn account kon betalen, echter kon ik niet inloggen op mijn account want die was gedeactiveerd. Vervolgens contact via de chat opgenoemn die mij vertelde dat ik moest mailen. Zo heb ik op 26-10-2023 gemaild naar monthlyinvoice@amazon.nl (dat werd mij verteld) het bijgevoegde mailtje als foto. Hier heb ik geen reactie op gehad. Vervolgens niks meer gehoord, en nu krijg ik van jullie een brief dat ik meerdere keren aangeschreven ben waardoor het bedrag verdubbeld is. Ik zou graag willen weten waar ik dit heb moeten inzien, in mijn mail (remcostoeten@hotmail.com, stoetenremco.rs@gmail.com) heb ik geen contact, of mail van jullie gehad. Ik ben niet telefonisch benaderd,, en dit is de eerste brief die ik van jullie krijg over deze case. Ik heb ingelogd op mijn Rivery account en daar staat deze case ook niet, twee oude bestellingen wel. Dus ik kan me moeilijk vinden in de extra kosten aangezien ik moeite heb gedaan om contact op te nemen, en ik nu voor de eerste keer pas wat hoor over deze case. Ik neem aan dat jullie dit gaan regelen. Remco Stoeten, dossiernummmer 920000008677