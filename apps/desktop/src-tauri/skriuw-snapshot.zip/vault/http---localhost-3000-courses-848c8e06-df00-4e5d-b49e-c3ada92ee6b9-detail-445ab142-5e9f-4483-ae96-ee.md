---
id: "fa5be5d2-9dbb-4ce0-9171-8c565162af3b"
tags: []
sortOrder: 132
preferredEditorMode: "raw"
createdAt: 1742232592949
modifiedAt: 1742232593419
---
http://localhost:3000/courses/848c8e06-df00-4e5d-b49e-c3ada92ee6b9/detail/445ab142-5e9f-4483-ae96-eee6d4eabe7e