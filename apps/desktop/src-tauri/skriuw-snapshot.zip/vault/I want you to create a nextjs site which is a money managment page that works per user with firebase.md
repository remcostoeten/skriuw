---
id: "dbfab08c-572b-453f-b087-15cffc2e0ec0"
tags: []
sortOrder: 277
preferredEditorMode: "raw"
createdAt: 1684360947468
modifiedAt: 1684361091956
---
I want you to create a nextjs site which is a money managment page that works per user with firebase.

-Per user individual dashboard.
-Allow to create categories (e.g food, hobbys).
-Allow to create expenses inside that category
-Expense consist of price, date (not required), title (not require) and description) not required.
-Allow to switch or drag from 1 category to other.
-Allow remove expense
-Set max budget which recalcualtes once a expense is added
-Each user must have unique expenses ofcourse. Login to view your own. 

I have a next app setup but that's all.