---
id: "3063bd01-155b-45c0-8a59-4c6418583cba"
tags: []
sortOrder: 404
preferredEditorMode: "raw"
createdAt: 1646442561737
modifiedAt: 1646767980486
---
En ben m'n hele kamer aan het ombouwen dus zal wat apparatuur zoals usb hubje worden enzo. Ik kan bob wel mailen met wat ik wil, als jij dan factuur regelt en seintje geeft zodra verloning is gedaan dan betaal ik die vakantieuren enzo terug