---
id: "e782ccce-2b71-4126-8627-77f02724bb85"
tags: []
sortOrder: 136
preferredEditorMode: "raw"
createdAt: 1742146336363
modifiedAt: 1742146966459
---

can you create me a dark vercel looking, or same uit as https://resend.com, https;//midday.ai or dark theme as https://vercel.com a  widget for a nextjs alication that is entierly scoed into one folder position at "src/modules/widgets/calculator/ and inside calculator you can have the follownig structure.

% stands for src/modules/widgets/claculator (just for in this promt, in the code secify the entire ath). `<--` Will indicate a comment regarding the folder

%/api `<--` All server logic goes here
%/api/queries/ `<--` all queries (server functions go here)
%/api/mutations/ `<--` all mutations (`post` , `put` go here)
%/api/models/ `<--` all `Zod` schemas go herre in this format: `z.some-name.ts`
%/api/schemas/ `<--` if necissarry all `drizzle` 
%/comonents
%/hooks
%/state
%/styles
%/helpers  
%/views/calculator-widget-view.tsx
%/views/calculator-view `<--` if it would've been a full page.

It should be a not in your face calcukaltor iwtha settingbuttons.
Thesettingshould allow toresize the width and heiht.shouldallow to click lock (if locked itshouldnt be allowed toresizeor move), otherwise you houldbealve to resize and move it freely. Also change the opacity.


Must have:

Project agnostic, meaning everything co-located in 1 folder so i can just copy 1 folder nad it should work.

Clean seperate of concerns code
Quick/ performant
Very KBD accessible.
    - Every number should work
    - Ctrl  or cmd c should copy the output
    - backspace should delete 1 number u typed:  
      E.g. : yuu typed 512512 and type backspace, `51251` should remain
    - `Enter` should submit calculation
    - Ctrl backspace / cmd bkacpsace should go back to the previous screen which was shown prior to the last enter 
    - E;g;? I type 1+ 1 and press enter. You get 2. IF I then press `ctrl + enter` or `cmd + enter` you get back 1 + 1 in screen.
    - Should have a history tab with all previous typings, results etc.
    - - Should only support + - x (or * , should do the same) `/` `-` `+` `x`(or (`*`).
      
      
      Should be very accessible, remembers memeory, has proper shortcuts, hasm icro interactinos, has a settings menu for all visuals aspects, has customizaltalbltion, ac