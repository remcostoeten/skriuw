---
id: "2f48232c-0f2e-463f-a120-33ab9df1595a"
tags: []
sortOrder: 391
preferredEditorMode: "raw"
createdAt: 1655114298616
modifiedAt: 1655114307555
---
appsettings.Development.json
