---
id: "92b136c8-4e93-4d6c-a2db-e9f7f5f74e59"
tags: []
sortOrder: 312
preferredEditorMode: "block"
createdAt: 1676429308588
modifiedAt: 1676429313622
---
Daphne 

Tbh denk ik dat jij maar even goed voor jezelf moet nadenken of je nog wel vrienden met mij wilt zijn.

Ik weet niet wat er verandert is maar ik ben de afgelopen maanden niet anders gaan doen en bijna elk gesprek loopt gewoon uit op dat ik jou irriter

Ik doe nief anders dus kan het ook niet echt veranderen dat. Kan zijn dat ik het groter maak dan hoe het is voor jou maar lijkt alsof het wachten is  tot het echt oeme ruzie.

Of we nou een relatie hebben of niet, het komt eerder over alsof we haat hebben naar elkaar ipv een goede geschiedenis h

- [ ]