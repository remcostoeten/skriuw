---
id: "a0f8c637-07cb-461d-a2e2-436524cd7cad"
tags: []
sortOrder: 360
preferredEditorMode: "raw"
createdAt: 1660247085595
modifiedAt: 1660327143502
---
Wifi wachtwoords
Kotter12!


 192.168.123.254
Router pw:  33269412


Je huidige wifi-naam (SSID) is:	
Ziggo3EAC697

Voer een nieuwe wifi SSID in: Stoeten
Je huidige wifi wachtwoord is : aU7zybxsh5pE
Voer een nieuw wachtwoord in: Kotter128531cs





Je nieuwe instellingen wachtwoord is:
Wachtwoord:	Kotter128531cs
https://gyazo.com/dc6d845da39759fb2a1ce4c11d9be26c?token=25792f33d51f9b0fc1b90be6f436ebbc

op wifi: http://192.168.178.1/

Je nieuwe wifi-instellingen
Wifi-netwerknaam (SSID):	Stoeten
Wachtwoord:	aU7zybxsh5pE
