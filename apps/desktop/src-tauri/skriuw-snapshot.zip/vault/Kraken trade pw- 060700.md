---
id: "bbc2c036-f427-4863-8e08-b4a208cf2892"
tags: []
sortOrder: 425
preferredEditorMode: "raw"
createdAt: 1640752781770
modifiedAt: 1640753269097
---
Kraken trade pw: 060700

0.073942 eth = 281.55