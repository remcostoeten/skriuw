---
id: "abc7d6b0a4e1488f919e06e0f19772b1"
tags: []
sortOrder: 72
preferredEditorMode: "raw"
createdAt: 1754896842868
modifiedAt: 1754897285973
---
Nou omdat je niet in ging op wat ik er van vond en daarna wat negeerd en niks meer zei, terwijl dat 180g anders is van hoe wij contact hebben

Dus vandaar dat ik zei moet ik zelf de conclusie maar trekken omdat het over kwam als dat je het kut vond en geen zin had om het erover  te hebben 

Had dat berichtje wel wat anders kunnen doen en wellicht waf voorbarig Mja