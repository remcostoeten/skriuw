---
id: "250143a9-24aa-417d-9e58-73083d304c95"
tags: []
sortOrder: 56
preferredEditorMode: "raw"
createdAt: 1762044175844
modifiedAt: 1762044257991
---
Ask if they wnat custom theming. (reocmmended Y/n)

if n just quit and tell them they  can revisit with --argumetn

if y s go ahead and isntall
curl jq gnome-tweaks and i think thatsi t

also install this https://www.pling.com/p/1961175
https://ocs-dl.fra1.cdn.digitaloceanspaces.com/data/files/1672007007/Alterf-PlyrctlF-v2.8.zip?response-content-disposition=attachment%3B%2520Alterf-PlyrctlF-v2.8.zip&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=RWJAQUNCHT7V2NCLZ2AL%2F20251102%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20251102T002745Z&X-Amz-SignedHeaders=host&X-Amz-Expires=3600&X-Amz-Signature=6a8fc954c7243ae94c76a21b75f9138cf8e996d0444720a0fc4cad1c8d39920e


u can read this how to integrate it , do that all in th setups.h 
https://malformed-blog.blogspot.com/2025/02/how-to-apply-theme.html


them dowbnlod this to ~/Downloads

https://ocs-dl.fra1.cdn.digitaloceanspaces.com/data/files/1467909105/ocs-url-3.1.0-1-x86_64.pkg.tar.xz?response-content-disposition=attachment%3B%2520ocs-url-3.1.0-1-x86_64.pkg.tar.xz&X-Amz-Content-Sha256=UNSIGNED-PAYLOAD&X-Amz-Algorithm=AWS4-HMAC-SHA256&X-Amz-Credential=RWJAQUNCHT7V2NCLZ2AL%2F20251102%2Fus-east-1%2Fs3%2Faws4_request&X-Amz-Date=20251102T003157Z&X-Amz-SignedHeaders=host&X-Amz-Expires=3600&X-Amz-Signature=9ad36eb61df71aacdd049b5ce536fbdec4ecb3069d0db8da19cad6c49d2d451a


Move them to:
~/.themes for GTK3 (full folder)
~/.config/gtk-4.0 for GTK4 (only assets, gtk.css, gtk-dark.css)

some docs

Run:

 ./install.sh
Examples:

 ./install.sh -l --tweaks dragon mac outline float -t red 
For more options: ./install.sh --help

----------------------------------------- ‹› ---------------------------------------

🔨 Applying the Theme

GTK3: Use Tuner, Gnome Tweaks or Refine
GTK4: After Manual Installation, restart apps if needed
----------------------------------------- ‹› ---------------------------------------

📦 Flatpak Compatibility

Override Flatpak themes:
sudo flatpak override --filesystem=$HOME/.themes
sudo flatpak override --filesystem=$HOME/.icons
flatpak override --user --filesystem=xdg-config/gtk-4.0
sudo flatpak override --filesystem=xdg-config/gtk-4.0
Tip: Use stylepak for easier Flatpak theming

----------------------------------------- ‹› ---------------------------------------

🔠 Abbreviation Cheat Sheet

Theme-Name-B-MB – Bordered + macOS Buttons
Theme-Name-B-LB – Bordered + Legacy Buttons
Theme-Name-B-GS – Bordered + Gnome Shell
Theme-Name-BL-MB – Borderless + macOS Buttons
Theme-Name-BL-LB – Borderless + Legacy Buttons
Theme-Name-BL-GS – Borderless + Gnome Shell
----------------------------------------- ‹› ---