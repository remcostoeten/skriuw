---
id: "a3ae5f29-05fb-4d78-8f75-189696cc83b7"
tags: []
sortOrder: 348
preferredEditorMode: "raw"
createdAt: 1663336837917
modifiedAt: 1664181463669
---
winegummix 
Zure/ zoete mix

2,95 = 500  = 0,59 per 100g. 
1kg = 5,50 = 0.,55 per 100g

Zure Kersen Haribo 
Perziken
250g = 2,19
500g = 3,99 