---
id: "234f6255-bc2a-4237-a8f5-59d44807244f"
tags: ["next_public_api_base_url","next_public_api_domain"]
sortOrder: 14
preferredEditorMode: "raw"
createdAt: 1773547723749
modifiedAt: 1773547724322
---
NODE_ENV=development
NEXT_PUBLIC_TAGGRS_ENV=development

# Front configuration
FRONT_CHAT_ID=67f70e7f6f2f7c59a07b3b789fed3e1b
FRONT_CHAT_VERIFICATION_SECRET=e29ff43d1ab5f94081623c67adf19ca6
#NEXT_PUBLIC_API_BASE_URL=http://localhost
#NEXT_PUBLIC_API_DOMAIN=http://localhost

NEXT_PUBLIC_API_BASE_URL=https://api.staging-dashboard.fyi
NEXT_PUBLIC_API_DOMAIN=https://api.staging-dashboard.fyi

# API Version (optional, defaults to 0.0.1)
NEXT_PUBLIC_API_VERSION_MAJOR=1
NEXT_PUBLIC_API_VERSION_MINOR=0
NEXT_PUBLIC_API_VERSION_PATCH=1

# Used for correct Redirect URLs.
NEXT_PUBLIC_APP_URL=http://localhost:3000

# Sentry configuration
NEXT_PUBLIC_SENTRY_DSN=
NEXT_PUBLIC_SENTRY_TRACE_SAMPLE_RATE=1.0
SENTRY_AUTH_TOKEN=

# PostHog configuration
NEXT_PUBLIC_POSTHOG_KEY=phc_mlUdYbsqqFQJdQoFXhNEfVuVQdHc6wXy7dVBnHToMAJ
NEXT_PUBLIC_POSTHOG_HOST=https://eu.i.posthog.com

# Google Service Account configuration
GOOGLE_SERVICE_ACCOUNT_PRIVATE_KEY=
GOOGLE_SERVICE_ACCOUNT_EMAIL=

GOOGLE_CLIENT_ID=872536693730-l8n6csbn42ocjnf6o4sb2183o99csl2g.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=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
GOOGLE_REDIRECT_URI=http://localhost:3000/api/auth/callback/google

# Taggrs tracking configuration
NEXT_PUBLIC_TAGGRS_GTM_ID=GTM-1234567
NEXT_PUBLIC_TAGGRS_DOMAIN=happytagging.taggrs.io

# Entri API configuration
ENTRI_APPLICATION_ID=
ENTRI_SECRET=

# Facebook / Meta configuration
NEXT_PUBLIC_FACEBOOK_APP_ID=your_facebook_app_id
NEXT_PUBLIC_FACEBOOK_API_VERSION=v23.0
NEXT_PUBLIC_FACEBOOK_LOGIN_CONFIG_ID=your_login_configuration_id
FACEBOOK_APP_SECRET=your_facebook_app_secret

# Affiliate tracking configuration
AFFILIATE_COOKIE_NAME=affiliate_ref
AFFILIATE_COOKIE_MAX_AGE_DAYS=90