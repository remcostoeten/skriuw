---
id: "e6146df5-0d0b-4dbc-9d20-2767f6533620"
tags: []
sortOrder: 371
preferredEditorMode: "raw"
createdAt: 1658437770766
modifiedAt: 1658437801363
---
21 jul verlofdagen
https://gyazo.com/edcd8158b2b9db3edc7fa212bef8dacf
	#	Verlofsoort	Basisrecht	Leeftijdsuren	Dienstjaren uren	Extra ind.recht	Overgeheveld	Verlofsoort	Opgenomen	Vervallen	Huidig saldo
1	Wettelijk verlof	105.82	0.00	0.00	0.00	0.00	105.82	9.00	0.00	96.82
Resterende uren	Vervaldatum


Resterende uren	Vervaldatum
96.82	01-07-2023
2	Bovenwettelijk verlof	26.45	0.00	0.00	0.00	0.00	26.45	0.00	0.00	26.45