---
id: "4177ed1f530a474b9843ebef40153bed"
tags: []
sortOrder: 75
preferredEditorMode: "raw"
createdAt: 1753619494161
modifiedAt: 1753722960842
---
Goeie dag,

Allereerst mijn excuses voor het lange verwachten. Zoals eerder vermeld privé nogal wat aan de hand waardoor mijn leven compleet op zn kop stond.  Ik begrijp dat het vervelend is- maar heftige familiaire zaken hadden, wat hopelijk enigszins te begrijpen valt- voorrang. 

Een oplichter ben ik niet, maar ik snap dat het zo overkomt. Dus bij dezen een berichtje om het te  regelen

Anyways. Om het nog vervelender voor je te maken ben ik tot de conclusie gekomen dat de 980 tijdens formatteren  (of wellicht daarvooor al) corrupt is geraakt. Een 970 (vijfhonderd GB) kan ik wel aanbieden. 

Indien je die nog graag wilt dan zie ik graag een betaalverzoek tegemoed voor het verschil wat ik je nog verschuldigd ben, en indien niet dan zie ik graag eentje voor het complete bedrag.

Ik ben momenteel niet thuis, ongeacht wat je keuze is kan indien het meezit maandag avond, maar ik vermoed dinsdag ochtend hem op de post doen, (hangt af van of ik in staat ben maandag of dinsdag thuis te komen).. Idem voor de terugbetaling die ik kan doen zodra ik thuis ben (i.v.m. rabo-scanners).

Dus voor de verduidelijking nogmaals excuses de 1tb is geen mogelijkheid meer de 500gb wel. ik compenseer je het verschil uiteraard. En als je geen interesse hebt in 500GB dan krijg je het gehele bedrag retour.

Ik zal waarderen als je bij deze alle ingelichte instanties kan berichten dat het opgelost is, nogmaals ik snap dat het vervelend is, maar ik hoop ook dat je begrip hebt voor nogal zware periode voor iemand.

Groetjes, Remco 

_______________________________________________________-

Beste MegaRobo

Allereerst mijn excuses voor het lange afwezigheid. ik heb een hoop kopers het verteld, ik weet niet meer of ik het bij jou heb gedaan maar mijn leven stond nogal even op z`n kop door overleiden van een zeer belangrijk persoon in mijn leven.

Het is geen excuus, maar de energie, kracht en mentale gemoedstand was (en is eigenlijk) niet om dit af te handelen. Daarnaast is het ook langs me heen gegaan door alle comotie en andere prioriteiten wat hopelijk te begrijpen valt.

Dus nogmaals excuses, ik snap dat het heel frustrerend is, had ik anders moeten afhandelen. Als klap op de vuurpijl nu ik eindelijk wat kracht heb  om alles in orde te maken ben ik tot de conclusie gekomen dat de schijf(ven) gewoon nietzijn wat je verwacht qua kwaliteit en sommige zelfs corrupt.

Dus ik zou graag een betaalverzoek zien zodat ik je kan terugbetalen en ik dit netjes afhandel. Door afgelopen periode is het wat een  rompslomp qua  financien maar ik zal hem Z.S.M. voldoen. Ik heb  twee andere  kopers waar in ik contact via whatsapp/andere media netjes terug betaald, maar mijn account op Tweakers was  (terrecht) verbannen, dus contact informatie had ik niet.

En mocht ik in de toekomst nog  wat leuke schijven weten tebemachtigen (heb hier en daar wat vrienden die soms leuke dealtjes hebben) dan zal ik aan je denken.

Nogmaals mijn welgemeende excuses, had het anders moeten afhandelen maar ik hoop  dat er enigzins begrip is.

Groeten,

Remco/Hoxyz