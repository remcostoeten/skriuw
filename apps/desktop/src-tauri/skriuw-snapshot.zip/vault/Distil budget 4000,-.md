---
id: "b2c444c6-db7d-455c-96a9-422af148047e"
tags: []
sortOrder: 410
preferredEditorMode: "raw"
createdAt: 1645201698022
modifiedAt: 1645479409412
---
Distil budget 4000,-

Keuze laptop: 
2078,- restant = 1992
https://www.coolblue.nl/product/874179/apple-macbook-pro-13-2020-16gb-1tb-apple-m1-space-gray.html

https://www.redshell.nl/apple-macbook-pro-notebook-361-cm-142inch-apple-m-16gb-512gb-ssd-wi-fi-6-80211ax-macos-monterey-grij-1-retail/


Adapter 50 restant = 1942
https://www.usb-c-adapters.nl/product/7-in-1-usb-c-hub-met-hdmi-2-x-usb-3-0-sd-micro-sd-ethernet-usb-c-opladen/

Optie 5 alienware 799,- restant = 1143
https://www.bol.com/nl/nl/p/alienware-aw3420dw-qhd-ultrawide-nano-ips-monitor-34-inch/9200000120866420/?Referrer=ADVNLGOO002021-G-115058520453-S-1076849209895-9200000120866420




Ultrawide monitor 
Dell Ultrasharp u3421WE 34 1007 restant  =943*
https://www.dustin.com/product/5011216069/ultrasharp-u3421we-34-wqhd-ips-219-curved?ssel=false&utm_source=tweakers&utm_medium=pricecompare`

*Optie2: Dell P3421W 724,79 restant = 1225

*Optie3 LG 34GN850 34"ultra gear 789 = 1161 restatn 
https://www.megekko.nl/product/0/287423/LG-34GN850-34-Ultra-Gear-Gaming-Monitor

Optie 4 Acer Nitro ei gamemonitor ei342ckrp 144hz 599 restant = 1351
https://store.acer.com/nl-nl/acer-nitro-ei-gamemonitor-met-gebogen-scherm-ei342ckrp-zwart-um-ce2ee-p01

Laptop pro 2020  13 inch spacegrey keuzes:

16gb 1tb  m1 1999,-
https://www.coolblue.nl/product/874179/apple-macbook-pro-13-2020-16gb-1tb-apple-m1-space-gray.html

16gb 512SSD  m1 8-core 1799,-
https://www.coolblue.nl/product/874178/apple-macbook-pro-13-2020-16gb-512gb-apple-m1-space-gray.html


Laptop pro 2021 14" spacegray keuzes:

16GB 512SSD m1 8core 1999,-
https://www.amazon.nl/dp/B09JRMT2DF/ref=cm_sw_em_r_mt_dp_0EP45828VVQXV2KHXM4K

16GB 1tb SSD 10-core 2584,-
https://www.amac.nl/apple_studentenkorting/apple-macbook-pro-14-inch-m1-pro-chip-10c-cpu-16c-gpu-16gb-1tb-spacegrijs?utm_source=tweakers.net&utm_medium=pricewatch&utm_campaign=tweakers_student


Pro 16" 10 core 16gb 512SSD spacegray 2584,-
https://www.amac.nl/apple_studentenkorting/apple-macbook-pro-16-inch-m1-pro-chip-10c-cpu-16c-gpu-16gb-512gb-spacegrijs

Laptop
- [ ] Pro 2021 14" 16GB 512SSD spacegray 1999,-
https://www.amazon.nl/dp/B09JRMT2DF/ref=cm_sw_em_r_mt_dp_0EP45828VVQXV2KHXM4K

- [ ] Pro 2021 14" 32gb 512SSD spacegray 2709
https://www.mediamarkt.nl/nl/product/_apple-macbook-pro-14-2021-spacegrijs-m1-pro-512-gb-1715588.html?rbtc=twe|pf|1715588||p||&tduid=41068537f6679406426ea893ece90b23
