---
id: "2c0cbee3d53e433686225077efff9294"
tags: []
sortOrder: 137
preferredEditorMode: "block"
createdAt: 1741832814880
modifiedAt: 1741852614728
---
Gisteren 
- exploreation day

Vandaag
- concept of savings verder herschrijven en hopelijk afronden

Vandaag nog thuis, ik hoop volgende week er weer te zijn 