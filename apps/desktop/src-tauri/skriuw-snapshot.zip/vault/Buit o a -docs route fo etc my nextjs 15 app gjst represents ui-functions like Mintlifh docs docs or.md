---
id: "3bc15c2bae0d4d98bda9af8e0100c796"
tags: []
sortOrder: 179
preferredEditorMode: "block"
createdAt: 1734246328428
modifiedAt: 1734246387137
---
Buit o a /docs route fo etc my nextjs 15 app gjst represents ui/functions like Mintlifh docs docs or Fumadocs

Core features:
Left sidebar with use with aut state
aim content area
     - top bar breadcrumbs and entire mdx indexed search
     -main content area is purely mdx renders sign some custom components .
Default app runs in sec/*** and the docs will run in src/docs/index.ts. === /docs 

Allow to load any component in the mdx. Our custom components for now should consist off:
     -side wide search
      - inline code component
       - code block render (. I have one at src/code-block
       - notice, alert, tip, hint
        -pagination as im next or previous doc
        - right sidebar with legends and jump to auto generate

Routing should be just old based as nextjs but then starting from docs. Or we’ll… src/docs

It should function and look like as if vercel would’ve made 

Allow nested docs and folded