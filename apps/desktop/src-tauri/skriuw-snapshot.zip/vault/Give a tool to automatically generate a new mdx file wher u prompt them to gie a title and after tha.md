---
id: "b9e985dd-2d6e-44db-9729-f6bfaec0b93b"
tags: []
sortOrder: 154
preferredEditorMode: "raw"
createdAt: 1739238271291
modifiedAt: 1739238271767
---
Give a tool to automatically generate a new mdx file wher u prompt them to gie a title and after that u prompt to give adescription and after that u fuzzy search in apps/documentation/content and allows to select a folder there to create a file, or  give option to create new directory in /content. 

After that ask for Icon which gives  y/N option, if no just continue ifyes render option select list
Icons
Load the icon property specified by pages and meta files.


import { loader } from 'fumadocs-core/source';
import { icons } from 'lucide-react';
import { createElement } from 'react';
 
loader({
  icon(icon) {
    if (!icon) {
      // You may set a default icon
      return;
    }
 
    if (icon in icons) return createElement(icons[icon as keyof typeof icons]);
  },
});
Icons
Since Fumadocs doesn't include an icon library, you have to convert the icon names to JSX elements in runtime, and render it as a component.

You can use the icon handler from Source API.


After all that ask prompt lastly for a filename and if thats given you create that filename + .mdx in that given directory with this contents:

```mdx
---
title: "The answered prompt"
description: "The answered promt"
title: My Page
icon: HomeIcon <--- optional
full: false <----- can be left out, only if -full is ran
---
---

# The answered title

## System Goals

1. Track user actions and content interactions
2. Monitor system performance and errors
3. Provide insights through an admin dashboard
4. Ensure data privacy and GDPR compliance

## Architecture Overview

Our activity logging system will be built using the following technologies and practices:

- Next.js 15 for the web application framework
- React 19 for the user interface
- Drizzle ORM with SQLite for data storage
- Server Actions for handling log entries
- Server-Side Rendering (SSR) for improved performance and SEO

## Key Components

1. **Logging Service**: A server-side service that handles log entry creation and storage.
2. **Client-Side Logger**: A lightweight client-side module that sends log data to the server.
3. **Admin Dashboard**: A server-rendered page for viewing and analyzing log data.
4. **Database**: SQLite database managed by Drizzle ORM for storing log entries.

## Data Flow

1. User interacts with the application
2. Client-side logger captures the interaction
3. Log data is sent to the server via a Server Action
4. Server Action processes and stores the log entry in the database
5. Admin can view and analyze log data through the dashboard

## Next Steps

<Cards>
  <Card
    title="Setting Up the Project"
    href="/docs/activity-logs/project-setup"
    description="Step-by-step guide to set up the Next.js project with Drizzle ORM"
  />
  <Card
    title="Database Schema Design"
    href="/docs/activity-logs/schema-design"
    description="Designing the database schema for activity logs"
  />
  <Card
    title="Server Actions Implementation"
    href="/docs/activity-logs/server-actions"
    description="Implementing server actions for log processing"
  />
</Cards>


for all have dozens options show to create suff from here
https://fumadocs.vercel.app/docs/ui/page-conventions
https://fumadocs.vercel.app/docs/ui/markdown
https://fumadocs.vercel.app/docs/ui/components
https://fumadocs.vercel.app/docs/ui/mdx/callout
https://fumadocs.vercel.app/docs/ui/mdx/card
https://fumadocs.vercel.app/docs/ui/mdx/codeblock
