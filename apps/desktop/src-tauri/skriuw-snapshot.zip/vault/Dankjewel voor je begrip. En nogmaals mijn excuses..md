---
id: "a4937648-416f-4281-a6aa-01f37cd299de"
tags: []
sortOrder: 76
preferredEditorMode: "raw"
createdAt: 1753696200935
modifiedAt: 1753696303828
---
Dankjewel voor je begrip. En nogmaals mijn excuses.

Door mijn `handels activiteiten` is mijn Tikkie en Revolut (waar ik mee betaal) geblokkeerd. Er wordt vanuit Revolut gevraad naar wat informatie omtremt betaalde tikkies die ik ze heb verschaft waaruit mijn 