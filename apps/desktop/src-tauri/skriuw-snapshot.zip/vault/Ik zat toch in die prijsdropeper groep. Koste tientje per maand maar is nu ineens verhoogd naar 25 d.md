---
id: "7b035c77-c929-4ae1-aab7-3f22c1eb1f57"
tags: []
sortOrder: 343
preferredEditorMode: "raw"
createdAt: 1665333498565
modifiedAt: 1665333571804
---
Ik zat toch in die prijsdropeper groep. Koste tientje per maand maar is nu ineens verhoogd naar 25 dus ben eruit, die robin zit er nog gratis in. Die heeft een bot gemaakt die alles foward naar z'n eigen discord, en ook nog wat andere botjes zoals V&A van tweakers foward. Filters ingebouwd obv EAN/SKU zodat we geen meuk krijgen van amazon. Heeft een websocket erbij waar ik de frontend van ga doen, mooi projectje 