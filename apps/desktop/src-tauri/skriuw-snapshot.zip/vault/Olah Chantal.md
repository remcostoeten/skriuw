---
id: "a932fb2eecc14f8498a1dc424e48b0d2"
tags: []
sortOrder: 196
preferredEditorMode: "block"
createdAt: 1729573042588
modifiedAt: 1729837605007
---
Olah Chantal

Zat wat door m’n matched te scrollen en heb jou nooif gezien. Ik dacht damn leuke meid, tot ik scrolled en die bootypic  zag

Direct, not done en grof maar toch doe ik het; Lig hier in bed door die foto met een stijve lul van 23cm. Zin om binnenkort cocktails te drinken en daarna naar jouw of mijn plek te gaan? Jachtje weg is ook prima, ik heb zo’n gevoel dat jij prima
raad weet met zo’n bizar grote
-url="https://remotedesktop.google.com/_/oauthredirect" --name=$(hostname)