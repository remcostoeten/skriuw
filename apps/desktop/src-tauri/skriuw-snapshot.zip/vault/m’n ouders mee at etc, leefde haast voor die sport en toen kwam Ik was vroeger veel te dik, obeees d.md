---
id: "544cd58e-440d-4b65-92dc-63d11976c874"
tags: []
sortOrder: 268
preferredEditorMode: "raw"
createdAt: 1686335291639
modifiedAt: 1686335697184
---
m’n ouders mee at etc, leefde haast voor die sport en toen kwam Ik was vroeger veel te dik, obeees denk. Toen knop om en van 110 naar 78 gegaan en vanaf die dag elke keer stuk serieuzer sporten, beetje tot autistisch aan toe dat ik al jaren niet meer met ouders mee at en elke dag m'n voeding bijhield etc, maar toen met corona ineens van een op de andere dag  viel m'n weekbesteding + weekend feestjes weg. 

Na lockdowns wel geweest uiteraard maar toen kwam een periode met prive veel opstapelingen. Toxic werkgever / tegen burn out aan zitten, relatie die kut was en  achteraf best veel dingen veroorzaakt hebben in m'n hoofd, medicatie die ik aan het afbouwen was die neveneffecten gaven en m'n moeder is een jaar terug overleden. Dat is 
de eerste week ooit sinds m'n 18e dat ik niet geweest ben en sindsdien gewoon niet meer gegaan, eigenlijk misde ik het eerst niet maar vooral iets wat me tegenhoudt

Gevoel dat ik me moet verantwoorden warom ik niet geweest ben, waarom ik dik 20kg afgevallen. Beetje ons kent ons angst en vooral anxiety. Volg die sport nog wel echt elke dag en heb nul minder passie maar idk

ineens weg en daarna gewoon niet meer lekker op kunnen pakken omdat ik door corona best veel "problemen" had. Werkgever die fucking toxic was / tegen burnout aanzat, relatie die achteraf voor veel kut dingen heeft gezorgd, mediciatie die ik aan het afbouwen was wat veel neveneffecten gaf en m'n moeder is vorig jaar overleden, dat was ook de eerste week in jaren dat ik niet geweest ben, en ben sinds dien gewoon nooit meer gegaan