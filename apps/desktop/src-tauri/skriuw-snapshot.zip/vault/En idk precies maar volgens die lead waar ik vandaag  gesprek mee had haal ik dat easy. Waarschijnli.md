---
id: "f79a44f9-4369-4eb5-9f46-ba0046874b67"
tags: []
sortOrder: 288
preferredEditorMode: "raw"
createdAt: 1681327417668
modifiedAt: 1681327533305
---
En idk precies maar volgens die lead waar ik vandaag  gesprek mee had haal ik dat easy. Waarschijnlijk krijg je dan een opdracht  dat je iets moet maken wat veel voor komt bij hun klanten, maak een in winkelwagen knop met een voeg toe aan favorieten knop ofzo