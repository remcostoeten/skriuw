---
id: "d65041ec-74bf-4eb4-a57c-29c44f1b060d"
tags: []
sortOrder: 302
preferredEditorMode: "raw"
createdAt: 1677948237578
modifiedAt: 1677948672814
---
 Je doet alsof ik een slecht mens ben omdat ik iets probeer te organiseren wat leuk is, ik snap niet waarom je me daarvoor afrekent. Als pietje of nadieh jou vraagt om naar een feest te gaan en ze vervolgens met je over je werkrooster hebben, of andere "probleemn in de planning" proberen op te lossen, of vragen wil je morgen of volgende week wel afspreken dan brand je ze ook niet zo af , ik vind die haat naar mij enkel omdat ik iets wil doen wat jij zelf zei ook wel leuk te vinden nog niet oke

 Ik vind het echt niet oke dat je doet alsof ik een slecht mens ben omdat ik iets probeer te organiseren wat leuk is en jij ook wou. Als pietje of nadieh jou vraagt voor een feest en vervolgens met je meedenkt over je werkrooster of ander "obstacels in de plannming" proberen op te lossen brand je hun ook nie af en maak je ruzie, of als ze voor  over 24h een planning willen. 
 
 Het enige wat ik gvd probeer is iets wat een beetje plezier geeft in het leven voor elkar te krijgen of vertellen dat ik baal. IK word er srs verdrietig van en is ook deels de reden waarom ik zo onzeker ben, omdat ik  gewoon niet meer van mezelf weet hoe ik moet handelen als ik voor zoiets wat in mijn ogen gewoon posit ief is neergezet word als een slecht mens

 Ik snap het gewoon echt niet dat ik uitgescholden moet worden en zo cynisch gedan moet worden, op moet flikkeren als iemand alleen iets wilt plannen, het kan aan mij liggen maar snap niet waarom dat zo erg is