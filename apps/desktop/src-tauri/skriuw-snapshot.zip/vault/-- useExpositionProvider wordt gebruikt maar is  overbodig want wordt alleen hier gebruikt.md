---
id: "c9826b17-e817-4328-8034-511f686a0d1f"
tags: []
sortOrder: 40
preferredEditorMode: "raw"
createdAt: 1750676162132
modifiedAt: 1765200561700
---
        // useExpositionProvider wordt gebruikt maar is  overbodig want wordt alleen hier gebruikt
// Zorg ervoor dat er een nieuwe hoopk komt die deze data beschikbaar maakt zoner providers (wrappers)
// provider -> hook         