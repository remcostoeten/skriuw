---
id: "13f88f24-8fc0-44a4-998d-279ddf371cff"
tags: []
sortOrder: 80
preferredEditorMode: "block"
createdAt: 1752336229753
modifiedAt: 1752336230102
---
DATABASE_URL=libsql://kunze-clone-db-remcostoeten.aws-eu-west-1.turso.io
TURSO_AUTH_TOKEN=eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE3NTIzMjkwMjYsImlkIjoiOGQ4NGUzYmEtZThkNy00ZGM2LTg0Y2QtOGI1ZjAzZDU5NzBiIiwicmlkIjoiNmExNzA5MzAtZDUxNi00ZTE2LThlNzYtMmRmMzA4MzJjMDUwIn0.YmYfDPCrpOc7690FwcgtQaxDKQ32DWzfZYVhHmEhtWU2KpjamfZeKQH04fDA_fPeLY9zzf63In_5vQ2CrMoUDg