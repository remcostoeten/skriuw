---
id: "fef059db-b46a-43ca-aebf-b3599f71a77b"
tags: []
sortOrder: 231
preferredEditorMode: "raw"
createdAt: 1708687960301
modifiedAt: 1708690319309
---
Ok nog ff kleine liev dagboek en that's it dan.

Nou heb het ff laten bezinken. Ben gister best overvallen voornamelijk door onze gesprekken zondag en uberhaupt alle weken, het doen en laten irl. Ik zou het er nog wel graag over willlen hebben zodat ik (of we?) dingen goed begrijpen want ik heb wel wat vragen en begrijp sommige dingen ook gewoon niet. Weet dat het deels gevoel is maar we kunnen goed praten denk ik.

Misschien stel ik me aan maar vind het best raar aanvoelen nu. Ookal zijn we elkaar niks verschuldigd, voelt toch leeg ofzo. Zal voor jou anders zijn I guess. Wil ook nog wel paar aardige of voor mij bijzondere dingen wil vertellen/zeggen maar dan wordt het zon jank bericht

Weet niet precies hoe en wat handig is, denk dat jij dat maar moet beslissen.  Of uberhaupt willen. Anders laat ik je ook en ben je van me af I suppose