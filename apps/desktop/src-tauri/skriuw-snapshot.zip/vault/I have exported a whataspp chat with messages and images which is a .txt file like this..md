---
id: "0c3cd2e0-3689-4ebd-af37-81dd16dff3fb"
tags: []
sortOrder: 272
preferredEditorMode: "raw"
createdAt: 1685449917845
modifiedAt: 1685449918821
---
I have exported a whataspp chat with messages and images which is a .txt file like this. 

Id like to make a page in my tsx + nextjs + firebase app with tailwind that displays these messages and has a seartch functionallity. I want it to be secure, so data has to be stored in firebase.