---
id: "0076eb19-9369-434c-9958-24430d6c91c6"
tags: []
sortOrder: 406
preferredEditorMode: "raw"
createdAt: 1645892370123
modifiedAt: 1645908276302
---
I am a Front End developer with industry experience building websites and web applications. I specialize in JavaScript and have professional experience working with C# and Angular. I also have experience working with Vue, Ruby on Rails, and React. Take a look at my work or get in touch! www.samanthaming.com

Ik ben een Front-end developer 

Developer gespecialiceerd in Front-end met vijf jaar ervaring in het maken van custom Magento 2 webshops. Sinds kort van een agency waar ik de Front-end voor Magento 2 webshops verzorgde gewisseld naar Distil waar wij applicaties en PIM software ontwikkelen voor interne werkzaamheden. Naast enkel de Front-end te ontwikkelen ben ik nu ook bezig met de transitie naar Full-stack developer waar ik me richt op het realiseren van software van A tot Z middels alle moderne Front-end technieken en daarnaast C#, .NET5 & 6.

Tijdens de opleiding media vormgeving heb ik mijn laatste stage gelopen bij Tickles. Na het afronden van mijn stage ben ik blijven plakken als Front-end developer. Binnen gekomen terwijl ik geen regel CSS kon schrijven en gedurende periode beetje bij beetje de fijne kneepjes van het vak geleerd. Over de jaren heen mezelf van complete beginner ontwikkeld tot een Front-end developer die geheel zelfstandig pixelperfect een design vanuit de UX afdeling kan omtoveren tot responsive code. In het geval van Tickles waren dit vrijwel uitsluitend Magento 2 webshops. Over de jaren heen heb ik aan tientallen shops mogen werken die van vrij standaard tot complexe customs designs uiteenliepen.