---
id: "8860923a06fa4ae0a3ab969eb2418d18"
tags: []
sortOrder: 218
preferredEditorMode: "block"
createdAt: 1723951109127
modifiedAt: 1723951226541
---
When click see more templates make it logically shift out left and the others animate in from right (or vice versa).

Also when you clicked more templates there’s no “back to previous templates” button.

ALSO the “soon” buttons should have blocked cursor.

Also there should be 1 button where the user can click and type his own input and then submit 