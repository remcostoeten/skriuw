---
id: "9b332617-f2d2-41e3-91d3-1e1d5aad9a8e"
tags: []
sortOrder: 43
preferredEditorMode: "raw"
createdAt: 1764962986617
modifiedAt: 1764962987011
---
# GitHub API Token (Optional)
# Used to fetch repository data with higher rate limits
# Create a token at: https://github.com/settings/tokens
# Required scopes: read:user, repo (for public repos)
NEXT_PUBLIC_GITHUB_TOKEN=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

# Analytics Configuration
# Enable/disable analytics tracking
NEXT_PUBLIC_ENABLE_ANALYTICS=true

# Session Configuration
# Session duration in milliseconds (default: 30 minutes)
NEXT_PUBLIC_SESSION_DURATION=1800000

# Application URL (for scripts and external references)
NEXT_PUBLIC_APP_URL=http://localhost:3000

# Spotify Configuration
NEXT_PUBLIC_SPOTIFY_CLIENT_ID=01ef36c71f6d40b0a93b03fb33423975
NEXT_PUBLIC_SPOTIFY_REDIRECT_URI=http://127.0.0.1:3000/api/auth/spotify/callback
SPOTIFY_CLIENT_ID=01ef36c71f6d40b0a93b03fb33423975
SPOTIFY_CLIENT_SECRET=7730f76ff980408887013fb754668746
SPOTIFY_REDIRECT_URI=http://127.0.0.1:3000/api/auth/spotify/callback
SPOTIFY_REFRESH_TOKEN=AQDATEYjIOjgh1Pf-aApdBvIjCwmgVUQaLuQsZzgEQJ008CaTRB-LLkfQREUNoVXByRVfyg9SK8nLmTUYmbSY52zCCd9-Z7djt_oqiuTn5dM_V_Yiit3G4W4Mi24lWDoXXQ