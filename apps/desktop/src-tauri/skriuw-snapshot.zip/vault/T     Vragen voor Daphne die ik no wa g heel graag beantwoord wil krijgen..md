---
id: "b2d32674-bf65-45e8-a734-2adb2b71b5eb"
tags: []
sortOrder: 7
preferredEditorMode: "raw"
createdAt: 1675957289839
modifiedAt: 1776887727500
---
T     Vragen voor Daphne die ik no wa g heel graag beantwoord wil krijgen.

2 vragen. Eentje zodat ik kan afsluiten. Andere (als het klopt,wat ik niet hoop/denk) dan denk ik dat jou deze als  persoon ook heel erg helpt, niet zo zeer voor mij. 

Lijkt veel, maar het zijn meerdere observaties/puntjes die samen dit mij laten denken. Dit is een ding waar ik al sinds einde zomer mee zit en gewoon heel graag wil weten/ begrijpen, niet omdat ik jou iets kwalijk neem/verwijt, maar omdat ik het niet een plaatsje kan geven met zoveel onbegrip of vragen. 

Ik soms eerst alles even op en dan de concrete vraag, ik zou het  fijn vinden als je goed wilt luisteren voordat je a ntwoord, en niet zuchten/geiiriteerd worden of directin de verdediging.                 

Disclaimer* ik neem je niks kwalijk hoe je ook antwoord, zolang het maar een oprecht antwoord is en niet weet niet, dan kan ik het een plekje geven.

Alsjeblieft niet geirriteerd worden, volop in de verdediging schieten of weet niet zeggen, want op vele vragen weet je het antwoord wel. Ik word niet boos of neem het je kwalijk wat je ook antwoord, ik wil dit gewoon een plekje geven wat nu niet lukt.



1 = Waarom schaam je je voor mij, voorbeelden van niet reposten, niet op snapchat mogen komen etc. Sinds Secret Forest. Wat is er daar gebeurd, wie ben je tegen gekomen, veel insta lui erbij.

- Waarom mocht ik nooit een post over ons/jou maken terwijl je eerst dat zo graag wou.
- Als ik al een story maakte reposte je het niet
- 

2 = Vragen over misbruik.

Je hoeft van mij niet binnen een minuut te antwoorden Maar ik wil wel graag dat je er even over nadenkt en niet zegt Ik weet het niet. Het kan Natuurlijk wel zo zijn dat je het niet exact weet, maar de eerste twee jaar wou je dit juist wel heel graag dus ergens kan je vast wel wat bedenken.


1) wat is de reden waarom je hier vroeger zelf zo'n groot probleem van maakte Maar de laatste twee jaar nooit wou dat ik een foto van ons of jouw posten.
  
    En als ik al wat op snap poste of naar mensen wou sturen  dan mocht dat nooit. 
  
    Maar ook als ik dan al wat op insta zette over ons dan reposte je het nooit. Of als je zelf iets van vrienden of dump wou posten dan kwam ik nooit in beeld. Onder het mom van We hebben geen foto's Samen niet veel maar wel wat Natuurlijk. Met mijn bday ofzo ook niet terwijl je dat in het begin wel deed.

Of destijds dat collega's niet echt wisten dat je een vriend had terwijl je tegen mij wel zei dat zei wisten dat je naar lemmer ging vaak (hier hebben we het over gehad i know, maar samen met die andere puntjes voelt dat toch naar).

En als jij een Snapchat of beal maakte dan moest ik buiten beeld en Als ik dan in beeld kwam dan stopt hij direct en maakt hij een nieuwe ik ik mocht absoluut niet in beeld komen

het voelt een beetje alsof sinds jij misschien sinds je bent gaan afstuderen jij mij geheim wou houden voor iemand of Iedereen,en dat je hier wat schaamde voor mij of zo, of in ieder geval niet trots was dat ik je vriend was. 



2) hoop dat als het zo is je eerlijk dit durft te vertellen. Je was altijd van hef knuffelen en kusjes geven, maar jd wou laatste tijd niks van dat en ook niet dat ik aan je zat. Haast alsof je nare ervaring hebt gehad. is er ergens in de afgelopen twee jaar iets gebeurd wat hiervoor heeft gezorgd? Intimidatie op stage of wat anders iemand die jou wat heeft aangedaan of is er wat gebeurd waardoor je zo a seksueel bent geworden. 
    