---
id: "9282af98-346f-490a-9d76-8cb10c8ad29e"
tags: ["next_public_instant_app_id"]
sortOrder: 55
preferredEditorMode: "raw"
createdAt: 1762215973025
modifiedAt: 1762215973487
---
NEXT_PUBLIC_INSTANT_APP_ID=23e3c4e5-a3ad-49b7-a4c3-15cb8e19f2c1

#NEXT_PUBLIC_INSTANT_APP_ID=eb1d74d8-f179-4c2c-acc7-d70bf7b86dcd