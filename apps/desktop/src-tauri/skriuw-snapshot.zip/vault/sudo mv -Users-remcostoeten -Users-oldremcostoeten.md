---
id: "8500e47f-bb81-446b-a6cb-e8a7b8c18e8d"
tags: []
sortOrder: 102
preferredEditorMode: "raw"
createdAt: 1748214498377
modifiedAt: 1748220463650
---
sudo mv /Users/remcostoeten /Users/oldremcostoeten

sudo dscl . -change /Users/remcostoeten RecordName remcostoeten oldremcostoeten


sudo dscl . -change /Users/oldremcostoeten NFSHomeDirectory /Users/remcostoeten /Users/oldremcostoeten


sudo dscl . -change /Users/oldremcostoeten RealName "Remco Stoeten" "Old Remco Stoeten"

dscl . -read /Users/oldremcostoeten



run this after renaming before loging out
dscl . -read /Users/oldremcostoeten | grep -E 'RecordName|NFSHomeDirectory'


expected output
RecordName: oldremcostoeten
NFSHomeDirectory: /Users/oldremcostoeten


sudo dscl . -change /Users/oldremcostoeten NFSHomeDirectory /Users/remcostoeten /Users/stoetenremco
oii