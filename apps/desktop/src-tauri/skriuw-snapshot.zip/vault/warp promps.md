---
id: "1b74814a-e17a-4ff3-978a-47c12e45be08"
tags: []
sortOrder: 89
preferredEditorMode: "raw"
createdAt: 1751206541744
modifiedAt: 1751206567156
---
warp promps

Never write classes
Never write `const Foo = () => {` but write `function Foo() {`  instead



Types/interfaces rules in TypeScript:

Always use types in TytpeScrirpt, no Interfaces. 
Prefix ALL types with T. e.g.,  `export type TSomeType = {}`.

If a file only has 1type which Isn't exported by default name it `TProps`