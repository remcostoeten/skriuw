---
id: "de376197-15bd-4a49-a087-8c5685089556"
tags: []
sortOrder: 289
preferredEditorMode: "raw"
createdAt: 1681078930829
modifiedAt: 1681079618951
---
Hierbij nog wat werk. BIj m'n vorige werkgever heb ik vrij veel shops gebouwd maar een paar die mooi vorobeeld zijn zijn https://vedder-vedder.com, https://qhp.com, https://webshop.alcomex.nl en https://shopreworkstaticnojs.netlify.app. Code is uiteraard prive i.v.m werkgever. Prive heb ik ook wel wat projectjes lopenm waar de code wel inzichtelijk is, maar dit zijn enkel projecten die ik voor mezelf bouw of heb gebouwd, de GIT flow kan dus wat rommelig zijn. Projecten zijn hier te vinden https://github.com/remcostoeten en dan met name interessant denk ik https://github.com/remcostoeten/remcostoeten.com React/NextJS project en m'n eigen SCSS boilerplate https://github.com/remcostoeten/own-scss-structure

Wat betreft salarisindicatie is het deels afhankelijk van wat eventueel groei plannen zijn en wat hierin mogelijk is ben ik flexibel tot een bepaald punt i.v.m inkomsteneisen voor woningen. 3750  op 40 uur is waar ik naar kijk. Ik heb is heb ik altijd een 32 of 36 uur gewerkt, maar salaris gebasseerd op 40 uur, dus dat zou een ratio 0.8 of 0.9 zijn. 

Fijne pasen nog, en hopelijk tot snel.