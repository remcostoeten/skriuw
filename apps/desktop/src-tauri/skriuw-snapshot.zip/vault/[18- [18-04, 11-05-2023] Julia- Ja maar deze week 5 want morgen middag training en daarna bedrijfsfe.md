---
id: "9b6cab9792e94f63827288ee415d1f83"
tags: []
sortOrder: 267
preferredEditorMode: "block"
createdAt: 1686368259392
modifiedAt: 1686368339874
---
[18: [18:04, 11/05/2023] Julia: Ja maar deze week 5 want morgen middag training en daarna bedrijfsfeestje
[18:05, 11/05/2023] Yente: ik benoem jou officieel tot de squirt koning 😳

