---
id: "8cfb64bf-c0d6-4879-856f-819500d56de8"
tags: []
sortOrder: 169
preferredEditorMode: "raw"
createdAt: 1734573857303
modifiedAt: 1734573861877
---
https://stackblitz.com/edit/sb1-frtfctem?file=.gitignore