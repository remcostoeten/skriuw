---
id: "e6f3bee2-fd0b-42e2-8f9c-bc344dc7b56d"
tags: []
sortOrder: 163
preferredEditorMode: "raw"
createdAt: 1735909723583
modifiedAt: 1735915565214
---
Goedemiddag Edie. Ik dacht dat het was verplaatst aangezien we hadden afgesproken dat ik nog een onboarding sessie bij zou wonen en gisteren een mailtje kreeg van een. onboarding sessie uitnodiging die was verplaats. Zodoende..  Anyays, betreft de onboarding heb ik het volgende gedaan:

```plaintext
- Secuirty & compliance
- Q4 secuirty
- Onboarding:
    - Acces rights
    - Tech onboarding
    - Gateways
    - Hours
    - Expenses
    -  

- Hoofdstuk twee
    - Git <-- overgeslagen
    - devops intro. 
    - dev processes
    - FRT/RRT <-- overgeslagen

- Hoofdstuk drie
    - Exact api <--- over vergeslagen
    - Splunk <--- gedaaan
    -  Mendt <---- Overgeslagen
    -  Microsfot certification <--- ToDo
```

Zag zo alleen nergens een "check-off" label, vandaar dat niks op done stond. Ik kan m'n browser historie wel doorsturen als dat moet gelden voor "bewijs".

... Ik zie dat ze op done gezet zijn en ik heb het labeltje ook gevonden :')