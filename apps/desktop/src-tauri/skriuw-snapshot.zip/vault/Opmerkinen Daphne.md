---
id: "f8b5aaeb20544647be21e8783031c789"
tags: []
sortOrder: 307
preferredEditorMode: "raw"
createdAt: 1676775848388
modifiedAt: 1677261146765
---
Opmerkinen Daphne
> Moest lachen want zag dat je Snapchats in chat verwijderd had, welke allemaal weet ik niet precies maar sowieso paar piem, alleen die van sok om m'n piemel niet 

Je zegt eerst ik kom naar jou, dan kan ik daarna sporten en naar huis toe eten en tijd ovor mezelf in de avond want ik moet de dag erna dienst tot 10

Of je nou eerst hier komt of eerst gaat sporten en ik dan bij jou komt qua tijd op precies het zelfde aan als jij zegt hoe laat ik bij jou moet zijn. Snap niet waarom je weer zo'n vies leugentje moet maken in de hoop dat ik iets niet herinnerd had