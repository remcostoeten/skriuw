---
id: "ec588ed0-ec3e-473e-9d85-20fc6c4d43d1"
tags: []
sortOrder: 413
preferredEditorMode: "raw"
createdAt: 1644867699277
modifiedAt: 1644952868604
---
Goedendag,

Ik heb vandaag een bestelling van jullie ontvangen echter is deze incompleet. Ik had 3g a-PiHP, 1x glass pipe oil burner skul, 5x 31mm gaasjes en 3x helder pyrex glass pipe. Het pakketje zojuist open gemaakt en de a-PiHP, gaasjes en skull pipe zaten er alleen in. De drie Pyrex pijpjes misde. Vorige bestelling zaten deze er wel gewoon bij. Betreft #5000114969