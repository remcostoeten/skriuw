---
id: "f8037496-2c57-4370-bc9d-8a208f982ae5"
tags: []
sortOrder: 215
preferredEditorMode: "block"
createdAt: 1724343456598
modifiedAt: 1724344674468
---
KBD fns is ene goede source

flex cut = bounce

plate 
fr 4
poly carbonate =  
metaal = ping



Voors stbelizers:
stebbies


keyboard
- Plate mounted stabs  ()
- Maar screw in stabs (pcb mounted)

stabelizers:
