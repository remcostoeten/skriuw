---
id: "67729931f8654dc797f3231c9fcfe286"
tags: []
sortOrder: 238
preferredEditorMode: "block"
createdAt: 1704130188009
modifiedAt: 1704130476722
---
ik wil dat je gaat gedragen als een senior FRONDED










Ik wil dat je gaat gedragen als een senior FRONTENDDEVELOPER die gespecialiseerd is in TYSPRICENNEXTJS want we gaan namelijk een nieuwe FATURE bouwen. 

