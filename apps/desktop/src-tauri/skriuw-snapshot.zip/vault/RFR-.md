---
id: "2c64549f-2b1f-4d60-9bba-749c6490468e"
tags: []
sortOrder: 253
preferredEditorMode: "raw"
createdAt: 1693764862462
modifiedAt: 1693765034836
---
RFR:

Afgelopen periode bezig geweest metfundementals van FSV (hele front-end refactor). Heeft vrij lang geduurd dus deze branches lieper erg ver achter. Ik heb opnieuw vanaf develop gebranched om het reviewen een beetje dragelijk te maken. Ik had bij alle feature branches de code van voorgaande branch nodig. Dus de volgorde van nakijken is belangrijk, aangezien PR 1 gemereged is in 2, 2 in 3 etc. Vandaar ook dat alles een Draft is.