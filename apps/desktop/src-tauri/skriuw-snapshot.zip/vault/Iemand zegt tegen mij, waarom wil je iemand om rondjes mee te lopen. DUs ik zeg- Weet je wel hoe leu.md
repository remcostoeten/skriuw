---
id: "f46b7231-4e38-4f40-ae2a-84e439ee1efa"
tags: []
sortOrder: 290
preferredEditorMode: "raw"
createdAt: 1680981716939
modifiedAt: 1680981865252
---
Iemand zegt tegen mij, waarom wil je iemand om rondjes mee te lopen. DUs ik zeg: Weet je wel hoe leuk dat is op feestjes? Zij zegt, nou ik wandel wel graag maar op feestjes? Ik zeg: Elk rondje is anders op feestjes he. Nou zo ging het wat door wat ze niet snapte, ze werd beetje geirriteerd. Dus ik zeg; zoek dat filmpje eens op. Komt ze terug met: Jezus wat ben jij onrespectvol, dat je mij associeert met zulke junkies balblablabl. Dus toen begon ik overnieuw met. Hoi, alles goed, net zoals ik bij jou deed. "Ik walg van jou met je kut grappen, aso"