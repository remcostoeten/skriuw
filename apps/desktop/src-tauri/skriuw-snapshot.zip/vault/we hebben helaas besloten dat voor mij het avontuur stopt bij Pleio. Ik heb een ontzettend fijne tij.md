---
id: "de15dbfe-fcf3-4a5f-a07f-87e43399888e"
tags: []
sortOrder: 224
preferredEditorMode: "raw"
createdAt: 1713427417141
modifiedAt: 1713427422021
---
we hebben helaas besloten dat voor mij het avontuur stopt bij Pleio. Ik heb een ontzettend fijne tijd gehad, en afgelopen jaar meer skills opgebouwd dan in mijn eerste vijf jaar van mijn carrière, maar de type projecten en benodigde skills zijn wellicht niet optimaal voor de progressie van mijn carrière. Ik wil jullie in ieder geval bedanken voor de hulp en kennisdeling, want daar heb ik veel aan gehad. Ik zal komende teamdag nog aanwezig zijn en officieel tot 31 mei in dienst blijven, maar zal hoogstwaarschijnlijk een paar weken eerder stoppen vanwege vakantiedagen, maar dat is variabel.
Aangezien jullie veel ervaring hebben en een groot netwerk, houd ik me aanbevolen voor eventuele tips qua werkgevers of andere opdrachten. Ik heb vijf jaar agencywerk gedaan en de afgelopen twee jaar volledig remote SaaS. Beide vind ik leuk, behalve als het een agency is waar je elke minuut moet bijhouden en niet autonoom kunt werken of fulltime op kantoor moet zitten.
Ik hou van prototypen maken, fancy UI's ontwerpen, en nieuwe tech uitproberen. Idealiter zoek ik een positie met NextJS (React) + TypeScript, maar ik sta ook zeker open voor frameworks zoals Svelte, SolidJS, Qwik, of andere experimentele. SaaS/startups vind ik interessant, zolang het maar autonoom is, zonder een wantrouwende/micromanagement-cultuur. Ik zou mezelf geen junior noemen, maar ook niet helemaal senior. Dus ik zoek een bedrijf waar ruimte is om te groeien. Locatie maakt me niet veel uit, zolang er maar veel remote mogelijkheden zijn.
Voor wat het waard is, heb ik een GitHub-overzicht van hobbyprojecten en een kleine pagina over mij/werkervaring. (