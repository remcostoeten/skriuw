---
id: "3a0d4150-995f-4cd5-84ef-c0fcca84eec9"
tags: []
sortOrder: 418
preferredEditorMode: "raw"
createdAt: 1643890886316
modifiedAt: 1643892723178
---
Distl

Kwaliteiten van mezelf:

-Leergierig: Passie ligt bij Front-end (of eigenlijk mooie dingen maken). Maar met alleen een mooi design kom je er niet, het moet ook goed werken. Daarom ben ik ook vrij nieuwschierig naar de andere kant van developen (backend). Of dat nou PHP, C#, of diepgaande JS is maakt mij niet uit.

Leergierig voorbeeld: huidige werkgever alleen front-end. Maar vraag geregeld voor diepgaandere issues. Ze willen ook een Magento store bouwen met laravel en Vue en voordat we begonnen zijn vroeg ik al of ik daaraan mocht mee helpen, of mee denken. ---- Of zoals bij jullie gehoord via Wietze over C#. Direct een kleine course gekeken omte ziedn wat het inhield, en sta overal open om te leren.

Ander voorbeeld:  Bij tickles geen mogelijkheid om meer tel eren (js&php) dus veel thuis. Dus hobby projectjees voornamelijk js. Dat heeft mij de laatste jaren het meest doen  leren.


-Met een goede Designer/UX gewerkt die mij heeft aangeleerd om front-end exact zoals het design te vertalen- met waar nodig eigen input


-Communicatief- Ik kan makkelijk problemen voorleggen en toegeven als ik ergens niet uit kom. Ik probeer het zelf eerst wel, maar als ik merk dat ik onnodig veel tijd verspil durf ik wel aan de bel te trekken. Daarnaast einde van de dag/issue/sprint even een reflectie richting PM.

Proactief- Wanneer er een foutje lijktte zijn in de planning geef ik het aan. Cojncret voorbeeld bij tickles is dat m'n planning soms leeg is. Dan communcieer ik direct met develoeprs/project managers om te kijken ofi k wat nadfer skan oppakken

-Zelfstandig - Ik kan prima communcieren maar ik vind het ook heerlijk om alleen te werken. Ik kan uren een project draaien zonder getoord te worden als dat niet nodig is.

-Samenwerken is geen probleem, ideeen uitwisselen/bugs oplossen. Kijken hoe we iets anders aan hadden kunnen pakken - of efficienter. Vooraf we ergens beginnen taakverdeling afpsreken. Even overleggen en vervolgens individueel bezig gaan. ALs iemand hulp nodig heeft elkaar later opzoeken.

-Doorzettingsvoormogen (kwam bij Tickles zonder enig regel CSS/HTML/JS te kunenn schrijven). Vertaald zich ook door in het sporten, crypto

Waarom?
Wietze vertelde me al vaker dat het een leuk bedrijf was. Met wietze kon ik het goed vinden. Daniel ook. Tickles verandert de bedrijfsfilosofie waardoor ik het minder naar m'n zin heb. Ik wil doorgroeien.

-Lasolec ook een grote cae wat interessant is.
Groot bedrijf, Daniel en wietse impliceert dat niveau hoog is en ik veel kan leren.

Vragen:
-Wat zijn julllie core projecten?
-Veel nieuwe projecten?
-Hoeveel man persooneel exact?
-Wat zouden exacte taken zijn
-Zou een auto bij vast contract mogelijk zijn?
