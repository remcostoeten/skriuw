---
id: "e8fe38ea-50ab-46ba-8624-f86bccca2e26"
tags: []
sortOrder: 139
preferredEditorMode: "raw"
createdAt: 1741685309721
modifiedAt: 1741744492027
---
Will come. A lot, waar weet ik nog niet maar het gaat een hele boel zijn.

Maar zal eerst zorgen dat jij aan je behoeften bent en een goede tijd voorzien ben 