---
id: "a9ae0a5a-c9b0-424c-87e3-cef4a8b27343"
tags: []
sortOrder: 322
preferredEditorMode: "raw"
createdAt: 1671629014662
modifiedAt: 1673613113926
---
Loon  periode 9 
2727  =  netto 2242.24
108.42= reiskosten
Samen bruto 2829.99
Netto 2346.23
Uurloon = 17.48


Periode 10
2925 = netto  2359.38
108.42  reiskosten
Samen bruto 3027.8 
netto2481.98
Uurloon = 18.75

Periode 6
2700 = netto 2226.17y
106.42 reiskosten
Samen bruto 2803.04
Netto 2329.21
Uurloon = 17.31
