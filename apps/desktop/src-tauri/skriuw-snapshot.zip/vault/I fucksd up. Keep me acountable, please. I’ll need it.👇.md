---
id: "ffc049cbdad44155977eee89e98d9be5"
tags: []
sortOrder: 46
preferredEditorMode: "raw"
createdAt: 1764045815865
modifiedAt: 1764048495900
---
I fucksd up. Keep me acountable, please. I’ll need it.👇

tldr: Remco bestaat nog, leeft echter al jaren niet meer. 2faced, Isolatie, de-realisatie 