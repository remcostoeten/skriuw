---
id: "fc4fa3c3-fe82-45b8-9ffd-d063525df239"
tags: []
sortOrder: 304
preferredEditorMode: "raw"
createdAt: 1677429679180
modifiedAt: 1677443644437
---
Het gaat, is ook uit met daphne dus dat is wel beetje shit. Voor werk nog niet gesolliciteerd omdat ik eerst wat skills wou uitbreiden omdat ik bepaalde dingen gewoon nog lang niet op niveua heb, dus 

Dus vooral veel bezig geweest met  code schrijven om m'n github (site waar je code opgeslagen wordt) te vullen zodat ze m;'n style van code schrijven kunnen inzien en om shit te oefenen. Eerst twee kleine dingen gedaan https://notifications-challenge.netlify.app/ en https://app.netlify.com/sites/remcostoeten-multistepform/overview en nu al tijdje bezig met remcostoeten.com, lijkt op de voorkant vrij weinig maar onderwater echt heel veel shit gemaakt  zoals login systeem en andere random shit  wat ik moet kunnen


