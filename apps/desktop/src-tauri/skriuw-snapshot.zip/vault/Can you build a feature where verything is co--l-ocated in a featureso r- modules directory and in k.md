---
id: "f406dfec-7e4f-4dcc-8ac6-4534cdde7891"
tags: []
sortOrder: 157
preferredEditorMode: "raw"
createdAt: 1738596216527
modifiedAt: 1738598270205
---
Can you build a feature where verything is co--l-ocated in a featureso r- modules directory and in kebab case and heavy oon seperat of concerns and mostly SSR. T his should a be tool that is used to register/document agreements and rules  regarding a new job. I should be able to create new folders with a title , optinoal emoji (instead of the folder icon) and colorize it  (optional). It should have full C RUD functionallity regarding a queries/ mutation pattern stored in Zustand storage for now, migration to an ORM with postgres sshould be a breeze so try makeing it agnostic as possible. Heavy on seperate of concerns means that these  mutations should be located in src/features(or modules)/agreements/server/queries/index.ts 
This index.ts is resposive only for exporting individual function files like so: export * from './create-agreeemnt'

Besids creating folders I want to be able to create notes, or agreements, or stuff related to that inside a folder. Again with full CRUD. On clicking of a created item in the folder you should be forwarded to the note page which contains a google-drive or notion like enviorment allowing to set title and all t he needed formatting options you'd expect. A  save button which sa ves in storage for now.

Basic layout is a tree with the folders and items, if empty a create folder structure and then allow creation of items.

Each function shouild have its own name with docstring and jsdoc. at author  remco stoeten and below th at a at descriptino with one or two lines max.

Use functions instead of arrrow constants for this.

Same code style should be used for the following folders;
src/features(or modules)/agreement/server
src/features(or modules)/agreement/server/queries
src/features(or modules)/agreement/server/mutations
src/features(or modules)/agreement/server/models (holds zod valiations)

Other folder structurs should be 

src/features(or modules)/agreement/component <- moduile specific components
src/features(or modules)/agreement/hooks 
src/features(or modules)/agreement/helpers <--  utilities
src/features(or modules)/agreement/types

Every project has certain components and hooks that are used more than once and not entierly module/feature specific,.FOr example SHADCN compoents or a date helper
 
 This should be sitting in 
 src/shared/*
 src/shared/components/ui  <--- shadcn 
 Also here we use the index.ts approach
 src/shared/components/ui/inex.ts
 export * from ',/card'
 export * from './button' etc

src/shared/hooks/index.ts
src/shared/types, helpers etc etc

Which means that I can impot all queries, mutations, ui components etc like so : import {  a, b, c f rom './path/to/root/where/index.ts


For the note creation I want it do be handles via the package 'Plate' https://github.com/udecode/plate
a rich text editor for ai and shadcn

To make life easy use the plate ai editor template which can be installed like so: 
Features
Next.js 15 App Directory
Plate editor
shadcn/ui
Installation
Choose one of these methods:

1. Using CLI (Recommended)
npx shadcx@latest init plate
npx shadcx@latest add plate/editor-ai

docs can be found here.

https://platejs.org/docs



Make the entire ui  of the application Vercle/shadcn style - thus v ery dark and sleek