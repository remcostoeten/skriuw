---
id: "a2623151a29d4420aad4a2115a87a688"
tags: []
sortOrder: 140
preferredEditorMode: "block"
createdAt: 1741578371133
modifiedAt: 1741580411159
---
Hey FP kunnen wij straks even paar minuutjes zitten? Ik zit met een klein dingetje ik m’n maag die ik even wil bespreken.



Zoals je weet verdiende ik bij m’n vorige werkgever €1000,- meer. Nu heb ik bij jullie een week gemist waardoor m’n loon significant lager was, opzich geen probleem. Weze het dat ik probeer zoveel mogelijk te sparen en dus automatisch sparen ingesteld heb op Rabo-tijdslot sparen, maar dan op m’n oude loon wat dus betekent dat ik spaargeld gebaseerd op €4600,- automatisch heb laten overboeken daar waar ik €3600 * 0.75 ongeveer heb ontvangen van jullie.

Ik probeer vrij minimalistisch te leven omwille van uit huis gaan dus ik heb een budget voor mezelf en de rest spaar ik (op tijdslot dus zodat ik er ook niet bij kan en iets meer rente ontvang). Maar dit ben ik dus vergeten aan te passen en dat resulteert in dat. 

p

