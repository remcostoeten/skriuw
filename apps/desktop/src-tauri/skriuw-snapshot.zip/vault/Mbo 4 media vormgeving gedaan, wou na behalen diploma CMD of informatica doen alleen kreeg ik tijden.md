---
id: "5e4d2e26-d3cb-4f8e-a35f-f939567fcef3"
tags: []
sortOrder: 19
preferredEditorMode: "raw"
createdAt: 1683545542364
modifiedAt: 1771246044739
---
Mbo 4 media vormgeving gedaan, wou na behalen diploma CMD of informatica doen alleen kreeg ik tijdens m'n laatste stage bij Tickles Digital Agency een baan aangeboden. Hier vijf jaar lang Custom magento 2 webshops gebouwd. Tientallen shops maar o.a front-end van https://www.vedder-vedder.com/  https://www.qhp.nl/ https://webshop.alcomex.nl/ https://shop.buma.com/ van nieuw naar oud. Code hiervan is uiteraard niet beschikbaar. Daarna inhouse bij Distil (Lasaulec), hier wat inhouse SaaS proejctje gedaan en de complete shop opnieuw gebouwd (staat nog niet live, kleine statische snippet hier: https://shopreworkstaticnojs.netlify.app/).

Dan m'n eigen code op  https://github.com/remcostoeten en dan voornamelijk mijn NextJS (react) project. Site waar ik bouw waar ik zin in heb omte oefenen. Kleine kanttekening dat er een boel kapot is; is een playground site. https://github.com/remcostoeten/remcostoeten.com  https://remcostoeten.com/tasks is  een leuke om in te zien (komt zo online)

En mijn eigen SCSS boilerplate misschien ook wel iets om mee te sturen. https://github.com/remcostoeten/own-scss-structure

Voor de rest actief in dev communties en veel bezig met Nextjs/react maar heb ook interessse in Svelte, Vue en Angular.