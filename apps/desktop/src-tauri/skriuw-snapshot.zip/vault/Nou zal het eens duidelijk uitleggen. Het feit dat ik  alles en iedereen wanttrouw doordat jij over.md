---
id: "2cc582fe-993c-4115-ba3a-6325d983f2c0"
tags: []
sortOrder: 293
preferredEditorMode: "raw"
createdAt: 1679607429614
modifiedAt: 1679607592606
---
Nou zal het eens duidelijk uitleggen. Het feit dat ik  alles en iedereen wanttrouw doordat jij over fucking veel dingen in onze relatie loog van klein tot groot. En nu we geen relatie hebben, lieg je nog meer, zo afgelopen week al een handvol dingen wat totaal niet nodig is. Waar het in het specifiek over gaat:


