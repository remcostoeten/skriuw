---
id: "17849b67-6444-4d5e-a2ce-c10d70ab95b9"
tags: []
sortOrder: 331
preferredEditorMode: "raw"
createdAt: 1668555438425
modifiedAt: 1668557316298
---
Your message really made impact which does"t happen quick so you know how to word it.  I feel like I need to clear some things since  the way i make you feel is a 180 degrees from what i'm actually thinking and I think that should be spoken out.

I do somewhat see what you mea with hijackig topics, but the intenntion is usually to troubleshoot my problems without creating dozes of threads. You've noticed i ran into alot of problems which i"ve troubleshooted for hours on hours prior to posting on the forums. I'm not sure if it's  a language barrier from my side since i'm not native eng but I have not itetially blamed you or your software. I  develop myself and I know how software works, there is no good in blamig someones code

As far i know i have never blamed you personally or let alone anyonehere i the commuity If you really feel like i blamed you for (bluescrees? or sc ripts?) Id like to see what messages you mean since I always try to stay  very neutral but i am the person to gather a lot of information which maybe gave you that feeling.

Lastly regarding the scripting I would also like to understand why you feel that I ignore your feedback? There are two reasons why I create those scripts, one is for self development and the other is to provide something to the community. In the ray tracing problem for example I implemented your feedback expect for the overlay part because I did not understand it fully (you have to understand that I’m a total junior regarding this) but do know that I appreciate it like I’ve spoken out. I’ve spent a lot of time past months on the forums and trying to learn. Maybe my over-active way of communicating makes it seems like I’m this angry muppets ranting about everyone but myself. 

Do know that all my posts and asks for help are with intention of bettering myself and hopefully the community and if I hate one thing in life it’s mocking/bullying. I will tone my activenesss down a notch and lurk for a while. I got constellation running on h22 so that’s nice. Once again sorry for how I made u feel but I hope you get what I’m trying to say. I don’t want drama nor bashing on public forums so that’s why I pm’ed you. Have a good night.

Or me asking if something I experienced was due to the humanized