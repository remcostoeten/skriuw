---
id: "615db2f8-ff3d-435b-b0ab-8adf6cf2d4d3"
tags: []
sortOrder: 101
preferredEditorMode: "raw"
createdAt: 1748654310622
modifiedAt: 1748654312658
---
# Database - Turso SQLite
DATABASE_URL=libsql://sweet-mister-fantastic-remcostoeten.aws-eu-west-1.turso.io
DATABASE_AUTH_TOKEN=eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE3NDg2MDc0NTksImlkIjoiMjQxNzI0NTAtNGUxOC00MTc3LWFlYWItMzM5Y2MzNTIxMmZjIiwicmlkIjoiNjQwMjU2ZTAtNmM1MS00ZjM3LTgzOGEtOTBhN2EzYTczZjI1In0.lj3jv5rRUKk4d0vgzmsm1SP9aTc6s77AHQ9uZRw0d8wbANBgwIj-XahB3Njhl3455bSnxDmXHu1z7DM35mWZAA
JWT_SECRET=YYdy6VF0Crd3imCoz03eeCJtd2Rz6qumq8oZD0huEII=
ADMIN_EMAIL=stoetenremco.rs@gmail.comm

# Node
NODE_ENV=development

# GitHub OAuth
GITHUB_CLIENT_ID=Ov23liH78ToxIuhzb04f
GITHUB_CLIENT_SECRET=979b940876eadf7304c348769fb53f5953b0996e

# Google OAuth
GOOGLE_CLIENT_ID=650774158141-l3p0mi1810e837mk6knlopj9v208lgtr.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=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

DISCORD_CLIENT_ID=1377031733500837989
DISCORD_CLIENT_SECRET=4YA0szcwXRxMdfER2TuVylnAp9085BCU


# App URL - Make sure it's a valid URL format
NEXT_PUBLIC_APP_URL=http://localhost:3000
