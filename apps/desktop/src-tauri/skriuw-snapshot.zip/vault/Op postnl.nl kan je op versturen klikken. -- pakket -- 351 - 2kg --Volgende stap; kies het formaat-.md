---
id: "a99eddec-256d-4239-9735-b7aa506a14ac"
tags: []
sortOrder: 405
preferredEditorMode: "raw"
createdAt: 1645910497698
modifiedAt: 1646077742909
---
Op postnl.nl kan je op versturen klikken. -> pakket -> 351 - 2kg ->Volgende stap; kies het formaat: pakket 0-10kg (anders krijg je geen T&T).   Bij ontvanger je eigen gegevens uiteraard (want jij ontvangt hem).  -> Opslaan & naar betaal overzicht. Dan moet je de afzendgegevens invullen (maakt opzich niks uit, is voor retour eventueel). Kan je mijne invullen dus. Remco Stoeten, Kotter 12, 8531cs Lemmer, remcostoeten@hotmail.com. Na betalen krijg je zo'n pagina met QR code. Als je de URL Van die pagina geeft dan kan ik die QR code laten scannen op postkantoor en kan ik hem morgen voor je versturen. :-)

apihp
2517 2766 28132517 2766 2813