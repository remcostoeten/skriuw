---
id: "ded8b3a2-cd7a-43d3-94ea-6471c347cf7a"
tags: []
sortOrder: 126
preferredEditorMode: "raw"
createdAt: 1742987272695
modifiedAt: 1742987365350
---
https://v0-next-js-e-learning-ui-beta.vercel.app/admin
https://v0.dev/chat/fork-of-next-js-e-learning-ui-UfCVsIHjmaJ?b=WLVYp3bGQ1w


back
https://v0-nuqs-demo-with-popover.vercel.app/?page=1

black
https://v0.dev/chat/fork-of-reusable-widget-shell-zI3zS0O64JJ?b=b_lgB2n5p7uEV



modal state openen
    