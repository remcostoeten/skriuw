---
id: "cde337e4-16a7-4d95-959e-60b4f111a855"
tags: []
sortOrder: 246
preferredEditorMode: "raw"
createdAt: 1699563677551
modifiedAt: 1699574430755
---
dept 
(schatting)
400+ 200 + 200 minimaal

Huidige sessie debt:
100
200
100
250
250
100


Huidige sessie uitgecashed:
50,-

50,-

100
100
50
50



23456 +1

789 = 0
10-j , k , q , ace = --1