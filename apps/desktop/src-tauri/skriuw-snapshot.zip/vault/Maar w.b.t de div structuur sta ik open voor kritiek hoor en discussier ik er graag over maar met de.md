---
id: "04a870dc-5199-42ed-8dba-a4562619b6f2"
tags: []
sortOrder: 350
preferredEditorMode: "raw"
createdAt: 1663000123574
modifiedAt: 1663000494178
---
Maar w.b.t de div structuur sta ik open voor kritiek hoor en discussier ik er graag over maar met de huidige structuur zie ik niet echt in wat overbodig is. De header is als volgt:

<header>
 .header__inner  (rename ik naar outer)
    .logo-wrapper
    .header-outer (wordt header__inner)
    .header__nav-container
      .nav-dropdown

