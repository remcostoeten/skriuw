---
id: "8c424bcda3d24828b99ce687c4c9a23a"
tags: []
sortOrder: 31
preferredEditorMode: "raw"
createdAt: 1768180668767
modifiedAt: 1768180673831
---
I want to have a custom lockdown plugin that allows me to type a certain syntax which then indicates that the module is triggered around a word it should add some sort of dashed, animated border or something indicating that it's a popover if it's hovered or clicked, a section should open a popover or modal, I'm not sure with a demo, it's for demos so to say so for example we can play a GIF in there, or a video with maybe a title and a little bit of additional text to showcase certain projects it should increase and decrease based on the width of the video or GIF or the text that's added in there and also it should be working on mobile the big thing is that I think we need to lazy load the asset that is loaded in there or only load if the state is triggered because otherwise we will have very big pages if our video is loaded on a page load