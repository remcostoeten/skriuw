---
id: "9de0a6588a8448d68261e53ebe1c4100"
tags: []
sortOrder: 65
preferredEditorMode: "raw"
createdAt: 1760321708470
modifiedAt: 1760322065917
---
For the blank page create a constant file where u export scream cap constants 

Also create a mock res which mimickes the database structure exactly to see now things render. Some nested folders and files 



Create a custom nicely styled checkbox / task action for in the / menu which if added adds a aesthetic checkbox + title + optional due date, categorie an nested child tasks. Should be submerged right into the editor 