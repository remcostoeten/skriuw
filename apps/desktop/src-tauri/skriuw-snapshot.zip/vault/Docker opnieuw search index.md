---
id: "6fa28522-9a59-4c6f-95b1-16dc601a29e8"
tags: []
sortOrder: 265
preferredEditorMode: "raw"
createdAt: 1686647509333
modifiedAt: 1686742408576
---
Docker opnieuw search index

docker exec dossier-web-1 /app/src/manage.py update_index
/usr/local/lib/python3.9/site-packages/wagtail/search/index.py:301: RemovedInWagtail60Warning: The partial_match option on SearchField has no effect and will be removed. Use AutocompleteField instead
  warn(
Updating backend: default
default: Rebuilding index default
default: wagtaildocs.Document      .
default: wagtailimages.Image       .
default: wagtailcore.Page          .
default: dossier.ContactPage       .
default: dossier.FaqAndTimelinePage .
default: dossier.BasicPage         .
default: dossier.HomePage          .
default: dossier.FSVPersonalPage
default: news.NewsOverviewPage     .
default: news.NewsArticleDetailPage
default: news.NewsArticlePage      .
default: woo.WOODocument           .
default: woo.WOODocumentsPage      .
default: indexed 79 objects


  localhost:8000/cms
  inloggen via localhost:8000/admin
  remco@pleio.nl
  pleio.   