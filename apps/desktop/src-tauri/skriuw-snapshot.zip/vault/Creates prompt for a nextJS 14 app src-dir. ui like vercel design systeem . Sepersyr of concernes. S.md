---
id: "6f326b74729f49ea9e2207b73e1385d8"
tags: []
sortOrder: 188
preferredEditorMode: "block"
createdAt: 1732508269979
modifiedAt: 1732509975930
---
Creates prompt for a nextJS 14 app src/dir. ui like vercel design systeem . Sepersyr of concernes. Shadcn ui folder goed here src/shared/ui and lib utilize also in shared.

Feature files colocste at src/features/finance.

1 time use components ik src components

Zistsndcfof managment and data persistent. Make easy to migrate Postgres drizzle orm in future  tho .

Build a wealth tracker. When first hit the route have onboarding questions. Goals? Track income, expense, savings, debt

If ljcomd > what’s your income monthly and af which day do u get paid
If expense > any reoccurring monthly expenses? Allow entry of expense wij title amount description optional, labels/category’s , where, when
Individual expenses can be added later 
If savings ask  how much they have. How much they want by which date.

And sent ask them how much the have 

After they showcase party emoji and welcome them

Everything has to be animated via framed motion.

Show all stats. Slow add individual expenses whic substracrcffom monthly income 