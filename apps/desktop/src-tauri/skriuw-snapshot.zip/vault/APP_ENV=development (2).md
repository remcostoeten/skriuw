---
id: "b4d0c5cf-8471-4fbd-9240-fad51d63b6e3"
tags: []
sortOrder: 145
preferredEditorMode: "raw"
createdAt: 1740391937753
modifiedAt: 1740391949203
---
APP_ENV=development
NEXT_PUBLIC_APP_ENV=development

#################
##   BACKEND   ##
#################
BACKEND_ENDPOINT=https://cw.stage.allyoucanlearn.nl
FALLBACK_ENDPOINT=$BACKEND_ENDPOINT
API_ENDPOINT=$BACKEND_ENDPOINT/api

# Change the domain communicated as X-PORTAL-DOMAIN header in API calls:
PORTAL_DOMAIN=$BACKEND_ENDPOINT

##############
##   AUTH   ##
##############
AUTH_COOKIE_NAME=auth_token
BEARER_TOKEN=eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIyMCIsImp0aSI6IjQ1NjdlN2IwMzU2YjUwZWYzZDlhZGFjODU0OTMwMjk5NjViODlkMGVlZjA4NzUyMDlhMzk1ODY5MjYwOWY0YmI0MTI4ODI3MWEwM2Y1MzYwIiwiaWF0IjoxNzM5Mjc5Mjk4Ljg1OTM0OSwibmJmIjoxNzM5Mjc5Mjk4Ljg1OTM1MSwiZXhwIjoxNzcwODE1Mjk4Ljg1NjYwOCwic3ViIjoiOTkyODUiLCJzY29wZXMiOltdfQ.DT38mqinknwkx8SAY5CovdEZQ_i2cigQesIh7WSto25dS0J1cfjsqeFmYewXnqD6-STASPnzq3Yh-iSgDNMv6u32j-WrhtQUVfpvg72utuxQWuWy-8W2pLn09-YV3pciP3xoJZgl8SykZch8aer0DJXxaXc3jTIRiRmorOorr2CL0ykJgAmq_ULcLRx4eFE6h10b9G_PaCQRcduMUc6TdC0IVXkouvd5c5LL2JKf2MsrHSBiyCGu-nclxNs50LGSSqQzDDrGKbNvfI7Jy-q6K_iFD4suALjSJ5qe7pw7Vnovn0vyEp91U8NGq7uLesCrwD1GvqrC3yB1T2NqQ8QIahlbMs8CDpSpjRn1I1LsvqfqFh1oi26-rX2XkeYpkJHxtVfiSu4DIA79hrQkQiiFDgbEBCdPVcoUdU6XMiYGMdXv4k4IGYC7688xqya2wktWkUadwmcG6L4pfih3YEUUr7zCOKNrR9HHBzQobXvEt-DWRxBvR56Tsl8_YUSJbd1CsQOIvhmHD8DoX-8pwNDQZNzOfRyogyqbbzNbf_U4yZjI3khkdugTB3VcWcwROLXrwlVfoWksL1kI4p9g6HeLeFH7rD3upOONDmn1-KvNrSxLMjeFha2gwArNjuU4f2T6pI97SYY5YaAnU98F5oUqAl4EsRYa7IZ844kYjsjMb-A

##################
##  DEV OAUTH   ##
##################
# Only required during development
OAUTH_CLIENT_ID=23
OAUTH_CLIENT_SECRET=# Ask someone with staging database access

# Used to compute the localhost oauth login route during development
NEXT_PUBLIC_DEV_OAUTH_URL=$BACKEND_ENDPOINT
NEXT_PUBLIC_OAUTH_REDIRECT_URL=http://localhost:3000/api/auth/token
NEXT_PUBLIC_OAUTH_CLIENT_ID=23


################
##  New Relic ##
################
NEW_RELIC_ENABLED=false


###################
##   DEBUGGING   ##
###################
NEXT_PUBLIC_DID_IT_RENDER=true
