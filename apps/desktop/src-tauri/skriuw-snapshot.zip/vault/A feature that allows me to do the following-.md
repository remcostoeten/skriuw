---
id: "e969b86d81cf42e69222cb9cbded4892"
tags: []
sortOrder: 78
preferredEditorMode: "raw"
createdAt: 1751847268820
modifiedAt: 1752466939718
---
A feature that allows me to do the following:
- add a income entry

income;
Allow adding a value for monthly kncome.
With that entry a name, optimal description,amount of money and reoccurring payment Boolean. If yes, allow picking a monthly date which it van reoccur

- - add a new dept entry



Remcostoetrn.nl

#1 
In the cms editor I can select an entire sentence e.g a paragraph. Inside that sentence I can highlight individual words which then shows the option to make it a link or highlight it or give if other properties. If I do this, nog only the word gets that particular option I chose but the entire paragraph I’m in. Only the highlighted word should get that option.

#2
When I initially load the page it shows different text / content than when it’s fully loaded did to the database query being slow. We Nescio to find out a way how we can impose it. There may never be a. Situation that other text is shown, thus as there should be no  hardcoddd data 

#3
In the feedback form we have d some used analysis. I want way more user information to get an idea  of who left the feedback 

#4
I want to have a analyrkcxx de se room in the cms which tracks how many unique visitors have visited our site (index) do not track localist . Also we want to see who reoccurred amd visited more often than once.

With these page counts we want all the user information that possible to get a good  view of who my visitors are. Country, platform etc etc.

Raket this inside the admin cms  