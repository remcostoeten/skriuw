---
id: "2801a8db-c17a-4078-bd21-df888818dc0f"
tags: []
sortOrder: 131
preferredEditorMode: "raw"
createdAt: 1742784375330
modifiedAt: 1742784377488
---
https://v0.dev/chat/fork-of-supabase-nav-J1HWiy6V5gL?b=b_t0iWYcVb7l5