---
id: "5545fe20-3bd7-4638-b0f5-c1fd9850153d"
tags: []
sortOrder: 377
preferredEditorMode: "raw"
createdAt: 1657820336187
modifiedAt: 1657820447313
---
Ik heb nog eens even echt alles teruggelezen vanaf waar het begonnen is, voorheen alleen stukjes en ik kan me wel voorstellen dat jij het gevoel had alsof ik over je heen probeerde te lopen, vooral met al die metaforen maar ik zie aan m'n berichten en insane veel typfouten dat ik daar gefrustreerd was omdat je me niet begreep,  maar die lappen teksten snap ik wel dat je het kut vond, dus daar wel m'n excuses voor. 