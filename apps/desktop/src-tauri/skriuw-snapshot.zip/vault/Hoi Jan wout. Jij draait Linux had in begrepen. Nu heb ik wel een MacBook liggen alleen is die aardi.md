---
id: "94032052ca4e49e2954f8e811ac40d7e"
tags: []
sortOrder: 254
preferredEditorMode: "block"
createdAt: 1692261477888
modifiedAt: 1692261483658
---
Hoi Jan wout. Jij draait Linux had in begrepen. Nu heb ik wel een MacBook liggen alleen is die aardig sloom en blaast hij constant op 6000RPM dus heb ik Ubuntu geïnstalleerd op m’n prive desktop. Werkt op op wat random crashes naHoi Jan wout. Jij draait Linux had in begrepen. Nu heb ik wel een MacBook liggen alleen is die aardig sloom en blaast hij constant op 6000RPM dus heb ik Ubuntu geïnstalleerd op m’n prive desktop. Werkt op op wat random crashes na