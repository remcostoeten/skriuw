---
id: "bb52597c788e440092aba2d852aaace1"
tags: []
sortOrder: 220
preferredEditorMode: "block"
createdAt: 1723776448520
modifiedAt: 1723776591915
---
Ik moest een tijdje wachten dus dacht laat ik maar weer eens Tinder opstarten na maanden en kijken of er wat nieuws is. Zie ik 8km verwijdert bij jou. Foutje van tinder of toeval? 🥵