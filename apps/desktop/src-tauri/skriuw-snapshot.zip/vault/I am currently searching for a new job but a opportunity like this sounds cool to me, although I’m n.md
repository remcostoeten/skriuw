---
id: "409db01cef2142dabc50d2ebded6e25e"
tags: []
sortOrder: 291
preferredEditorMode: "block"
createdAt: 1680478912428
modifiedAt: 1680478917362
---
I am currently searching for a new job but a opportunity like this sounds cool to me, although I’m not sure regarding the freelance part, but that’s probably something which we’ll work out.

I have six years of frontend experience mainly in e-commerce and SaaS, and I’d like to think my strong points are the design side  implementing css. I know my way around JavaScript but I wouldn’t classify myself as a senior. I’ve done a little bit off lua also.  I’m not sure what the requirements off your client are regarding the JS side, but who knows I’m the one who can help out. I’ve attached my resume with all contact info and some links to finished projects and stuff.

Cheers,

Remco