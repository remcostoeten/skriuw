---
id: "73ebd0a2-650c-463c-975e-dd0e39750c69"
tags: []
sortOrder: 310
preferredEditorMode: "raw"
createdAt: 1677009249812
modifiedAt: 1677009256329
---
fighter case 
profit 0.003 + 0.005 + 0.007 + 0.015 + 0.003 + 0.017 + 0.947 + 1.882 + .9739 + 2.68 + 2.86  + 2.88 + 3.63 + 2.69 + 0.027 + 1.957 + 0.032 + 1.97 + 1.872  = 25%
