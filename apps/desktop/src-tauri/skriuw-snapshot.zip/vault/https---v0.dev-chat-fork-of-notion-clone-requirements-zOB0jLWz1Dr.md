---
id: "81356e3d-5320-4f7c-a1a4-70df55bd8718"
tags: []
sortOrder: 110
preferredEditorMode: "raw"
createdAt: 1747263438145
modifiedAt: 1747263455811
---
https://v0.dev/chat/fork-of-notion-clone-requirements-zOB0jLWz1Dr

# Recommended for most uses
DATABASE_URL=postgres://neondb_owner:npg_9jzWZCh4XKLH@ep-shrill-brook-a2q89ffv-pooler.eu-central-1.aws.neon.tech/neondb?sslmode=require

# For uses requiring a connection without pgbouncer
DATABASE_URL_UNPOOLED=postgresql://neondb_owner:npg_9jzWZCh4XKLH@ep-shrill-brook-a2q89ffv.eu-central-1.aws.neon.tech/neondb?sslmode=require

# Parameters for constructing your own connection string
PGHOST=ep-shrill-brook-a2q89ffv-pooler.eu-central-1.aws.neon.tech
PGHOST_UNPOOLED=ep-shrill-brook-a2q89ffv.eu-central-1.aws.neon.tech
PGUSER=neondb_owner
PGDATABASE=neondb
PGPASSWORD=npg_9jzWZCh4XKLH

# Parameters for Vercel Postgres Templates
POSTGRES_URL=postgres://neondb_owner:npg_9jzWZCh4XKLH@ep-shrill-brook-a2q89ffv-pooler.eu-central-1.aws.neon.tech/neondb?sslmode=require
POSTGRES_URL_NON_POOLING=postgres://neondb_owner:npg_9jzWZCh4XKLH@ep-shrill-brook-a2q89ffv.eu-central-1.aws.neon.tech/neondb?sslmode=require
POSTGRES_USER=neondb_owner
POSTGRES_HOST=ep-shrill-brook-a2q89ffv-pooler.eu-central-1.aws.neon.tech
POSTGRES_PASSWORD=npg_9jzWZCh4XKLH
POSTGRES_DATABASE=neondb
POSTGRES_URL_NO_SSL=postgres://neondb_owner:npg_9jzWZCh4XKLH@ep-shrill-brook-a2q89ffv-pooler.eu-central-1.aws.neon.tech/neondb
POSTGRES_PRISMA_URL=postgres://neondb_owner:npg_9jzWZCh4XKLH@ep-shrill-brook-a2q89ffv-pooler.eu-central-1.aws.neon.tech/neondb?connect_timeout=15&sslmode=require