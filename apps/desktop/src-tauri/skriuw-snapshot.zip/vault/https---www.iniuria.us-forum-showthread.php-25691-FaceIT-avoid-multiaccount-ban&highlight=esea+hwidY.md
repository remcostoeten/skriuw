---
id: "979d238a-f9fe-4543-a057-88952ff144dd"
tags: []
sortOrder: 384
preferredEditorMode: "raw"
createdAt: 1656438708718
modifiedAt: 1656438712963
---
https://www.iniuria.us/forum/showthread.php?25691-FaceIT-avoid-multiaccount-ban&highlight=esea+hwidYes, just looked it up. A new account will void a GUID.

These are your options.

If you're cheating again, use super legit aimbot settings like 1-1.5 fov, high smooth (also randomized), no RCS (unless it has spread deviation) and no trigger (because they have their own trigger detector, literally)

Otherwise.
1.) VPN with Private IP Address *Important - because you use a VPN (shared) and ip is already blacklisted = Ban*
2.) New e-mail
3.) New SteamID
4.) New Browser (firefox, addons: noscript / random agent spoofer)
5.) Run Privazer/CCleaner to clean up cookies browser

I know for a fact they do not ban HWID's/MAC's because it isn't an actual client like ESEA or CEVO.

Good luck.