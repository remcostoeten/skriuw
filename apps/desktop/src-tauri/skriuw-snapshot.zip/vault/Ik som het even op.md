---
id: "1930f162-8659-46af-b2b8-0488e6ff2589"
tags: []
sortOrder: 357
preferredEditorMode: "raw"
createdAt: 1660673056441
modifiedAt: 1660673078186
---
Ik som het even op

-Ik moet jou wakker bellen maar jij hoort me niet
-Ik vraag enkel heb je 