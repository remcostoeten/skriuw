---
id: "651632c8d1564556b5eec1f4244f77e5"
tags: []
sortOrder: 194
preferredEditorMode: "block"
createdAt: 1729911282990
modifiedAt: 1729911439978
---
Now with auth done make a features that uses that auth.

Finance app or so.. full crud, <Form component from next 15. Shading, ssr, no api routers

Again solid

Make detailed guide from a to z as a part 2 ok tje auth