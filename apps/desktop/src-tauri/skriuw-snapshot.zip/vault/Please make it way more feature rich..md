---
id: "4f5ecd5c0bc840219f355bf1abdbbf0d"
tags: []
sortOrder: 198
preferredEditorMode: "block"
createdAt: 1729825307034
modifiedAt: 1729826350587
---
Please make it way more feature rich.

The ui should look exactly like its Collings from the vercel l them. Idd their design system, style and colors. So it’s dark theme

Functionallity:

Have an icon button which pasdec clipboard ik. The text area
Have icon button which clears textures 
Have Icon button to sort a-z and z-a
Have icon button to reformat the text area to default prettier settings.

Have a bar below the text area with content statistics. Amount of words, letters and lines.

Have a submit button with, if slow api it has a processikg… loading state. Once finished show a toast success via sonner.

then below show a small bar with statistics about the modification: how many letters, strings are remove in how lang seconds and how many likes are left (very important

The output of the text should be rendered in a code block just like u see ok documentation sites. Style it just like the screenshot l. Make sure it has a copy content button which clogs all converted text to clipboard and shows a toast.

Than we need a button that opens a pop-up with the following form ;
a name input optional (if empty use date/timestamp)
Description textarea optional
Radio button with 2 options. Either followers or following with default being followers.
Optional datepicker
And a save button 

Ok save it should trigger a server action WITJ <form action = server action > NO API ROUTE FOR THIS PART OR CLIENT ONSUBMITS. Use optimistic and the  newest form component
Action to save to the database with a schema like this:

Name (if left empty take timestamp)
Optional description field
Chosen Radio button option
Date from the form 
CreatedAt
Lines numbers
Add must be related to the authenticated user