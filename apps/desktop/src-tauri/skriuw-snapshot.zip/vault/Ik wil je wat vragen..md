---
id: "c1526cab-a6b6-4357-90c9-4c8b67ed4fcd"
tags: []
sortOrder: 297
preferredEditorMode: "raw"
createdAt: 1679076930312
modifiedAt: 1679081115601
---
Ik wil je wat vragen.

Als je nee zegt dan ga ik niet discussieren of er op door maar ik ben 
serieus.  Mag ik vanavond bij je komen aub, ik beloof dat ik niet ga zeuren over rela of aan je ga zitten en morgen weer weg ga wanneer jij dat wilt, maar ik word echt gillend gek hier, ik heb zo verschrikkelijk veel anxiety dat ik hyperventileer en constant het idee heb dat ik dingen hoor en zie. Ik heb me nog nooit zo gevoeld, m'n ogen doen gewoon pijn van het huilen en papa doet ook zo fucking kut/boos. Ik weet dat ik jou hier niet mee lastig hoor te vallen maar dit is niet goed iig, ben gewoon bang en voel me niet veilig, dat je huis straks na werk ene rotzooi is of wat dan ook maakt me echt geen fuck uit