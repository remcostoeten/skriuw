---
id: "2211faf8c5324cccbb9cdab3413f47f8"
tags: []
sortOrder: 84
preferredEditorMode: "raw"
createdAt: 1751932074340
modifiedAt: 1751932074340
---
Please could you pay me € 22,50 for 'Es es Dee' at https://tikkie.me/pay/gd1fagvs1d6i7grm9jvs
This link is valid until 22 July