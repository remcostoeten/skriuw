---
id: "81a730dc-8328-4202-a972-7ebca13a1ece"
tags: []
sortOrder: 298
preferredEditorMode: "raw"
createdAt: 1678993338216
modifiedAt: 1678993388147
---
I have this to do app. I also have firebase authentication and database. This todo logs todos  into the firebase database. But everyone with the URL gets the same todo list. I want to only sh ow the todos if     aperson is authenticated, and then have their own unique to do page.