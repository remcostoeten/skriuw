---
id: "9d4586ce34fb4a4db00846de70ddcb55"
tags: []
sortOrder: 35
preferredEditorMode: "raw"
createdAt: 1767074751030
modifiedAt: 1767074848116
---
Can u add a multiplayer aspect where there’s a mode to vote with friends 

- create party
- - share link
- - friends join 
- - they set name
- Host searches 
- Whilst. U can see active connections
- Updates live for all
- Everyone can browse on there own and thumbs up or down a result 
- after n period of time results show
- 