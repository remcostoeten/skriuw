---
id: "168c8600-f568-4cba-a9a5-4750da3d2604"
tags: []
sortOrder: 383
preferredEditorMode: "raw"
createdAt: 1656459428388
modifiedAt: 1656459429052
---
Hierbij bied ik mijn Alienware AW3420DW 120hz ultrawide aan. Monior verkeerd in perfce staat. Geen dode pixels of andere rariteiten. Ik heb hem altijd op een monitorbeugel arm gehad.

Ik doe hem weg omdat ik er twee heb en een van de twee (deze adveretentie) wil omruilen voor wat anders. Ik sta open voor ruilen dus. Monitor is zowel geschikt voor productiviteit/design-vormgeving en gamen.

Ik heb enkel interesse in ultrawide's op 1440p/4k (vanaf 34" dus), maar ook geintereseerd in 38" schermen. Ik sta niet open voor budget VA panelen. Ook wil ik enkel scermen met een hogere refreshrate dan 60. Of het moet om een erg goed paneel gaan, dan wil ik het overwegeneb.Ik wil best bij betalen indien jij een degelijk IPS paneel hebt op 38" of bijvoorbeeld de OLED variant van dit scherm wilt ruilen. Indien je geen ruil wilt doen dan is ver onder de prijs bieden nutteloos. Scherm kost momenteel nog steeds ruim 1000,-.

Monitoren waar ik geintreseerd ik ben met eventuele bijbetaling.
-Alienware AW3423DW OLED
-Alienware AW3821DW
-Dell UltraSharpt 30

+ (U3421WE, -  U3421WE   - U3223QZ 

-Dell UltraSharpt 38" (U3821DW)
-LG UltraGear

Etcetc