---
id: "172a0209d07a4e90b969debbdfa6d5af"
tags: []
sortOrder: 66
preferredEditorMode: "raw"
createdAt: 1758345921126
modifiedAt: 1758346495868
---
Must be 100% perfect on iPhone and feel naive like. Touch areas should be large enough and screen reelestate optimally used.

Storage solution should be indexdb for now with an architecture that can easily be converted into drizzle orm postgresql with server actions.

No authentication for now. Just a mock user with a getuser function thatcrrturn the mock object and a global zustsnd store auth provider.

On first visit have a initialization screen that. Welcomes you ask for your name, euro or dollar preference and then a next button which goes to the next slide that asks u which service u want to use:
- savings
- Expense 
- Income

if either is ticked forward to dashboard which has three sections optimized for iPhone. A savings account which allows u to deposit money (just a integer that accumulates). Also withdraw, and set reoccurring per month on a specific date which allows to project the future.

Then income - same principle, but allow multiple entry’s with a name. Reoccurring or not 

Expenss exactly the same.

Than a total wealth which is savings + income - expense 

And current balance which. Is income - expenses with a indicator of date month period.

You should be able to plan future payments wether it’s expenses or income and on that you should be able to scroll through a timeline and see the amount in theory with the reoccurrings

Make sure it saves on close 
