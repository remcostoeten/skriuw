---
id: "a11362a6a621464c9b554fa78826201e"
tags: []
sortOrder: 187
preferredEditorMode: "block"
createdAt: 1732769119704
modifiedAt: 1732769741778
---
Since we currently have no database here can u take a user object so we can mock register and get a signed in state?

Once we are able to “fake sign in “ we should get forwarders to a onboarding page. Everything has to be animated. Register page out. Onboarding page in. All elements staggered into each other.

Take a look at the project structure and craze a onboarding feature and service. Features we wrap in a Boolean for the file “features” so feature are easily turned on and off.

Even tho we currently mock a user, do.cfeFe  drizzle Postgres schema in features/onboarding/server/schema.ts and that schema u import in the main schema file.

The onboarding process has three steps. First ask them for their name, username/nicknMe and have a continue. Button


Then step 2: where did they find us and where’d are you here for?
- how did u find is? Buttons with GitHub , Reddit, Google, discord , anywhere else?

- Then ask them what features are they most interested in? Have buttons (nicely animated with hover and active state) with the following features:
- finance
- Notes
- Code snippet storage 
- Tasks
- Text mutate tools
- Other… if prrrsss show an animated textarea with optional context but not mandotsry. 
Then a next button and previous button. With also a visual indicator of how many store  steps they  left 

And lastly an overview to set their bio, date of birth and social handles for GitHub, LinkedIn, personal site, and optimal free form.

Finish button and then animate out saying welcome aboard with a party emoji which is Also animated in and then after 2s redirect to :/dashnkard

Screenshots are purely for rough flow inspiration 