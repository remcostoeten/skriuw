---
id: "0691b525-dcbf-424d-bf71-0a25c5817c9d"
tags: []
sortOrder: 278
preferredEditorMode: "raw"
createdAt: 1683729692306
modifiedAt: 1683733564808
---
Aangezien we het overigens niet echt over mijn werk hebben gehad dacht ik stuur jou nog even wat projectjes op.  O.a. de front-end voor shops zoals https://vedder-vedder.com, https://shop.alcomex.com. https://qhp.com en tientallen anderen gedaan. SaaS projectjes zijn nog in development of prive. Eigen Github met mijn site (die aardig kapot is/NextJS expirmetn is. https://github.com/remcostoeten/remcostoeten.com) en dan met name deze feature ben ik wel trots op, althans de functionaliteit, de UI moet opnieuw. https://remcostoeten.com/tasks. En deze is misschien wel leuk https://github.com/remcostoeten/own-scss-structure

En bij m'n laatste werkgever is dit wel een leuk voorbeeld. De huidige caegorie (en dan even de DOM/HTML vergelijken) https://www.lasaulec.nl/categories/aandrijftechniek/asafdichtingen met de versie waar ik mee bezig was (oude statische snippet) https://shopreworkstaticnojs.netlify.app/