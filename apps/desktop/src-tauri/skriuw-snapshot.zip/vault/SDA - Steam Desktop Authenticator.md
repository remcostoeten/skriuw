---
id: "60b06f0c-bd3b-47bd-a84d-617cf81acb69"
tags: []
sortOrder: 18
preferredEditorMode: "raw"
createdAt: 1664978728202
modifiedAt: 1771533643113
---
SDA - Steam Desktop Authenticator
The Mobile authenticator revocation code R5040v

remcovier:
SDA  steam desktop authenticator
recovery code R22639