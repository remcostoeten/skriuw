---
id: "5a68bd7ee6e44cf3bac323969902a36e"
tags: []
sortOrder: 142
preferredEditorMode: "block"
createdAt: 1739076902422
modifiedAt: 1741492698116
---
Bro ik durf het haast niet te zeggen maar ik heb wat kk doms gedaan. Ik heb redelijk wat schulden afbetaald toch, dus ik automatisch sparen weer aangezet, maar nu heb ik 1250€ op m’n spaar staan alleen die is locked omdat ik naar m’n rabo spaarslot heb overgeboekt 😭😭

Denk dat ik +-100€ benzine nodig ben en dan wat roken tot aan loon, maar lijkt me beste om in delen te doen aangezien ik hopelijk komende week €1100 verzekeringsgeld krijg voor schade op m’n auto. Zolang ik morgen en donderdag maar op werk kan komen

Ik wil je best wel weer rente geven en screenshots sturen van tankafschrift,l. Heb al CC en rood staan proberen aan te vragen maar beide doen het niet..
