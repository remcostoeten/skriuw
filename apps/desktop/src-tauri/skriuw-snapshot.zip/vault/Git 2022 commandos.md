---
id: "ad70883f-ea38-41e7-b141-f2e24f6d54d5"
tags: []
sortOrder: 328
preferredEditorMode: "raw"
createdAt: 1669129252365
modifiedAt: 1669129371272
---
Git 2022 commandos
Van branch wisselen nieuwe versie
Oud - nieuw
git checkout *Branchnaam*  - > git switch *branchnaam*

Een specifieke file pullen van een branche zonder te mergen.
Eerst git switch naar de feature waar de file in moet.
git switch feature/cattegory
 git restore --source feature/category PimShop\wwwroot\css\scss\layout\_search-autocomplete.scss


 Dus `git restore --source *branchnaam* *relative filepath*`