---
id: "69341433-9318-402c-aee0-9935ba5b54a4"
tags: []
sortOrder: 385
preferredEditorMode: "raw"
createdAt: 1656279896441
modifiedAt: 1656279977248
---
img thumbnail fix
gci *.jpg | % { magick convert "$_" "$_"}; gci *.png | % { magick convert "$_" "$_"}