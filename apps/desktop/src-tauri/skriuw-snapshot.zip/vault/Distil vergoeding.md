---
id: "b9360cae-3a0c-4f33-b029-929959478a53"
tags: []
sortOrder: 408
preferredEditorMode: "raw"
createdAt: 1645741231007
modifiedAt: 1645752108938
---
Distil vergoeding

Enkele rijs naar Lasulec = 22.3km totaal 44.6 = 120.353

Per medewerker wordt een maandvergoeding verstrekt. De berekening is
overeenkomstig de wettelijk voorgeschreven formule: woon-werkafstand x 2 x fiscaal
maximaal onbelaste vergoeding per kilometer x 214 dagen x 1/12. De woonwerkafstand is maximaal 20 kilometer enkele reis. De maximale maandvergoeding
bedraagt daarmee € 135,53.

40 * 0.19 * 214 * 1/12 = 135.53

44.6 * 0.19 * 214 * 1/12 = 151.11

44.6 * 0.19 * 214 = 1813.436 1450.4