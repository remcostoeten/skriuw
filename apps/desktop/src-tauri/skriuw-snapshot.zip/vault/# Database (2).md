---
id: "a5a39976-a4f9-4a6b-93b8-7539280b6a7a"
tags: []
sortOrder: 33
preferredEditorMode: "raw"
createdAt: 1767966116662
modifiedAt: 1767966215515
---
# Database
# neon.tech or local postgres
DATABASE_URL=postgresql://neondb_owner:npg_dJc2klP7iunC@ep-dark-surf-ag83l04h-pooler.c-2.eu-central-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require

# Better Auth
# Generate with: openssl rand -base64 32
BETTER_AUTH_SECRET="GuEeGnso9QOcHYQMCTJLXMbESvxytjsLp8yzDwkOIto="
# Base URL for auth, usually your frontend
BETTER_AUTH_URL="http://localhost:6967"

# GitHub OAuth Credentials (Zentjes)

# GitHub OAuth Credentials (Zen)
GITHUB_CLIENT_ID="Ov23li3yMNDncwlatKdp"
GITHUB_CLIENT_SECRET="5c3e2c352a6f9a0932a8a1cf7c08b185aa3a10ca"

GOOGLE_CLIENT_ID=""
GOOGLE_CLIENT_SECRET=""

# Client Side (Public)
NEXT_PUBLIC_API_URL="http://localhost:6967"
NEXT_PUBLIC_APP_URL="http://localhost:6967"

# Environment
NODE_ENV="development"
PORT=6967
SKIP_ENV_VALIDATION=false


_____________________DB________________--
# Database
# neon.tech or local postgres
DATABASE_URL=postgresql://neondb_owner:npg_dJc2klP7iunC@ep-dark-surf-ag83l04h-pooler.c-2.eu-central-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require

# Better Auth
# Generate with: openssl rand -base64 32
BETTER_AUTH_SECRET="GuEeGnso9QOcHYQMCTJLXMbESvxytjsLp8yzDwkOIto="
# Base URL for auth, usually your frontend
BETTER_AUTH_URL="http://localhost:6769"

GOOGLE_CLIENT_ID="x"
GOOGLE_CLIENT_SECRET="x"

# GitHub OAuth Credentials (Zentjes)
GITHUB_CLIENT_ID="Ov23liufhy9nouavlBEX"
GITHUB_CLIENT_SECRET="46c7d783eeb4f8705f468c923050334b76399c2b"

# Client Side (Public)
NEXT_PUBLIC_API_URL="http://localhost:3001"
NEXT_PUBLIC_APP_URL="http://localhost:6967"

# Environment
NODE_ENV="development"
PORT=3001
SKIP_ENV_VALIDATION=false


___________________WEB_____________________

# Database
# neon.tech or local postgres
DATABASE_URL=postgresql://neondb_owner:npg_dJc2klP7iunC@ep-dark-surf-ag83l04h-pooler.c-2.eu-central-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require

# Better Auth
# Generate with: openssl rand -base64 32
BETTER_AUTH_SECRET="GuEeGnso9QOcHYQMCTJLXMbESvxytjsLp8yzDwkOIto="
# Base URL for auth, usually your frontend
BETTER_AUTH_URL="http://localhost:6967"

# Social Auth Providers
GITHUB_CLIENT_ID="Ov23li3yMNDncwlatKdp"
GITHUB_CLIENT_SECRET="5c3e2c352a6f9a0932a8a1cf7c08b185aa3a10ca"
GOOGLE_CLIENT_ID=""
GOOGLE_CLIENT_SECRET=""

# Client Side (Public)
NEXT_PUBLIC_API_URL="http://localhost:6967"
NEXT_PUBLIC_APP_URL="http://localhost:6967"

# Environment
NODE_ENV="development"
PORT=6967
SKIP_ENV_VALIDATION=false
NEXT_PUBLIC_BETTER_AUTH_URL="http://localhost:6967" 