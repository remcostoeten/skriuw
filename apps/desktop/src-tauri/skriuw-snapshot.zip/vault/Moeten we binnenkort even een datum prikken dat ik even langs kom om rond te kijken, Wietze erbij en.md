---
id: "f8b00ca3-aa92-4562-92cd-6b8192e2367f"
tags: []
sortOrder: 411
preferredEditorMode: "raw"
createdAt: 1645091686716
modifiedAt: 1645092114340
---
Moeten we binnenkort even een datum prikken dat ik even langs kom om rond te kijken, Wietze erbij en even bespreken hoe en wat ik exact ga doen met projecten, Wietze zei in ieder geval dat ik dat evne bij jou moest aanvragen en dan komt hij op dat tijdstip ook even naar kantoor.

En ik had nog een vraag of er ook een vast budget is voor apparatuur? Heb het met Wietze en Daniel even over gehad en een Macbookje lijkt me toch wel het fijnst werken i.c.m eventueel een mooi monitor voor thuiswerkstation, met front-end is mijn ervaring dat je hierin wel bepaalde schermen wilt i.v.m kleurenoverbracht etc. Maar als jij zegt dat er daar geen budget voor is, of ik weet hoeveel ik intotaal ongeveer zou mogen spenderen aan die twee dan kan ik dat even concretiseren voor je. Maar als daar geen budget (of de noodzaak van gezien wordt :-p) voor is dan begrijp ik dat ook wel