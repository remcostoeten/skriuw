---
id: "35af6625d6164798896bd7082901c2f9"
tags: []
sortOrder: 178
preferredEditorMode: "block"
createdAt: 1734247002127
modifiedAt: 1734248074330
---
Men we zijn op kantoor voor de 7e de dag deze week. Woensdag product launch en dan rust

Dus je zult nog even geduld moeten hebben, of nog wat tijd om te oefenen en je outfit te bedenken 

Nee ik bedoeld mannen praten publiekelijk sneller over seks dus daarom lijkt dat zo, dat bedoelde ik met schreeuwen.

Maar goed bruggetje. Schreeuw je een beetje of wat zijn dos en donts? De een vindt het geio om in haar kont geturfd of gespoten te worden en de ander vindt en klap op haar bil al teveel.

En hoe kan je dat op meerdere dingen opvatten? Om je een idee te geven: lengte zo’n 22 en omtrek 17.