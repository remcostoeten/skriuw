---
id: "c52859bc-9cd7-4d85-9766-edaf1071b3d5"
tags: []
sortOrder: 415
preferredEditorMode: "raw"
createdAt: 1644603171048
modifiedAt: 1644603217620
---
Glazen sprayers + 10ml = +-70/s