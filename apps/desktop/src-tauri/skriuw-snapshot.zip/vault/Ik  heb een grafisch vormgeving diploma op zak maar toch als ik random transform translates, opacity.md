---
id: "a2eb8b8c-41b4-4183-a107-4d1ab78cd47b"
tags: []
sortOrder: 287
preferredEditorMode: "raw"
createdAt: 1681414713791
modifiedAt: 1681414762102
---
Ik  heb een grafisch vormgeving diploma op zak maar toch als ik random transform translates, opacity  fades ga toevoegen dan wordt het een niet samenhangend geheel vaak