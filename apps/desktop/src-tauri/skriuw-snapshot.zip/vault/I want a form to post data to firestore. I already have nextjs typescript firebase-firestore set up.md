---
id: "d0632787-6989-4563-be18-de25eccf86a8"
tags: []
sortOrder: 236
preferredEditorMode: "raw"
createdAt: 1706107617595
modifiedAt: 1706108219535
---
I want a form to post data to firestore. I already have nextjs typescript firebase/firestore set up (at @/core/database/firebase).  This is a component where I submit data to firestore. SO i want you to use the exact same syntax.:

IN FIRESTORE.ts
export const addTask = (userId: string, projectId: string, task: Task) =>
  new Promise<string>(async (resolve, reject) => {
    try {
      const userDocRef = doc(db, "users", userId)
      const prjTasksCollRef = collection(
        userDocRef,
        "projects",
        projectId,
        "tasks"
      )
      const safeTask: Task = {
        title: task.title,
        description: task.description ?? "",
        label: task.label,
        status: task.status,
        priority: task.priority ?? 0,
        ...(task.due && { due: task.due }),
        phase: task.phase ?? 0,
      }
      const taskRef = await addDoc(prjTasksCollRef, safeTask)
      if (taskRef.id) {
        return resolve(taskRef.id)
      } else {
        return reject(new Error("Adding task failed!"))
      }
    } catch (e) {
      return reject(new Error("Error adding task: " + e))
    }
  })



IN thge COMPONENT:


  const handleCreateProject = (v: { title: string }) => {
    if (user?.uid) {
      addProject(user.uid, v.title)
        .then(() => {
          form.resetFields()
          messageApi.success("Project Created!")
          dispatch(fetchProjects(user.uid))
        })
        .catch(() => {
          messageApi.error("Failed!")
        })
    }
  }




Now I want you to create me a form that structures the data in  this way: IT is important you follow my exact names and structure since I need to mutate it later.

A form for income which  keeps track off the current date. And models it like so 

Income: 3000,-
Date: 24-01-2024 
IncomeFor:  THISI S A FIELD WHICH IS THE MONTH NAME, BUT 1 MONTH IN ADVANCE. SO LETS SAY THE DATE IS 24-01-2024. This FIELD BECOMES FEBRUARI

IF THE DATE WERE 27-02-2024 THE FIELD WOUILD BECOME MARCH.

Than for keeping track off the dept paid off

NameOfDept: a string, 
amountOFDept: integer
Date:allow for date selection, if not selected take current.
IsPaidOff: Yes or no
AmountPaidOff: a number which gets increased as amountdeposited gets submitted

And then lastly a seperate form with keeping track off what i paid off.

Should contain a select box off NameOfDept. 
amountDeposited: A input field.

If subm,itted AmountPaid should get updated based on AmountDeposited


AmountDeposited: a number which is a seperate input field, which if gets posted 





ITs a form to keep track off my deps paid off
-A form with input fields
-Income which has a euro sign
-