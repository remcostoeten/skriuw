---
id: "70d9ac367390444aa172abc1ac81b657"
tags: []
sortOrder: 286
preferredEditorMode: "block"
createdAt: 1681698258457
modifiedAt: 1681702709762
---
Hey Judith,

Excuses voor de late reactie, blijkbaar kan een Outlook mailbox vol zitten en komen mailtje pas binnen als je oude verwijdert. The more you know.

Laten we woensdag doen, komt mij het beste uit. Wat betreft bellen denk ik niet dat dat nodig is, mag wel. Ik kom met de auto en ben verder flexibel, 10:00 is prima. Eventueel details en afspraken omtrent locatie e.d. kunnen van mij part later wel, indien we er niet uit komen hebben we in ieder geval wat kennis en connecties erbij.

Moet ik verder nog huiswerk doen omtrent Shopify? Of is het een algemenere frontend toets?

Groeten,

Remco