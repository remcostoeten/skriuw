---
id: "029d8fa5125b4b2593dfb68f49d2f613"
tags: []
sortOrder: 203
preferredEditorMode: "block"
createdAt: 1728358240511
modifiedAt: 1728358345385
---
Remove all mutate functions from entire project as apparently it doesn’t exist and we’ve been trying to build for over an hour.

Also make the ts  configuration very weak so it’s easy to deploy  as appedsnflg u have made  countless type errors 