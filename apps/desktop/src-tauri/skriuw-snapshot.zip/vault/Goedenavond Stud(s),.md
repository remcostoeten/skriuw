---
id: "bce8683fafaa45efb7e88037e8fda8b6"
tags: []
sortOrder: 156
preferredEditorMode: "block"
createdAt: 1738515784856
modifiedAt: 1738615882668
---
Goedenavond Stud(s),

Kon het boek en het contract qua schrijfstijl wel waarderen, kunnen anderen een lesje (no pun intended) van leren. Ik heb het van het weekend vuchtig doorgelezen en nu thuis achter de computer nog even aandachtig,  overnagedacht en wat om me heen gevraagd. Ben erg enthousiast overt het project, werksfeer/methodiek en vooral stack. Regelement en (kern)waardes in het handboek kan ik me grotendeels in vinden, paar kleinigheden en een iets groter. Excuses alvast voor het lange veerhaal, maar ik geef graag context. Dit is ook echt het enige, want verder ben ik serieus hyped. En  dit heb ik niet vaak.

Kleinigheidje:
-  Reiskosten. Er staat 19 cent de kilometer, dit is tegenwoordig 23 onbelast. Met tweemaal per week kantoor scheelt dit aanzienlijk. 

-  Contract staat 40 uur in zwolle. Vrij zeker, maar dit is voor de formaliteit? Aangezien hoe ik het begrepen heb dat dit in principe vrij in te vullen is en je thuis werkt wanneer je wilt behalve 2 dagen per maand. Gemiddeld is een team zo'n twee keer per week op kantoor. 

En dan de iets grotere waar ik mee in m'n maag zit. De waardering/totale pakket. Bespreken kan van mij part op alle manieren, maar via tekst weet ik zeker dat ik alles gemeld hebt en referentiemateriaal heb. Komt 'ie dan:

In de vacature staat een salarisrange van €3.000 (0%) tot €5.500 (100%). Logischerwijs zit €3.000 aan de onderkant qua skills wat jullie potentieel zouden aannemen en is €5.500 voor een doorgewinterde senior of lead. Met jullie voorstel zou ik net onder de 24% van die range vallen (25 stappen a €100,-, wat elke stap grofweg 4% maakt). 

Ik ben de laatste die beweert de beste te zijn, er valt nog genoeg te leren qua skills en ambities zijn hoog. Maar het voelt gek om te veronderstellen dat ik driekwart van de benodigde skills (om tot bovenkant range te komen) mij onbekend is, en dan heb ben we het alleen over programmeer skills aangezien soft skills zoals jullie bevestigde vrij goed zijn.

Ik ben ruim acht jaar van school af. Vijf jaar compleet custom B2B- en B2C-webshops zoals https://www.vedder-vedder.com/ gemaakt. Ondertussen al meer dan drie jaar in inhouse SaaS. Varierend van EU marktleiders in de technische groothandel, volledig open source een  doorontwikkeling van intranet-builder  voor zo'n 500k+/week non-profit/overheid medewerkers, maar ook non SaaS software als een https://fsv-portaal.nl/  en tot voor kort een product dat de gehele bouw MKB domineert.  En niet te vergeten een GitHub propvol met allerlij verschillende NextJS projecten buiten werktijd om.

Zoals wel duidelijk is, ben ik een techhead, hou van ontdekken, kennis delen/ontvangen en wil graag met NextJS werken. Alles past perfect bij jullie, en om die reden ben ik ook wel bereid om een klap te nemen t.o.v. mijn vorige baan. Ik ben daar begonnen op €60k/y. Maand salaris van +- €4550 (€4300 base + maandelijks vakantiegeld) en daar bovenop nog een dertiende maand met gunstig pensioenregeling, thuiswerkvergoeding, een home office budget van 2k.  direct een vast contract na proefperiode. Dit alles was eigenlijk ook bij mijn vorige werkgevers, minus 8-10k.

Ik heb met Pieter initieel en na de  toets nog contact gehad en hem gevraagd om te hameren op het feit dat ik een duidelijke roadmap wil qua groei. Ik las wat over gesprekken in het boek maar dat is uiteraard pas als ik in dienst ben. Dit hoeft pre contract niet in detail, maar zou toch graag weten wat julliie op de planning hebben en verwachten. Geld is niet alles en hecht veel veel waarde aan een leuke plek, ik verwacht geen 60k (over zes maandjes misschien... geintje) maar het zou fijn zijn als ik op mijn 28e eens uit huis kan, en met dit val je in Zwolle bijvoorbeeld overal buiten de boot i.v.m inkomsteneis. 

