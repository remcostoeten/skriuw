---
id: "8c24200136934d9dbd3c76a09f4c2d7b"
tags: []
sortOrder: 71
preferredEditorMode: "raw"
createdAt: 1755689023905
modifiedAt: 1755689673594
---
Zag gewoon de bui wel weer hangen dat je ineens laat wel zou reageren en ik me dan haast schuldig moet voelen als ik dan nee zeg maar een andere keer wil proberen te plannen 