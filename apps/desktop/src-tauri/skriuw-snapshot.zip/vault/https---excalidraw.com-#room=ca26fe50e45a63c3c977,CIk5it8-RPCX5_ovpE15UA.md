---
id: "8a849983-1f5f-4f08-9046-11cf35a4b9d3"
tags: []
sortOrder: 106
preferredEditorMode: "raw"
createdAt: 1747610612377
modifiedAt: 1747610612658
---
https://excalidraw.com/#room=ca26fe50e45a63c3c977,CIk5it8-RPCX5_ovpE15UA