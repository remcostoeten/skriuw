---
id: "0174bc6e174a4c4999e4f48c8d6b8ea7"
tags: []
sortOrder: 37
preferredEditorMode: "raw"
createdAt: 1766207045629
modifiedAt: 1766207427766
---
Create new dir
New hit repo 
Call it analytics

Make it next specific

Make it so that ppl can do ;
<analytics db=db and if needed schema /> and that’s it to get unique visitors,  geo data via ipinfo, per page visitors
Origin
Unqieu etc

Is this possible to it posts to prop db? Without hosting separate servers I want it just to work on my vercel next app PM