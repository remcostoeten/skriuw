---
id: "ca39cb26bf454a31b6aee771b59bd837"
tags: []
sortOrder: 204
preferredEditorMode: "block"
createdAt: 1728345236143
modifiedAt: 1728345570300
---
Can u save the lists in local storage and setup the server action in such a way that it is easily migrated to my Postgres db via drizzle orm

Can u rewrite the application to be modular in the sense that I acfually want another text modifier tool with exact same ui, only the text, functions / algorithms to extract text differs as the input will be different than this csv specific.

In my case  I have another feature where I insert dom content and have it extract only person names from that dom conten. Besides that being different. I want the Same ui look and feel. Can u set that ip for me and make another route for the feature I just explained but the logic behind it to manipulate text can be dummy. And another feature bug first this. 
