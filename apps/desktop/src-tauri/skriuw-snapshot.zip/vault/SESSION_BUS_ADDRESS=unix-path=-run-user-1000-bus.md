---
id: "8deaa383-8804-4eb4-b3ac-d02682d597ae"
tags: []
sortOrder: 50
preferredEditorMode: "raw"
createdAt: 1763409715212
modifiedAt: 1763419500968
---
SESSION_BUS_ADDRESS=unix:path=/run/user/1000/bus
LANG=en_US.UTF-8
GEMINI_API_KEY=AIzaSyD4q31ivUAQ4YpScF1yCHyCYhkdAVDF5kEt