---
id: "a77c0a30-e5a2-4a7b-8399-f4b33c934150"
tags: []
sortOrder: 170
preferredEditorMode: "raw"
createdAt: 1734561311667
modifiedAt: 1734561501915
---
ou've sent an email with people in the CC when they should have been in BCC. What do you do?
 


Reply to your sent email to apologize to the people in the CC

Do nothing, mistakes happen right?

Inform your manager so he/she can deal with this

Inform your manager and send an email to security@exact.com to report your mistake and contact the security team of Exact
Options
Question 15 of 38 (required)
Security Awareness for All > Mobile working 

If you don't know the answer read more about the topic here. 

 

 

Using open networks is risky. Malicious networks such as free Wifi can easily...?

Bypass HTTPS connections.

Harvest online user names and passwords.

Imitate your open networks remembered by your devices.

Change the content of the websites you visit.

All answers are correct.
Options
Question 16 of 38 (required)
Following our internal Information Handling Policy: If I want to use a new application or tool within Exact, I can just download it and install it without permission


No, you should first ask Corporate IT for permission to download this tool and install it for you

No, all currently used and new applications should be checked by Corporate IT before use is accepted within Exact

Yes, but only if it helps with your work

Yes, why not?
Options
Question 17 of 38 (required)
Security & Privacy Awareness for All > Privacy

If you don't know the answer read more about the topic here.

 

 

Which piece of information is enough to identify individual X?

X’s date of birth is the same as your date of birth.

X lives in the same town as you.

X works for Exact.

None of the other answers individually but together they identify X.
Options
Question 18 of 38 (required)
Security Awareness for All > Communicating securely

If you don't know the answer read more about the topic here.

 

 

In the media there is talk about a security issue people have been experiencing with websites similar to Exacts. You receive a call from a customer who has concerns about the issue. How do you handle this?
 


Explain that Exact is not impacted since our website is secured.

Explain that you are sorry but unable to help them.

 	Check with your manager and/or Corporate communications about what you can say. Don’t go into details or mention that Exact has an issue, but still help the customer as best you can.
Options
Question 19 of 38 (required)
Security Awareness for Technology > Controlling access to data

If you don't know the answer read more about the topic here.

 

 

Whats the best protection against uploading a malicious XML file like this one?



Prohibit DTD processing.

Support CSV import only.

Sanitize the XML file before parsing it.

Convert to ANSI before processing the file.
Options
Question 20 of 38 (required)
Security Awareness for All > Handling data

If you don't know the answer read more about the topic here.

 

 

You have access to confidential data as part of your job. What can you do with this information?

Discuss it with other employees and customers.

Tell your brother to help him get a job.

Deal with it solely for the purpose of your job activity.
Options
Question 21 of 38 (required)
Security Awareness for All > Day-to-day security 

If you don't know the answer read more about the topic here. 

 

 

Which of the following is NOT a security risk?
 


A non-Exact car parked in a reserved parking spot

A colleague accessing information they don’t need for their work

Unknown person working on an Exact laptop/PC

Unknown person walking around in restricted areas not accompanied by an employee
Options
Question 22 of 38 (required)
Security Awareness for Technology > Controlling access to data

If you don't know the answer read more about the topic here.

 

 

You can use the table below when you are:



Renewing your password to something unique and strong

Hacking your bank’s website

Looking for party conversation starters

Threat modelling
Options
Question 23 of 38 (required)
Security & Privacy Awareness for All > Privacy

If you don't know the answer read more about the topic here.

 

 

Exact in Malaysia has a customer in Thailand. Which statement is true?

GDPR only applies to the European Union so privacy is not important.

Many countries outside Europe have privacy laws so we might be forced to think about privacy.

Exact believes all its customers have a right to privacy.
Options
Question 24 of 38 (required)
Security Awareness for All > Mobile working 

If you don't know the answer read more about the topic here. 

 

 

You are on an airplane with a group of work colleagues flying to a conference. From an Exact perspective what is important to be mindful of?
 


Turning off your electronic devices.

Keeping your tray and seat back in the upright position.

Be careful not to discuss confidential information (strategy, churn, attrition, technical issues etc) that might be overheard.

Your nearest emergency exit.
Options
Question 25 of 38 (required)
Security Awareness for All > Social engineering attacks 

If you don't know the answer read more about the topic here. 

 

 

How can you protect yourself and the company from social engineering attacks?

All answers are correct.

Verify the identity of the person requesting info and their right to access it.

Don’t give out confidential information.

Use caution about what information you post on social networks.
Options
Question 26 of 38 (required)
Security Awareness for All > Communicating securely

If you don't know the answer read more about the topic here.

 

 

You want to send a confidential email to a few colleagues with an attachment that contains internal information. What do you do? 
 


You take extra measures by adding: Confidential to the subject line of your email.

You take extra measures by using functionality in Outlook, where you specify that this email can't be forwarded, edited, saved, exported, copied and creating a screenshot is not possible. You zip the attachment and secure is with a password longer then 14 characters.

You take extra measures by using functionality in Outlook, where you specify that this email can't be forwarded. You take no additional measures for the attachment

You take extra measures by using functionality in Outlook, where you specify that this email can't be forwarded, edited, saved, exported, copied and creating a screenshot is not possible. You take no additional measures for the attachment
Options
Question 27 of 38 (required)
Security Awareness for All > Data loss prevention

If you don't know the answer read more about the topic here.

 

 

What percentage of people who lose/leave a job keep confidential information?
 


50%

10%

20%

70%
Options
Question 28 of 38 (required)
Security Awareness for All > Day-to-day security 

If you don't know the answer read more about the topic here. 

 

 

If you have an access badge for the Exact location where you work, it is important to keep it with you at all times because...?
 


It gives you access to the building and to restricted areas that visitors can’t access.

You may be periodically stopped for a badge check.

Every time you scan your badge you earn bar points.
Options
Question 29 of 38 (required)
Security Awareness for Technology > Controlling access to data

If you don't know the answer read more about the topic here.

 

 

A new member has been transferred to your team. He's supposed to be involved in day-to-day workloads and occasional project work as needed. Before assigning access to tools, platform or documentation, do you (choose all that apply)

Template the day-to-day access the new joiner will have, based on the team member that mostly closely matches their duties and responsibilities

Confirm if proper sign off is in place with the in-line supervisor/manager

Assign access based on the team member that matches their duties and responsibilities

Assess all access required to do the work the new joiner is doing, then review with the in-line supervisor/manager before assigning
Options
Question 30 of 38 (required)
Security Awareness for All > Data loss prevention 

If you don't know the answer read more about the topic here. 

 

 

What percentage of companies that lose their data center for 10 days or more due to a disaster, file for bankruptcy within one year?
 


6%

93%

25%

41%
Options
Question 31 of 38 (required)
Security Awareness for All > Data loss prevention 

If you don't know the answer read more about the topic here. 

 

 

Which of the following is a strategy for making sure that end users do not send sensitive or critical information outside the corporate network?
 


Data Loss Prevention (DLP)

Project codename

Data protection program

Common sense
Options
Question 32 of 38 (required)
Security Awareness for Technology > Controlling access to data

If you don't know the answer read more about the topic here.

 

 

Writing code is a tricky job where small mistakes can have huge consequences. What is the best way to avoid security bugs during development?

Ask for help when you aren’t sure about something.

Follow best practices regarding secure coding guidelines.

All answers are correct.

Consider ways the functionality you are creating might be abused.
Options
Question 33 of 38 (required)
Security Awareness for Technology > Secure development

If you don't know the answer read more about the topic here.

 

 

Which development methodology should be used to be able to implement security in the Software Development Life Cycle (SDLC)??

Waterfall

DevOps

Agile

Not applicable, regardless of the methodology used you can always implement security activities in your SDLC
Options
Question 34 of 38 (required)
Security Awareness for Technology > Controlling access to data

If you don't know the answer read more about the topic here.

 

 

What is the best way to test if a login page is vulnerable for SQL injection?

Use two dashes (--) in your user name and password.

Leave the password empty.

Use script alert image in your username and password.

Use a single quote in your username and password.
Options
Question 35 of 38 (required)
Security Awareness for All > Synergy security

If you don't know the answer read more about the topic here.

 

 

What security level in Synergy is considered internal, meaning that all employees can see the related information?

100

10

2

101
Options
Question 36 of 38 (required)
Security & Privacy Awareness for All > Privacy

If you don't know the answer read more about the topic here.

 

 

We are working with a new supplier but the contract is not signed. Which statement is true?

We cannot exchange any personal data with the supplier until the contract is signed.

Provided we are confident the contract will be signed, we can exchange personal data with the supplier.

We can exchange a limited amount of personal data to carry out a proof of concept with the supplier.
Options
Question 37 of 38 (required)
Security Awareness for All > Why Security Awareness?

If you don't know the answer read more about the topic here.

 

 

Why is it important for employees to follow security awareness training every year?

In today’s interconnected world, data breaches occur on a daily basis. We don’t want Exact to become a headline in the news as being a ‘breached’ company.

Our customers entrust Exact to manage and store their sensitive business data on an infrastructure Exact maintains.

All answers are correct.

Exact has an obligation to customers to ensure their data is secure and not used in unauthorized ways.