---
id: "5d4e80dd-4b64-4577-a0a5-d98c1a275ef8"
tags: []
sortOrder: 356
preferredEditorMode: "raw"
createdAt: 1660905711844
modifiedAt: 1660906290515
---
tradeit.gg  trade
karmbit = 393$
ak = 53. 75
mac = 4.96

452 $ total

butterfly scorched 468.07

bitskins
karmbit = 310
ak = 70
mac = 4.6 
346$

karmbit =
ak = 
mac = 
