---
id: "1b75d693abed4c1ea142c15c01503a08"
tags: []
sortOrder: 234
preferredEditorMode: "block"
createdAt: 1708345449902
modifiedAt: 1708345455228
---
Ik zie in de PostNL app dat afgelopen zaterdag een onbekende brief en twee belastingbrieven geleverd zou moeten worden nu is het met mij is niks geleverd en bij de buren wel maar de buren die hadden brieven voor een ander huis. De dag daarvoor had ik brieven voor de buren dus het lijkt erop dat de bezorger meerdere dagen achter elkaar Brieven door de war haalt.


Echter zijn mijn brieven spoorloos ik ben bij de buren geweest die weten het niet en PostNL is die dag dus wel bezorgd.

Gaat om vertrouwelijke brieven met urgentie… kunnen jullie uitzoeken of dit niet bezorgd is of dat de bezorger een fout heeft gemaakt?