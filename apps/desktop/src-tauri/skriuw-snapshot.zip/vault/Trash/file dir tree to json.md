---
id: "c9e12f1e-fe57-465e-a349-9c9f529005ec"
tags: []
sortOrder: 0
preferredEditorMode: "raw"
createdAt: 1755455221523
modifiedAt: 1782651359055
---
file dir tree to json
set -l ROOT ~/sites/test/; find $ROOT -maxdepth 3 -type f -print0 | sh -c 'ROOT="$1"; while IFS= read -r -d "" file; do rel="${file#"$ROOT"}"; rel="${rel#/}"; jq -Rs --arg p "$rel" "{(\$p): .}" < "$file"; done' _ "$ROOT" | jq -s 'add' | begin; if type -q wl-copy; wl-copy; else if type -q xclip; xclip -selection clipboard; else cat; end; end

