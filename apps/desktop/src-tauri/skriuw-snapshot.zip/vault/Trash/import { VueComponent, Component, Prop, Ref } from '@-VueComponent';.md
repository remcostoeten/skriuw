---
id: "0a18ce01-6768-4eb6-bcb6-625f0a8d6da5"
tags: []
sortOrder: 6
preferredEditorMode: "raw"
createdAt: 1735822920476
modifiedAt: 1782651359056
---
import { VueComponent, Component, Prop, Ref } from '@/VueComponent';
// ... other imports remain the same

@Component({
    components: {
        DayOffPerEmployeeForm,
        FullPlanItemForm,
        GenericDialog,
        ProjectForm,
        ContactForm,
        ContactPersonForm,
    },
})
export default class PlanningCreateDialog extends VueComponent {
    // ... existing properties and injections remain the same

    private setupSchedulerEvents(): void {
        requestAnimationFrame(() => {
            if (!this.scheduler?.instance) return;

            this.scheduler.instance.on('beforeEventEdit', (event: BryntumEvent) => {
                if (!event.resourceRecord?._data?._isManuallyAdded) {
                    this.handleBryntumDragEvent(event);
                }
                if (event.resourceRecord) {
                    event.resourceRecord._data._isManuallyAdded = false;
                }
                
                if (event.eventRecord) {
                    this.activeEventRecord = event.eventRecord;
                    this.planItemEventUpdater?.initialize(event.eventRecord);
                    this.dayOffPerEmployeeEventUpdater?.initialize(event.eventRecord);
                }
                return false;
            });

            this.scheduler.instance.on('autoCreate', this.handleAutoCreateEvent.bind(this));
        });
    }

    private async handleBryntumClickEvent(event: BryntumClickEvent): Promise<void> {
        if (!this.isValidBryntumEventOperation(event) || !event.record) return;

        if (this.activeEventRecord) {
            try {
                await this.scheduler.instance.eventStore.remove(this.activeEventRecord);
            } catch (error) {
                console.warn('Error removing active event:', error);
            }
            this.activeEventRecord = null;
        }

        const [startDate, endDate] = this.planningFormDateHelper.translateFromBryntumClickEvent(event);
        if (!startDate || !endDate) return;

        this.initialStartDateFromScheduler = startDate;
        this.initialEndDateFromScheduler = endDate;

        try {
            const resourceRecord = event.record;
            if (resourceRecord) {
                this.activeEventRecord = await this.scheduler.instance.eventStore.add({
                    resourceId: resourceRecord.id,
                    startDate: new Date(startDate),
                    endDate: new Date(endDate),
                })[0];
                
                await this.prefillFormWithEventResourceInCalendar(event);
                await this.openDialog(false, true);
            }
        } catch (error) {
            console.warn('Error creating event:', error);
            this.activeEventRecord = null;
        }
    }

    private async beforeDialogClose(): Promise<void> {
        try {
            await this.planItemForm?.selectProjectForm?.projectDeletePrompt();
            
            if (this.shouldRemoveEventRecord && this.activeEventRecord) {
                await this.scheduler.instance.eventStore.remove(this.activeEventRecord);
            }
        } finally {
            this.activeEventRecord = null;
            this.planItemEventUpdater?.remove(this.shouldRemoveEventRecord);
        }
    }

    // ... other methods remain the same
}