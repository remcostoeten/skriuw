---
id: "57c3e541-d80d-40fa-a8af-b84d0bf6ef86"
tags: []
sortOrder: 17
preferredEditorMode: "raw"
createdAt: 1687870693537
modifiedAt: 1782651359057
---
Tijdlijn datatypes
[ ] Euro
    Effect door FSV.                   Tegemoetkoming
    Heading                                  Content (euro teken 100,-)

    