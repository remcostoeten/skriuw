---
id: "6f18e3e4-1b91-4e66-8bf7-0bf5ff1c2c52"
tags: []
sortOrder: 25
preferredEditorMode: "raw"
createdAt: 1671903725252
modifiedAt: 1782651359058
---

[00:15, 21/09/2022] Remco Stoeten: Wil e er sowieso van af
[00:15, 21/09/2022] Remco Stoeten: of nja ik MOET wel anytime "soon"
[00:16, 21/09/2022] Remco Stoeten: Volgend jaar wil m'n vriendin op vakantie en dat wordt vliegen dus dat is wel de motivatie om er eindelijk eens vanaf te komen
[00:16, 21/09/2022] Remco Stoeten: Ik kan moeilijk withdraweln op vakantie