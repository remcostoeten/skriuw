---
id: "743ad60b-efcf-4bbe-a6e3-b2ef460c8632"
tags: []
sortOrder: 368
preferredEditorMode: "raw"
createdAt: 1659037602074
modifiedAt: 1659037824448
---
Hey tymen ik dacht ik doe maar even een update.

Afgelopen periode heb ik niet zzoveel gebruik gemaakt van de coaching en gesport. Afgelopen weken extreem druk geweest met het afstuderen en maken van scriptie en die heb ik gelukkig vorige week gehaald met een *cijfers balbalbal*. Daarnaast gewisseld van werk locatie waardoor ik even geen puf had in het sporten.

Nu is school afgerond en heb ik vakantie en wil ik weer structuur terug brengen en de concrete vraag was of jij  hierovr wilt nadenken qua schema hoe ik weer terug op het oud eniveau kan komen en eventueel bepaalde doelen kan bereiken of n aar een mock toe werken. Vanaf vcolgende week wil ik weer structureel 3x p/w gaan, dus als we vanaf dan weer samen kunnen knallen zou dat top zijn

Warme groenten,

Remco

Ik bedoel euh daphne

