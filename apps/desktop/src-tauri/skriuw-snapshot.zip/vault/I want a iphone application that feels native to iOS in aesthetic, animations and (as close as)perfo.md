---
id: "afea7ec1-0543-4e2c-952f-7bdd5679fe8f"
tags: []
sortOrder: 69
preferredEditorMode: "raw"
createdAt: 1755979417796
modifiedAt: 1755979418197
---
I want a iphone application that feels native to iOS in aesthetic, animations and (as close as)performant as possible. It should allow me to track income, set optionally re-occuiring, euros, date (past or future), categories - with option to create categories to reuse in other entrys, set a icon for the category, title and description.
See total current wealth basd on this

Set expenses with roughly same features as income. 
See upcoming expenses if re-occuring exist

Have a save section which u can give aname and description, add total amount and setup future re-occuring additions to savings

Have a future prediction / calculation of savings amount / wealth with the re-occuring expenses.

It doesnt have t o be released on appstore but ishould be able to run it on my iphone and persist data.