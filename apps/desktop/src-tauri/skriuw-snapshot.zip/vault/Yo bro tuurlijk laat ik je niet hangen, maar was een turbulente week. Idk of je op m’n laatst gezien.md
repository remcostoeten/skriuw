---
id: "002090f2686c495cbb59d5cc5e18d439"
tags: []
sortOrder: 122
preferredEditorMode: "block"
createdAt: 1743418620069
modifiedAt: 1743504950208
---
Yo bro tuurlijk laat ik je niet hangen, maar was een turbulente week. Idk of je op m’n laatst gezien hebt gekeken maar sinds vorige week dinsdag niet meer op m’n telefoon telefoon gehad want die lag op werk en ben de week thuis gebleven.

Vorige week Maandag naar werk en super manisch en paranoia met psychotische ideeen. Sinds dien soortgelijke van black-out. Maandag uit werk aperantly naar casino gegaan (weet ik niks van maar zie ik op afschriften), toen dinsdag naar werk en net voor m’n werk met waggie de bocht uit gevlogen. Op werk helemaal in paniek en toen is ambu gekomen en hele checkup gehad maar was obv niks aan de hand, naar huis gestuurd en ben nu net weer op werk en ietwat nuchter. Ik weet niet hoe het gebeurd is maar ik denk flubromazolam. Ik ben nu wel serieus fucked qua geld dus ben ff hard aan het denken hoe ik dit ga overbruggen tot loon maar ik beloof je dat als ik wat fix ik je als eerste pay