---
id: "330cc8cd-36c5-4f96-8969-c43b7a5ae93e"
tags: []
sortOrder: 402
preferredEditorMode: "raw"
createdAt: 1648041772477
modifiedAt: 1648041990598
---
These chemicals are not being sold by any vendor in EU so I think stocking these will yield more sales. Also these chemicals actually seem to offer something interssting isntead of another pyro or weird PCP analouge.

China stim:  4-MeTPMP: https://www.longflourishrc.com/4-metmp-hcl-powder_p0053.html

Tryptamines being sold in  canada from legit vendor (from LL their site)
4-HO-PiPT: https://chemlogix.ca/4-ho-pipt-fumarate

5-MeO-DPT(!!!) freebase https://chemlogix.ca/5-meo-dpt-freebase And they also have the salt version  https://chemlogix.ca/5-meo-dpt-fumarate 

5-MeO-PiPT https://chemlogix.ca/5-meo-pipt-hcl

More canada I think.  4-PrO-DMT (1:1: with 4-ACO-DMT but then legal) https://theindoleshop.com/product/4-pro-dmt/