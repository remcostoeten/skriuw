---
id: "897327ba-ab1f-42c9-95df-933051353b4a"
tags: []
sortOrder: 414
preferredEditorMode: "raw"
createdAt: 1644867427999
modifiedAt: 1644867429031
---
Dude je hoeft niet zo getriggerd te zijn.  Zoals ik ook al in het topic vroeg welke desinformatie? 

Bij langdurig etizolam gebruik treden geen withdrawals op? Withdrawals kunnn niet bestaan uit Seizures, colds, en tig andere complicaties?

Etizolam is wel een research chemical, maar wordt in een paar landen heel sporadisch voorgeschreven, niet in Nederland, 

https://www.deadiversion.usdoj.gov/drug_chem_info/etizolam.pdf
Ety

Etizolam is purchased via the internet and at local retail shops where it is promoted as a “research chemical.” It has been sold as a powder, in tablet form and spiked onto blotter paper.


https://recoverycentersofamerica.com/substance-guide/etizolam/#:~:text=Etizolam%20withdrawal%20is%20known%20to,insomnia%2C%20dysphoria%2C%20and%20tremors.

Etizolam withdrawal is known to be difficult and in certain cases even ***life threatening ****for those using large or moderate amounts for a prolonged period of time. One of the dangers with etizolam discontinuation is th