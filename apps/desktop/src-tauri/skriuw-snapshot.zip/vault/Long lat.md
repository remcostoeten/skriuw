---
id: "278cd715-7e84-4a1f-92c0-f2c2536ae82d"
tags: []
sortOrder: 281
preferredEditorMode: "raw"
createdAt: 1683314162327
modifiedAt: 1683314270181
---
Long lat
Zwolle:52.5125 6.09444
Stk: 53.0043 692522
Raalte: 52.38358 6.275
Burgum: 53,18951 5,9896
Leek 53.161611  6.39
Lwd 53.20 5.799
9715jj 53.23456 6.57273
breda 51.5719 4.768