---
id: "da44cfaf-04c2-4a64-9934-97853adee621"
tags: []
sortOrder: 147
preferredEditorMode: "raw"
createdAt: 1739913071187
modifiedAt: 1739915602299
---
        Can you create a generic reusable crud menu modal? in this case when u click on the dropdown for organisations in the top av, there's a new organisation button which should open a gneric reusable modal, I have two screenshots attached as example.

https://lovable.dev/@3M1RoVAMqubmAw3qRCl2lqUfXsJ3