---
id: "1fd24fc27ce44d3689159f7c6484f822"
tags: []
sortOrder: 284
preferredEditorMode: "block"
createdAt: 1682042017378
modifiedAt: 1682043553582
---
Hey Judith,

Ik heb zeker een leuke ochtend gehad, vond het gezellig en leek zo ook een prima team en locatie.

Moet zeggen dat het me wel wat verbaasd. Ik heb in het begin vrij lang lopen kloten met de GIT repo die niet geforked kon worden (mark er wel bij geroepen en die zei dat ik het zonder fork kon doen, maar toch heb ik het nog even een tijdje geprobeerd omdat ik dacht dat de eind tijd een indicatie was en ik hem gewoon af kon maken, wat allicht niet de slimste keuze was).

Ik zou haast zeggen dat ik wel een complexere opdracht wil maken om te bewijzen hoe m’n niveau is, aangezien de toets ik de toets inderdaad niet echt moeilijk vond en een besluit gebaseerd is op een harde puntentelling en niet m’n portfolio/praktijk ervaring.

En indien het besluit wel vast staat en een lead er voor open staat/tijd is zou ik wel graag inhoudelijk wat feedback willen ontvangen aangezien ik tijdens het evalueren het idee kreeg dat mijn onderbouwingen en werk in de lijn ter verwachtingen lagen. Of dit een korte call of mail is dat maakt mij verder niet uit. En indien niet ook even goede vrienden 

Dankjewel in ieder geval voor de snelle communicatie :)

Remco 

Als ik het goed begrijp dan hangt het besluit grotendeels af van de puntentelling, wat ik ergens wel jammer vind aangezien mijn portfolio en niveau volgens mij aardig strookt met de cases en ik inderdaad de toets relatief makkelijk vomd. Ik zou haast zeggen dat ik wel een complexere opdracht wil maken 

Tijdens het evalueren m’n puntjes ook volgens mij zoals het moest en kon ik onderbouwen/aanwijzen ik de openstaande punten had gedaan of slordigheden anders had gedaan als ik geen tijdnood had.