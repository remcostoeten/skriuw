---
id: "02e0e5b5-5c7a-49e5-8c20-d2a347f3c55e"
tags: []
sortOrder: 22
preferredEditorMode: "block"
createdAt: 1770928573450
modifiedAt: 1770928576074
---
You are an expert Go TUI/CLI engineer and systems architect.

Produce a single, copy pasteable SPEC file plus an implementation plan for a Go CLI tool using:

- Bubble Tea (state + event loop)
- Lip Gloss (layout + styling)
- Bubbles (lists, inputs, viewport, spinner, progress)

This must be a modern, aesthetic, keyboard-first terminal application with a dark monochrome theme and subtle orange accent.

The output must be practical, opinionated, and ready to execute, with exact folder structure, shell commands, and key bindings.

The result must compile and run.

────────────────────────────────
PRODUCT GOAL
────────────────────────────────

Build a project management TUI CLI that is fully project agnostic.

This is NOT a tool for “project X”.

It is a reusable management shell that can operate in any directory and adapt itself via configuration and modules.

Core philosophy:

- Zero assumptions about:
  - repo layout
  - programming languages
  - frameworks
  - databases
  - CI providers

Everything domain-specific lives in optional modules.

Core only provides primitives:
- navigation
- selection
- actions
- filesystem discovery
- process execution
- configuration loading
- UI rendering

Users adapt the tool via config + modules, not by forking.

The tool must work in any PWD and must support workspace root detection.

Configuration layers:
- Global user config: ~/.toolname/config.yaml
- Project config: .toolname/config.yaml
- Environment variables override both

All merged deterministically.

Example principle to include in SPEC:

A PostgreSQL feature is NOT “Postgres for project X”.

Instead:

A Database module exposes generic capabilities:

- connect
- migrate
- seed

Providers (Postgres, SQLite, external URLs) are configured per project.

Menus are built dynamically from discovered capabilities.

────────────────────────────────
UX REQUIREMENTS
────────────────────────────────

Keyboard only:

- Up / Down: move selection
- Enter: open / confirm
- Space: toggle item selection
- a: select all
- d: deselect all
- Backspace or Left: go back
- q or Esc: quit
- /: open search filter
- ?: help overlay
- Ctrl+C: hard exit

Must support:

- multi-level nested menus
- breadcrumbs always visible
- multi-select lists
- search filtering
- modal overlays
- help overlay
- command palette stub (future)

State must track:

- navigation stack
- focused component
- selected items
- search query
- active modal
- active capability

────────────────────────────────
AESTHETICS
────────────────────────────────

Use Charm stack:

- Bubble Tea
- Lip Gloss
- Bubbles

Theme:

- Dark background
- Monochrome foreground
- Small orange accent for focus

Typography guidance (document clearly in SPEC):

Terminal apps cannot force fonts.

Recommend:

Body:
- Inter
- fallback: system sans

Headings:
- JetBrains Mono or Geist Mono
- fallback: any mono

Provide instructions for:

- macOS Terminal + iTerm2
- Windows Terminal
- GNOME Terminal or Kitty

Simulate typography via:

- casing
- spacing
- weight
- borders

Not actual font forcing.

────────────────────────────────
ARCHITECTURE
────────────────────────────────

Core vs Modules.

Define:

Module:
- code package
- registers capabilities
- optional

Capability:
- named feature exposed by a module
- used to construct menus + actions

Modules never render UI.

They expose:

- name
- description
- actions

Core builds UI from capability registry.

Strict separation:

internal/core/cap     capability registry
internal/core/mod     module manifests + lifecycle
internal/core/cfg     config loader + merge rules
internal/core/ws      workspace detection + paths
internal/core/fs      filesystem scanning + globbing
internal/core/proc    process runner
internal/ui           lipgloss styles + components
internal/app          bubble tea model + router

Adapters depend only on core types.

────────────────────────────────
REQUIRED FOLDER STRUCTURE
────────────────────────────────

cmd/toolname/main.go

internal/app
  model.go
  router.go

internal/ui
  styles.go
  components/
    list.go
    breadcrumbs.go
    help.go

internal/core
  cap/
  mod/
  cfg/
  ws/
  fs/
  proc/

internal/modules
  project/
  database/   stub only

scripts/cli.sh

dist/

────────────────────────────────
BOOTSTRAP WORKFLOW
────────────────────────────────

Must include:

git init  
go mod init  

scripts/cli.sh (executable):

- build
- install
- run
- clean

install places binary in /usr/local/bin or ~/.local/bin

Include gofmt and optional golangci-lint.

────────────────────────────────
DELIVERABLES IN YOUR RESPONSE
────────────────────────────────

1. SPEC document (Markdown headings):

- Overview
- Non-goals
- UX rules
- Key bindings table
- Architecture
- Module vs Capability
- Folder structure
- State model
- Screen types
- Navigation rules
- Theming
- Typography instructions
- Error handling
- Logging strategy
- Extension points

2. Step-by-step implementation plan:

Exact shell commands.

Milestones.

Expected files per step.

3. Minimal working scaffold:

Provide FULL code for:

- main.go
- internal/app/model.go
- internal/ui/styles.go
- internal/ui/components/*
- internal/core/cap registry
- stub project + database modules
- scripts/cli.sh

The app must:

- compile
- show root menu (4 items)
- have 2 nested levels
- support multi select
- show breadcrumbs
- show help overlay
- show search filter
- include stub capabilities

No comments in code.

Use function declarations.

Use types, avoid interfaces unless unavoidable.

Identifiers max two words.

Clean modular structure.

────────────────────────────────
CONSTRAINTS
────────────────────────────────

- Go
- Bubble Tea + Lip Gloss + Bubbles
- Function declarations only
- types instead of interfaces
- modular scalable design
- no emojis
- no em or en dashes
- identifiers ideally <= two words
- code self explanatory

────────────────────────────────
OUTPUT RULES
────────────────────────────────

Output ONLY:

- SPEC
- implementation plan
- full code

Wrap everything in markdown fences.

If nested fences are needed, escape using $$$.

Do not add commentary outside the prompt.

Produce final result.
