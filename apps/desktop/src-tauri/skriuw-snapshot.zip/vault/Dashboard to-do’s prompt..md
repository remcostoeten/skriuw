---
id: "5bb509ab2a5840768a053678cec09cd8"
tags: []
sortOrder: 213
preferredEditorMode: "block"
createdAt: 1725590980001
modifiedAt: 1725592027954
---
Dashboard to-do’s prompt.

- [ ] Header ui
—-> atom/Flex.tsx overhevelen
—> IconButton uit prod dashboard?
      - [ ] - logo toevoegen met anchor naar /
      - [ ] -  search in het midden 
            - [ ] KBD icon in search 
             Styling
              - [ ] Background en border nalopen 
              - [ ] Border radius nalopen 
              - [ ] Focused border color 
      - [ ] - Rechts flexer met 3 icon ghost buttons die tooltip prop hebben.
      - [ ] search modal 
               1) - [ ] algemene modal-wrapper maken ( 1-C voor global classss)
              2) modulaire overlay via props 
                       - [ ] Full blur ala base
                       - [ ] low blur
                       - [ ] Dimmed background. 
                                - [ ] Rgba 255,255,255,0.7
                                - [ ] Rgba 0,3

bg-modal, border-separator, dropshadow, rounded-theme, absolute, inset-0,
 
      
Header Logic 
       - useKeyboardhook uit productivity halen
       - Trigger search modal op cmd/ctrl/k 
       - 