---
id: "bf6f3d68-fb7f-455b-a0c0-48c90425ff66"
tags: []
sortOrder: 341
preferredEditorMode: "raw"
createdAt: 1665519347294
modifiedAt: 1666084488605
---

    &:after {
        content: '';
        width: 100vw;
        height: 1px;
        left: -490px;
        right: 0;
        bottom: 0;
        background-color: $color-grey-border;

        position: absolute;
    }
