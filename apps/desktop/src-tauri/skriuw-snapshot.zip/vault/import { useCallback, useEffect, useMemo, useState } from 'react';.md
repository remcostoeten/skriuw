---
id: "5addd37c-9ee6-4f97-aa3d-ae8b5e80e503"
tags: []
sortOrder: 129
preferredEditorMode: "raw"
createdAt: 1742904343994
modifiedAt: 1742904344669
---
import { useCallback, useEffect, useMemo, useState } from 'react';
import { useMe } from '@brainstud/academy-api/Hooks/useMe';
import { Button } from '@brainstud/ui/Buttons/Button';
import { ConfirmationModal } from '@brainstud/ui/Modals/ConfirmationModal';
import { useForm } from '@brainstud/universal-components/Components/Form/useForm';
import {
  Check,
  RateReviewOutlined as RateReview,
  Save,
} from '@mui/icons-material';
import classNames from 'classnames/bind';
import { InlineList } from 'Components/Container';
import { AVAILABLE_TAGS, TTag, useObjectTags } from 'Hooks/useObjectTags';
import { Tips } from 'Modules/action-based-learning-panel/Components/Tips';
import { ExternalRatingModal } from 'Modules/action-based-learning-panel/Modals/ExternalRatingModal';
import BackButton from 'Modules/blended-learning-catalog-panel/Components/Navigation/BackButton';
import { useContentEditor } from 'Modules/course-editor/ContentEditor/Provider';
import { useAnswerProvider } from 'Providers/AnswerProvider';
import { useContentBlocksProvider } from 'Providers/ContentBlocksProvider';
import { useEnvironmentProvider } from 'Providers/EnvironmentProvider';
import { useLearningObjectProvider } from 'Providers/LearningObjectProvider/useLearningObjectProvider';
import { useLearningRouteProvider } from 'Providers/LearningRouteProvider/useLearningRouteProvider';
import { useLearningSubjectProvider } from 'Providers/LearningSubjectProvider/useLearningSubjectProvider';
import { useModals } from 'Providers/ModalProvider/useModals';
import { useTranslator } from 'Providers/Translator';
import { DateFormatter } from 'Utils/DateFormatHelper';
import { ObjectMetaBadge } from 'Views/CollectionViews/CollectionListView/ObjectRow/ObjectMetaBadge';
import { AnswerContributors } from 'Views/CollectionViews/ObjectViews/Contributors/AnswerContributors';
import { ContributorsModal } from 'Views/CollectionViews/ObjectViews/Contributors/ContributorsModal/ContributorsModal';
import { EditorBackButtonWithUnsavedCheck } from 'Views/Courses/CollectionEditView/LearningObjectEditView/EditorBackButtonWithUnsavedCheck';
import { AssignmentModal } from 'Views/Courses/CollectionEditView/LearningRouteEditorView/ContentModals/AssignmentModal';
import type { TAssignmentModalData } from 'Views/Courses/CollectionEditView/LearningRouteEditorView/ContentModals/AssignmentModal/Types';
import { useActualObjectLayoutName } from './useActualObjectLayoutName';
import styles from './ObjectHeader.module.css';

const cx = classNames.bind(styles);

type Props = {
  editable?: boolean;
};

export const ObjectHeader = ({ editable }: Props) => {
  const [t] = useTranslator();
  const [me] = useMe();
  const { subscribe, save } = useForm();
  const { isStatic, states: blockStates } = useContentBlocksProvider();
  const { learningObject, variety, hasEnrollment } =
    useLearningObjectProvider();
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(true);
  const { openModal, closeModal } = useModals();
  const tags = useObjectTags(learningObject);
  const { isAdminEnvironment } = useEnvironmentProvider();
  const { currentAnswer } = useAnswerProvider();

  const { layout: routeLayout, learningRoute } = useLearningRouteProvider();
  const {
    layout: panelLayout,
    setLayout: setPanelLayout,
    isUnsaved,
    save: saveContent,
  } = useContentEditor();

  const { quiz } = useLearningSubjectProvider();
  const isQuiz = !!quiz;

  const isSavable = useMemo(
    () => !isStatic && blockStates.some((block) => block.touched),
    [isStatic, blockStates]
  );

  useEffect(() => {
    const unsubscribe = subscribe?.('dirty', () => {
      setSaved(false);
    });
    return () => {
      unsubscribe?.();
    };
  }, [subscribe]);

  const isTurnedIn = currentAnswer?.status === 'TURNED_IN';
  const showSaveButton = !isStatic && hasEnrollment && !isTurnedIn;
  const contributors = currentAnswer?.contributors?.() ?? [me!.account!()];

  const handleConceptSave = useCallback(() => {
    setSaving(true);
    save?.(
      { status: 'CONCEPT' },
      {
        onSettled: () => setSaving(false),
        onSuccess: () => {
          setSaved(true);
        },
      }
    );
  }, [save]);

  const externalRating =
    learningObject?.metadata?.configuration?.allowExternalRating;
  const lastAnswer = learningObject?.lastAnswer?.();

  const handleAddExternalRating = useCallback(() => {
    openModal(ExternalRatingModal, { answerId: lastAnswer?.id });
  }, [openModal, lastAnswer]);

  const tips = !Array.isArray(variety?.content)
    ? variety?.content?.tips
    : variety?.tips;

  const handleOpenLearningObjectModal = useCallback(() => {
    const modalProps: TAssignmentModalData = {
      isQuiz,
      routeLayout,
      isTheory: learningObject?.baseType === 'theory',
      learningRouteId: learningRoute?.id,
    };
    const openAssigmentModal = () => openModal(AssignmentModal, modalProps);

    if (isUnsaved) {
      openModal(ConfirmationModal, {
        title: t('views.collection.object.header.unsaved.title'),
        description: t('views.collection.object.header.unsaved.description'),
        yes: t('views.collection.object.header.unsaved.confirm'),
        no: t('cancel'),
        handleConfirm: () => {
          saveContent();
          closeModal();
          openAssigmentModal();
        },
      });
    } else {
      openAssigmentModal();
    }
  }, [
    isUnsaved,
    openModal,
    learningObject,
    routeLayout,
    learningRoute?.id,
    isQuiz,
    t,
    saveContent,
    closeModal,
  ]);

  const isLinear = useActualObjectLayoutName() === 'linear';
  const isPanel = useActualObjectLayoutName() === 'panel';

  const isGroup = useMemo(() => {
    const groupTag =
      tags.find((tag) => tag.name === 'groupSize')?.value?.toString() || '0';
    return parseFloat(groupTag) > 1;
  }, [tags]);

  return learningObject ? (
    <header className={cx(styles.base)}>
      <div className={cx(styles.upper, { linear: isLinear })}>
        <div className={cx(styles.title)}>
          {isAdminEnvironment ? (
            <EditorBackButtonWithUnsavedCheck />
          ) : (
            <BackButton />
          )}
          <div className={cx(styles.titleContent)}>
            <h2>{learningObject.title}</h2>
            <div className={cx(styles.titleActions)}>
              <Tips>{tips}</Tips>
              {tags
                .filter((tag) => tag.name === 'xp')
                .map((tag: TTag) => (
                  <ObjectMetaBadge
                    key={tag.name}
                    type={tag.name}
                    value={tag?.value}
                  />
                ))}
              {showSaveButton && (
                <Button
                  type="button"
                  quiet={!saving && !saved}
                  loading={saving}
                  success={saved}
                  disabled={!isSavable && !saving}
                  onClick={handleConceptSave}
                  className={cx('buttonConceptSave', {
                    unsaved: !saved,
                  })}
                  aria-label={
                    saved
                      ? t('views.collection.object.header.saved_as_concept')
                      : t('views.collection.object.header.save_as_concept')
                  }
                >
                  {saved ? <Check /> : <Save />}
                </Button>
              )}
            </div>
          </div>
        </div>

        <div className={styles['button-bar']}>
          <InlineList center>
            {tags
              .filter(
                (tag) =>
                  AVAILABLE_TAGS.includes(tag.name) &&
                  tag.name !== 'xp' &&
                  !(tag.name === 'xp' && Math.ceil(Number(tag.value)) === 0)
              )
              .map((tag) => (
                <ObjectMetaBadge
                  key={tag.name}
                  type={tag.name}
                  value={tag?.value}
                />
              ))}
          </InlineList>
          {isGroup && !isAdminEnvironment && (
            <AnswerContributors
              contributors={contributors}
              groupLeadId={currentAnswer?.groupLead?.().id}
              onClickAdd={
                !isTurnedIn
                  ? () => openModal(ContributorsModal, { currentAnswer })
                  : undefined
              }
            />
          )}
          {!editable ? (
            <>
              {externalRating && !isStatic && (
                <Button
                  type="button"
                  quiet
                  disabled={!lastAnswer}
                  onClick={handleAddExternalRating}
                  className={cx({ 'is-disabled': !lastAnswer })}
                >
                  <RateReview />
                  <span>
                    {t(
                      'views.collection.object.header.request_external_rating'
                    )}
                  </span>
                </Button>
              )}
            </>
          ) : (
            <div className={cx(styles.editable)}>
              {isPanel && (
                <div className={cx(styles.layoutToggle)}>
                  <strong>
                    {t('course-editor.content_editor.toggle_layout')}
                  </strong>
                  <button
                    type="button"
                    className={cx({ isSelected: panelLayout === 'columns' })}
                    disabled={panelLayout === 'columns'}
                    onClick={() => setPanelLayout('columns')}
                  >
                    <svg
                      width="21"
                      height="19"
                      viewBox="0 0 21 19"
                      fill="currentColor"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path d="M0.414062 1.287L0.414062 17.8895C0.414062 18.5028 0.94234 19 1.594 19L7.72183 19C8.37349 19 8.90177 18.5028 8.90177 17.8895L8.90177 1.287C8.90177 0.673671 8.37349 0.176469 7.72183 0.176469L1.594 0.17647C0.942339 0.17647 0.414062 0.673672 0.414062 1.287Z" />
                      <path d="M11.9258 1.287L11.9258 17.8895C11.9258 18.5028 12.4541 19 13.1057 19L19.2336 19C19.8852 19 20.4135 18.5028 20.4135 17.8895L20.4135 1.287C20.4135 0.673671 19.8852 0.176469 19.2335 0.176469L13.1057 0.17647C12.4541 0.17647 11.9258 0.673672 11.9258 1.287Z" />
                    </svg>
                  </button>
                  <button
                    type="button"
                    className={cx({ isSelected: panelLayout === 'rows' })}
                    disabled={panelLayout === 'rows'}
                    onClick={() => setPanelLayout('rows')}
                  >
                    <svg
                      width="19"
                      height="20"
                      viewBox="0 0 19 20"
                      fill="currentColor"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <path d="M17.713 0H1.11053C0.497202 0 0 0.528278 0 1.17994V7.30777C0 7.95943 0.497202 8.48771 1.11053 8.48771H17.713C18.3263 8.48771 18.8235 7.95943 18.8235 7.30777V1.17994C18.8235 0.528278 18.3263 0 17.713 0Z" />
                      <path d="M17.713 12H1.11053C0.497202 12 0 12.5283 0 13.1799V19.3078C0 19.9594 0.497202 20.4877 1.11053 20.4877H17.713C18.3263 20.4877 18.8235 19.9594 18.8235 19.3078V13.1799C18.8235 12.5283 18.3263 12 17.713 12Z" />
                    </svg>
                  </button>
                </div>
              )}
              <Button
                link
                quiet
                onClick={handleOpenLearningObjectModal}
                type="button"
              >
                {t('views.collection.object.header.edit')}
              </Button>
            </div>
          )}
        </div>
        {saved && currentAnswer?.updatedAt && showSaveButton && (
          <div className={cx(styles.savedTaglineContainer)}>
            <time
              className={cx(styles.savedTimestamp)}
              dateTime={currentAnswer.updatedAt}
            >
              {t('views.collection.object.header.saved_as_concept', {
                date: DateFormatter.toDayDateTime(
                  new Date(currentAnswer.updatedAt)
                ),
              })}
            </time>
          </div>
        )}
      </div>
    </header>
  ) : null;
};
