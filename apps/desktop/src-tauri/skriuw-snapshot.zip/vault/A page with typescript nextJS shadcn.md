---
id: "14980095af214602898dfa438f1d332b"
tags: []
sortOrder: 185
preferredEditorMode: "block"
createdAt: 1732769848297
modifiedAt: 1732770062250
---
A page with typescript nextJS shadcn

Have a input field to search for adress which auto fills dutch city’s. Should find on street name and postal code. Once oke is selected plus are able to save it which prompts a popover asking for a category name (which acts as a folder and if I want to give the location a mame) which then shows the folder + it’s locations in the ui.

If clicked on a saved location show a interactive map with a pinpoint and all metadata.country  - province - city - street - postal code - longitude and latitude 

Also allows edit name for category’s and saved locations. And allow delete both with confirmation popover and toast  