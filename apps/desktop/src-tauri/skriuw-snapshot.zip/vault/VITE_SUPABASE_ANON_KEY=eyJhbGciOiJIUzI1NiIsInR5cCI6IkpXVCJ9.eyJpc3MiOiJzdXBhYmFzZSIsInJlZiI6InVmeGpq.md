---
id: "87725bb7-0596-49b7-8cd1-b4d844bda52f"
tags: []
sortOrder: 165
preferredEditorMode: "raw"
createdAt: 1735605637281
modifiedAt: 1735605637843
---

VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVmeGpqaXdnc21lcnBrY3VteGhsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzU1NjgxODcsImV4cCI6MjA1MTE0NDE4N30.yYaR0SBo93sG0bVtrMr_CcrMy2d6T9_n8mpCXcyMPzs
VITE_SUPABASE_URL=https://ufxjjiwgsmerpkcumxhl.supabase.co