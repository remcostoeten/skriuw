---
id: "efef1750aeb941c98b0583df7d1be25c"
tags: []
sortOrder: 193
preferredEditorMode: "block"
createdAt: 1730005023850
modifiedAt: 1730006287944
---
M’n oude gym docent omdat ik zo’n goede sprinter was…

Nee, een aantal meiden die niet hadden verwacht dat zo’n white boy als ik een lul van 24,5cm heb 😀

Zin om cocktails te drinken en daarna op m’n geschikt te zitten? En wellicht daarna de schrik van je leven krijgen? 🍆