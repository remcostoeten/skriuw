---
id: "13c44da7-646c-4975-94fb-f138de5b0a9f"
tags: []
sortOrder: 153
preferredEditorMode: "raw"
createdAt: 1739238712363
modifiedAt: 1739239653609
---
https://v0.dev/chat/generate-mdx-tool-5ONGBd4LuV6?b=b_BwnVIVBWSis&p=0


https://v0.dev/chat/prisma-env-validation-DUCw8irPm1E?b=b_dKcomFGB4B0


https://v0.dev/chat/prisma-env-validation-DUCw8irPm1E?b=b_dKcomFGB4B0

pop-os% cd ~/code/nextjs-15-roll-your-own-authentication/scripts
pop-os% cd docker 
pop-os% ls
 docker-compose.yml          help.js
 docker-compose_backup.yml   manage-docker.sh
 env-manager.js              README.md
 extract-db.js               utils.js
 generate-secret.js         
pop-os% pwd
/home/remcostoeten/code/nextjs-15-roll-your-own-authentication/scripts/docker
pop-os% 