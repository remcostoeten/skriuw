---
id: "45f3d374-f452-4aa3-a89a-9e1aa154c7cf"
tags: []
sortOrder: 279
preferredEditorMode: "raw"
createdAt: 1683728681570
modifiedAt: 1683728686259
---
Hoi Luciana,

Bedankt voor de terugkoppeling. Het is inderdaad een stukje rijden, maar wel te doen. Ik heb de afgelopen twee jaar volledig remote gewerkt en dit beviel me uitstekend. Idealiter blijf ik remote werken of kom ik eens in de X-periode langs voor bijvoorbeeld sprint planning.

Dit heeft verder niets met mijn sociale vaardigheden te maken, maar meer met het feit dat ik niet op zoek ben naar een bedrijf waar ik alleen maar aanwezig hoef te zijn. Uiteraard zou er wel een inwerkperiode nodig zijn.

Laat me weten wat de mogelijkheden zijn, ook als ik niet zou winnen. Ik sta in ieder geval altijd open om in gesprek te gaan.

Groeten,

Remco