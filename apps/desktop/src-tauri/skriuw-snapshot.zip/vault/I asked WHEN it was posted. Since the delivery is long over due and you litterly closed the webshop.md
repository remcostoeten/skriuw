---
id: "7fb49d2d-2af4-4198-ae68-e1cd2a777c98"
tags: []
sortOrder: 407
preferredEditorMode: "raw"
createdAt: 1645797512520
modifiedAt: 1645797513083
---
I asked WHEN it was posted. Since the delivery is long over due and you litterly closed the webshop down. Kinda smells like a exit-scam. Shit happends, but if you don't have your administration right just be honest that orders got fucked up. If you shipped it out when I ordered it it should be here already for multiple days/weeks. 

So again, WHEN did you ship it out? Otherwise I would just like a refund, because I have fowarded over 50 customers to your shop when you were opperating and since the closedown nothing arrived, neitehr for me or friends. So basically i'd like for you to refund my money. Or sort it out with res-chems that they ship out my remaining 2g's of a-PHP. 

Thisis not a way of handeling business in my opinion. Eventho you're out of businnes, you should handle your last stuff off proper. We all know postal shipment to NL is no problem with customs/time. So if it was shipped out, it would be here already, so just be honest on what's going on. Bank wire me my money back, or sort it out with reschems that they reship me 2g of a-PHP.

Shipping details
REmco Stoeten
Kotter 12
8531cs Lemmer

Bank info
Remco Stoeten
NL18 RABO 0326 1007 33
The Netherlands obviously.