---
id: "28869d48-366d-46d0-b6bc-771c85bb9eca"
tags: []
sortOrder: 88
preferredEditorMode: "raw"
createdAt: 1751245185068
modifiedAt: 1751245329385
---
joost https://builder.io/app/projects/35df286756154057af441748ba5124ae/main

https://replit.com/@joostnevens020/Database-palace      


https://stackblitz.com/edit/sb1-f3yn4fm7?file=index.html