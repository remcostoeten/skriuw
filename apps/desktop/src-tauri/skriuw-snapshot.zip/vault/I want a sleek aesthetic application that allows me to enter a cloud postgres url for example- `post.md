---
id: "4b0c866c-5632-46b1-8362-c288f9cd2143"
tags: []
sortOrder: 64
preferredEditorMode: "raw"
createdAt: 1760890000653
modifiedAt: 1760890884234
---
    I want a sleek aesthetic application that allows me to enter a cloud postgres url for example: `postgresql://neondb_owner:npg_CxlcdAKv7ue4@ep-snowy-hat-adsko2r2-pooler.c-2.us-east-1.aws.neon.tech/neondb?sslmode=require&channel_binding=require` Which is a real database i have hosted on neon. And in the same view where we enter the database url it should have a field for a name and a connection test button and a save button.

    If test is pressed it should preform a real query to test if the database respons, if we were to make a typo somewhere and it fails it should error.

    On save it should save the name + database type (for now only psql) to a list somewhere.

    We should then be able to click on the item which just got added to connect (which we will do in a later stage), edit the name (should work now), or delete the entry.