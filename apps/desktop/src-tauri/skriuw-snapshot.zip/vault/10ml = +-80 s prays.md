---
id: "e6dcc19e-7dbb-4f30-9fca-fff62932ae4f"
tags: []
sortOrder: 309
preferredEditorMode: "raw"
createdAt: 1676671778489
modifiedAt: 1677022179989
---
10ml = +-80 s prays

potje: 10mg op 12,5ml pg  (= 1ml .8mg)
een sprayer = 10ml a 8m = 0.1mg


