---
id: "036d8627-dbd3-4190-b675-1986a12b8abe"
tags: []
sortOrder: 125
preferredEditorMode: "raw"
createdAt: 1742985635955
modifiedAt: 1742987467992
---
https://v0.dev/chat/next-js-e-learning-ui-BHGLvLumCzU?b=b_AypgCT35aDtOkay I want to show the usage of the library can you please build a talkable bar which has three big Britain in a row one participant one coach and one admin with the real estate administration coach and/dashboard I think then I want each of that route to have each individual view for that particular participant you would cheat on a admin and then I want to be able to have a keyboard shortcut fear or helper witches for all three shoes to forward to that view and you should be able to record a custom keyboard shortcut inside the widget we shave to storage which just allows for easy accessing certain routes VoiceOver fucking fuck come up