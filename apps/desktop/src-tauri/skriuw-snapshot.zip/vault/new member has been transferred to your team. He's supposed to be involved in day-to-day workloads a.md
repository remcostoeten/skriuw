---
id: "a9db7337-4c07-4159-94a0-7a184e3276e4"
tags: []
sortOrder: 172
preferredEditorMode: "raw"
createdAt: 1734558993689
modifiedAt: 1734560808666
---
new member has been transferred to your team. He's supposed to be involved in day-to-day workloads and occasional project work as needed. Before assigning access to tools, platform or documentation, do you (choose all that apply)

Assign access based on the team member that matches their duties and responsibilities

Confirm if proper sign off is in place with the in-line supervisor/manager

Assess all access required to do the work the new joiner is doing, then review with the in-line supervisor/manager before assigning

Template the day-to-day access the new joiner will have, based on the team member that mostly closely matches their duties and responsibilities

Clear selection
Options
Question 8 of 38 (required)
Security Awareness for All > Day-to-day security 

If you don't know the answer read more about the topic here. 

 

 

Which of the following is a cheap USB device that can steal your data and install malware in a matter of minutes?
 


Bath Time.

Rubber Ducky.

Super Sponge.
Options
Question 9 of 38 (required)
Security Awareness for All > Day-to-day security 

If you don't know the answer read more about the topic here. 

 

 

You receive an email from a colleague inviting you to check out a website. The message seems out of character. Which of the following should you NOT do? (Select the one thing you should NOT do).
 


Ask your colleague if they sent it.

Hover your mouse over the link (without clicking) to reveal the real URL.

Click the link to see what it is all about.

Delete it.
Options
Question 10 of 38 (required)
Security Awareness for All > Synergy security

If you don't know the answer read more about the topic here.

 

 

You create a request in Synergy and set the security level at 20. Who will be able to see it? (mark all that apply)

People with a security level of between 10-19

The request creator

Administrators

People with a security level of 20 or higher
Options
Question 11 of 38 (required)
Security Awareness for All > Communicating securely

If you don't know the answer read more about the topic here.

 

 

You've sent a list with customer details to your Gmail account to work on over the weekend and you've found out that your personal laptop where you read your gmail is infected with a virus. What do you do?
 


Inform your manager and send an email to security@exact.com to report your mistake and contact the security team of Exact

Do nothing, your virusscanner dealt with the virus and a scan shows no results

Inform your manager so he/she can deal with this

Go to your local computershop and let them clean up the machine
Options
Question 12 of 38 (required)
Security Awareness for All > Day-to-day security 

If you don't know the answer read more about the topic here. 

 

 

You receive a suspicious email telling you that you need to pay an invoice which is past due. The payment instructions are included in the attached Word document. What do you do? (mark all that apply)
 


Open the attachment.

Report the email using the "Report Message" button in Outlook.

Do not open the attachment.

Pay the invoice.
Options
Question 13 of 38 (required)
Following the internal Logging Policy, the following actions should be logged:


All username changes in the last month

Every failed email delivery message

System, network, or services configuration changes, including installation of software patches and updates, or other installed software changes

All logins and logouts of Exact employees
Options
Question 14 of 38 (required)
Security Awareness for Technology > Controlling access to data

If you don't know the answer read more about the topic here.

 

 

You can use the table below when you are:



Threat modelling

Looking for party conversation starters

Renewing your password to something unique and strong

Hacking your bank’s website
Options
Question 15 of 38 (required)
Security Awareness for All > Social engineering attacks 

If you don't know the answer read more about the topic here. 

 

 

How can you protect yourself and the company from social engineering attacks?

All answers are correct.

Don’t give out confidential information.

Use caution about what information you post on social networks.

Verify the identity of the person requesting info and their right to access it.
Options
Question 16 of 38 (required)
Security Awareness for Technology > 3rd party components

If you don't know the answer read more about the topic here.

 

 

Mend (previously known as WhiteSource) helps improve our software by scanning code repositories and...

Injects hooks that help us monitor and manage performance and availability

Reports insecure constructs from source to sink

Reflects the code quality and newly introduced issues

Identifies risks in open source components
Options
Question 17 of 38 (required)
Security Awareness for Technology > Controlling access to data

If you don't know the answer read more about the topic here.

 

 

What is the best way to test if a login page is vulnerable for SQL injection?

Use script alert image in your username and password.

Use a single quote in your username and password.

Leave the password empty.

Use two dashes (--) in your user name and password.
Options
Question 18 of 38 (required)
Security Awareness for All > Data loss prevention

If you don't know the answer read more about the topic here.

 

 

What percentage of people who lose/leave a job keep confidential information?
 


70%

10%

50%

20%
Options
Question 19 of 38 (required)
Security Awareness for All > Communicating securely

If you don't know the answer read more about the topic here.

 

 

On an internet forum you read a post about Exact including sales figures. The message gives false or incomplete information. What do you do?
 


Report the poster to the RFFP (Registry for Fraudulent Forum Posters).

Report to Corporate communications.

Respond to the post to set it right, not mentioning that you are an Exact employee.

Respond to the post to set it right, stating that you are an Exact employee.
Options
Question 20 of 38 (required)
Following the internal Security Operations Policy, the following is true:


Inactive user accounts are disabled after 90 calendar days

Inactive user accounts are disabled after 30 calendar days

Inactive user accounts are disabled after 60 calendar days

Inactive user accounts are disabled after 80 calendar days
Options
Question 21 of 38 (required)
Security Awareness for Technology > Controlling access to data

If you don't know the answer read more about the topic here.

 

 

OWASP launched the 2021 edition of their OWASP TOP 10 project and the changes can be seen in the image below. Notice that XML External Entities (XXE), Cross-Site Scripting (XSS) and Insecure Deserialization on not in the list anymore.
Does this means those problems have been solved?
Mapping


Yes, we are using secure frameworks now preventing these issues

No, they still exist but have been merged into a more generic category

No, but we can't protect against them so why show them in the list

Yes, hackers don't exploit these kind of issues anymore
Options
Question 22 of 38 (required)
Security Awareness for Technology > Secure development

If you don't know the answer read more about the topic here.

 

 

Why is having a Secure Software Development Life Cycle (SSDLC) important for Exact?

Our customers expect and demand Exact to deliver secure products and services

We can show the outside world we are in control and our products and services are secure

Developing software and services comes with a security and privacy risk which should be managed to avoid surprises, breaches, and fines

All answers are correct

Delivery of secure software and services can only be achieved by implementing security across the whole SDLC
Options
Question 23 of 38 (required)
Security Awareness for All > Why Security Awareness?

If you don't know the answer read more about the topic here.

 

 

Why is it important for employees to follow security awareness training every year?

Exact has an obligation to customers to ensure their data is secure and not used in unauthorized ways.

All answers are correct.

Our customers entrust Exact to manage and store their sensitive business data on an infrastructure Exact maintains.

In today’s interconnected world, data breaches occur on a daily basis. We don’t want Exact to become a headline in the news as being a ‘breached’ company.
Options
Question 24 of 38 (required)
Security Awareness for All > Day-to-day security 

If you don't know the answer read more about the topic here. 

 

 

When should you opt to configure multi factor authentication?
 


Whenever possible

Never, I have a super strong password.

Only when the service has sensitive information in it and I find it important
Options
Question 25 of 38 (required)
Security Awareness for All > Data loss prevention 

If you don't know the answer read more about the topic here. 

 

 

What percentage of companies that lose their data center for 10 days or more due to a disaster, file for bankruptcy within one year?
 


6%

93%

41%

25%
Options
Question 26 of 38 (required)
Security Awareness for All > Mobile working 

If you don't know the answer read more about the topic here. 

 

You are away from the office with your laptop and are prompted to join a network already known to your computer. Oddly this network is from a hotel you stayed at in another city. What might be happening?
 


Your device is confused.

A malicious device is disguising itself by imitating a network known to your device.

Many hotels use international networks that are available in many locations.
Options
Question 27 of 38 (required)
Security Awareness for All > Day-to-day security 

If you don't know the answer read more about the topic here. 

 

 

What is the safest way to help you remember your passwords?
 


Write them on a sticky note and stick it to your computer.

Use a password manager.

When prompted, save them in your browser.

Tell your mom. She remembers everything!
Options
Question 28 of 38 (required)
Security Awareness for All > Day-to-day security 

If you don't know the answer read more about the topic here. 

 

 

Which of the following is NOT a security risk?
 


Unknown person walking around in restricted areas not accompanied by an employee

A non-Exact car parked in a reserved parking spot

A colleague accessing information they don’t need for their work

Unknown person working on an Exact laptop/PC
Options
Question 29 of 38 (required)
Security Awareness for All > Communicating securely

If you don't know the answer read more about the topic here.

 

 

In the media there is talk about a security issue people have been experiencing with websites similar to Exacts. You receive a call from a customer who has concerns about the issue. How do you handle this?
 


 	Check with your manager and/or Corporate communications about what you can say. Don’t go into details or mention that Exact has an issue, but still help the customer as best you can.

Explain that Exact is not impacted since our website is secured.

Explain that you are sorry but unable to help them.
Options
Question 30 of 38 (required)
Security & Privacy Awareness for All > Privacy

If you don't know the answer read more about the topic here.

 

 

You are designing a new process. Which statement is true?

It is important to delete data that are no longer needed. The deletion processes should be designed and built before the process goes live.

Data is valuable, we shouldn’t delete anything in case we need it in the future.

It is important to delete data that are no longer needed. Someone else will need to sort this out in the future.
Options
Question 31 of 38 (required)
Security & Privacy Awareness for All > Privacy

If you don't know the answer read more about the topic here.

 

 

Exact in Malaysia has a customer in Thailand. Which statement is true?

Many countries outside Europe have privacy laws so we might be forced to think about privacy.

GDPR only applies to the European Union so privacy is not important.

Exact believes all its customers have a right to privacy.
Options
Question 32 of 38 (required)
Security Awareness for All > Communicating securely

If you don't know the answer read more about the topic here.

 

 

You want to send a confidential email to a supplier with an attachment that contains confidential information. What do you do?
Choose all correct answers.
 


You check to see if the supplier has signed a contract with Exact and if a NDA is part of the contract

You take extra measures by adding: Confidential to the subject line of your email. You zip the attachment and secure is with a password longer than 14 characters.

You take extra measures by adding: Confidential to the subject line of your email. You take no additional measures for the attachment

You take extra measures by using functionality in Outlook, where you specify that this email can't be forwarded, edited, saved, exported, copied and creating a screenshot is not possible. You zip the attachment and secure is with a password longer than 14 characters.
Options
Question 33 of 38 (required)
Security Awareness for Technology > Controlling access to data

If you don't know the answer read more about the topic here.

 

 

Whats the best protection against uploading a malicious XML file like this one?



Sanitize the XML file before parsing it.

Prohibit DTD processing.

Support CSV import only.

Convert to ANSI before processing the file.
Options
Question 34 of 38 (required)
Security Awareness for Technology > 3rd party components

If you don't know the answer read more about the topic here.

 

 

Why is it important that the license conditions be reviewed by legal when working with a 3rd Party Software Component? (mark all that apply)

Source code transparency can leave the door open for hacks.

An owner of a component can make their own (potentially harmful) license conditions.

Using software components can mean that the product is not owned by Exact anymore.

Some standard license conditions oblige users to make source code available.
Options
Question 35 of 38 (required)
Security Awareness for Technology > Controlling access to data

If you don't know the answer read more about the topic here.

 

 

What is the most critical security risk to web applications according to the Open Web Application Project (OWASP) Top 10 of 2021?

Broken Access Control

Injection

Insecure design

Security misconfiguration
Options
Question 36 of 38 (required)
Security Awareness for All > Mobile working 

If you don't know the answer read more about the topic here. 

 

 

What should you do if a device in your possession that has Exact data on it goes missing?
 


Report it immediately to IT via phone or IT ticket.

Give it a week to see if it turns up.

Don’t tell anyone.
Options
Question 37 of 38 (required)
Security & Privacy Awareness for All > Privacy

If you don't know the answer read more about the topic here.

 

 

We are working with a new supplier but the contract is not signed. Which statement is true?

We can exchange a limited amount of personal data to carry out a proof of concept with the supplier.

We cannot exchange any personal data with the supplier until the contract is signed.

Provided we are confident the contract will be signed, we can exchange personal data with the supplier.
Options
Question 38 of 38 (required)
Security & Privacy Awareness for All > Privacy

If you don't know the answer read more about the topic here.

 

 

Which piece of information is enough to identify individual X?

X lives in the same town as you.

None of the other answers individually but together they identify X.

X’s date of birth is the same as your date of birth.

X works for Exact.