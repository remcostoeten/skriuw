---
id: "d262898c-9ddf-4d8c-aeda-1b2f321f22a1"
tags: []
sortOrder: 319
preferredEditorMode: "raw"
createdAt: 1674753242244
modifiedAt: 1674754376734
---
Hey Johanna ik had Daphne gister gevraagd dit te zeggen maar die had uiteraard wat anders aan haar hoofd. Ik weet niet wat de toekomst brengt en of we elkaar nog zien, maar ik wou jou en erwin bedanken en vertellen dat ik het heel erg waardeerde dat ik altijd welkom was en ik mocht doen alsof ik thuis was ondanks ik er niet zo vaak was en soms misschien wat stiller ben.

En ook wou ik m'n excuses aanbieden voor kerst. Ik kan wel excuusjes bedenken maar ik ben simpelweg vergeten te reageren en ging er vanuit dat Daphne het wel zou regelen en toen ik 1 dag van te voren kreeg te horen dat er niet op mij gerekend was wou ik ook niet meer aanklopen. Ik had in ieder geval graag meegewild en hoop niet dat ik jullie een gevoel heb gegeven dat ik om jullie niet mee wou, want ik waardeerde het aanbood zeker weten


En veel uiteraard veel sterkte met oma, echt een klote ziekte maar wonderen zijn de wereld nog niet uit