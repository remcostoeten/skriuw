---
id: "769a0d34-c2f5-4e52-9789-332f634e8ac2"
tags: []
sortOrder: 100
preferredEditorMode: "raw"
createdAt: 1749981435094
modifiedAt: 1749981442688
---
# Turso credentials. Generate with running this in the root 
```bash
python3 commands/generate-turso-db.py
```


DATABASE_URL=libsql://usable-phoenix-remcostoeten.aws-eu-west-1.turso.io
DATABASE_AUTH_TOKEN=eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE3NDk5NDczMjgsImlkIjoiZmEwYmQ0NTktMWVkNy00MmIyLWEwYmYtZjExMWZjY2VhZGE3IiwicmlkIjoiYzk5MjE3ZTktNTlhMC00NDVmLWE1NzktZjQ3YTE3YjE0MTA1In0.DxpEvSZ7bcjzE7Uoo1X6knrHLVakCgU8rVUdS5P_htgbet_6-XZQiGWpvOBwyLjHOkz2-uD_1HIyJz0LeVtGBw

ADMIN_EMAIL="stoetenremco.rs@gmail.com"

DISCORD_CLIENT_ID="1377031733500837989"
DISCORD_CLIENT_SECRET="4YA0szcwXRxMdfER2TuVylnAp9085BCU"
GITHUB_CLIENT_ID="Ov23liZIagZyS1oTBFYD"
GITHUB_CLIENT_SECRET="ca348cf111ae24267a92131b9705af567dd63ef5"
GOOGLE_CLIENT_ID="650774158141-l3p0mi1810e837mk6knlopj9v208lgtr.apps.googleusercontent.com"
GOOGLE_CLIENT_SECRET="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"
JWT_SECRET="ddddddddddddddddddddddddddddddwadwadwadadawwdawdawdawdawdawdawdaw="

NODE_ENV='development'

NEXT_PUBLIC_APP_URL='localhost:3000'
