---
id: "7867b42c-74f5-4dc4-b9b1-9ab5fc7d34b2"
tags: []
sortOrder: 73
preferredEditorMode: "raw"
createdAt: 1753809037453
modifiedAt: 1753809038143
---
Het is omdat jij normaal communiceert, in tegenstelling tot een bepaald ander lid (je weet vast wel wie ik bedoel), dat ik dat waardeer. Maar ik heb wel een oprechte vraag.

Blijkbaar is er een groepje dat deze zaak onderling bespreekt, wat begrijpelijk is. Ik heb gisteren iedereen op een nette manier benaderd met een volledige uitleg, inclusief het voorstel om te videobellen, mijn sociale media te delen en mijn 06-nummer te geven. Kortom, alles wat nodig is om niet anoniem te blijven en jullie vertrouwen te geven.

Dan de vraag: blijkt uit jouw schrijfstijl en uit de houding binnen jullie groepje dat er gedacht wordt dat ik mensen probeer te misleiden of wil verdwijnen zonder iets af te ronden? Als dat mijn intentie was, had ik echt geen uitgebreide berichten gestuurd. Dat begrijp je zelf vast ook wel.

Wat ik vreemd vind, is dat Piqou, die er inmiddels al aardig wat tijd in heeft gestoken, aangifte doet en dreigmails stuurt naar willekeurige mensen met mijn achternaam, die niet eens aan mij gelinkt zijn. Terwijl ik gewoon bereikbaar ben. Als hij iets gerichter had gezocht binnen de familie, was dat ook niet nodig geweest. In plaats daarvan richt hij een heel groepje op, dreigt met deurwaarders, verspreidt valse claims, en blijft, zelfs nadat ik hem heb betaald, doorgaan met alles delen. Alsof hij nog steeds denkt dat ik niet te vertrouwen ben.

Vervolgens stelt hij zelfs voor om mijn IBAN door te sturen, wat erop wijst dat hij mij nog steeds wantrouwt.

Nogmaals, dit is niet tegen jou gericht. Ik begrijp jouw houding volledig, en ik heb geen oordeel over de andere leden, behalve over deze specifieke persoon. Maar ik vraag me af wat de gedachte is achter dit gedrag, en of men echt denkt dat ik hiermee iets probeer te bereiken.

Ik begin sterk het idee te krijgen dat hij niet helemaal stabiel is. Zijn manier van communiceren doet vermoeden dat er sprake is van een emotionele of mentale beperking, en eerlijk gezegd begint het een beetje beangstigend te worden.

Iemand die geen enkele empathie toont, dreigmails stuurt naar wildvreemden met dezelfde achternaam, een groepje organiseert, aangifte doet, valse beschuldigingen verspreidt, en beweert beter te weten dan ik wie ik wel of niet heb terugbetaald. En dan, als klap op de vuurpijl, stuurt hij vier privéberichten tussen maandagmiddag en avond waarin hij zegt een privédeurwaarder in te schakelen, terwijl ik hem diezelfde middag nog uitlegde dat ik maandagavond of dinsdag zou betalen omdat zowel Tikkie als Revolut zijn geblokkeerd, en ik anders pas via Rabobank kan betalen.

Zodra ik de betaling kon doen, heb ik dat ook meteen gedaan, tussen de bedrijven door. Maar zelfs daarna voelt hij zich geroepen om opnieuw dat groepje op te trommelen en te suggereren dat mijn bankgegevens moeten worden verspreid.

Het komt inmiddels nogal obsessief en stalkerig over. Als je het aantal uren optelt dat hij hiermee bezig is geweest, dan had hij met die tijd ergens anders een 10TB SSD kunnen verdienen.

Nogmaals, dit is niet tegen jou gericht. Ik begrijp jouw houding volledig. Maar als deze obsessie aanhoudt, zou ik het waarderen als iemand binnen jullie groep hem vriendelijk duidelijk maakt dat het tijd is om dit af te sluiten. Laat hem dit desnoods lezen. Ik voel er niets voor om nog verder met zo iemand te communiceren. Zijn DMs open ik ook niet.



Last but  not least. 