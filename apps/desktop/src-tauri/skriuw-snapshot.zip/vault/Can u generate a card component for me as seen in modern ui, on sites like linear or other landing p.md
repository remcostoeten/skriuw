---
id: "b7d13cc08b3f404c91e7699683457ab3"
tags: []
sortOrder: 201
preferredEditorMode: "block"
createdAt: 1728703309483
modifiedAt: 1728703680957
---
Can u generate a card component for me as seen in modern ui, on sites like linear or other landing pages which are highly interactive.

A dark (#070707) background with a little lighter border (#171717) that has pseudo content. But the main feature is the modern effect where a small gradient (or so) follows the cursor oh so slightly to give some interactivity to the cards. The element that follows the cursor must be very subtle. Almost the same color as the background, maybe 5% lighter. And must not 1:1 follow the cursor, if should have a little bit of “own will” to it as in some random behavior to make it look natural and “spooky” werhsd  that’s.  Through a bezier curve , delay, animated rotate or scale with randomness u van decide. A completely other strategy is also fine. You’re the expert 