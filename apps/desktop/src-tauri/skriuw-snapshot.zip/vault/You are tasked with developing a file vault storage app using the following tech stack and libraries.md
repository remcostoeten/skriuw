---
id: "f7301525f83444118d00249f7e975f56"
tags: []
sortOrder: 222
preferredEditorMode: "block"
createdAt: 1722585565293
modifiedAt: 1722585569552
---
You are tasked with developing a file vault storage app using the following tech stack and libraries:

- **Next.js 14 (app router, no paged API)**
- **TypeScript**
- **Libraries:**
  - Zod (schemas over at `@/core/models`)
  - ShadCN UI (over at `@/components/ui`) [Docs](https://ui.shadcn.com/docs/)
  - Framer Motion
  - Tailwind CSS

**Database** via urso (SQLite):
- DB file over at `@/core/server/database.ts`
- DB schema over at `@core/server/schema.ts` (Split up the schemas, having one index schema file with separate schema files imported)

**Authentication** via Clerk:

All new videos go under `app/dashboard/feature/page.tsx`. Colocated components go in the components folder next to the page (`@/components`).

Hooks are located at `@/core/hooks`.

**Criteria:**
- The app should mostly use server-side rendering (SSR) with minimal client hooks.
- Code must utilize the latest Next.js features (e.g., `use`, `use optimistic`, form with `action={}` instead of classic `onSubmit`).
- Focus on developer experience (DX), user experience (UX), accessibility, and SEO.

### File Vault Storage App Requirements:

1. **User-Specific Vaults:** Each authenticated user should have a unique file vault.
2. **Initial Setup:** Prompt users to create a new folder if none exists when navigating to `app/dashboard/filevault`.
3. **File Management:**
   - Implement file upload using the [ShadCN UI file upload component](https://shadcn-extension.vercel.app/docs/file-upload).
   - Display files in both grid and list views.
   - Clicking a file should open a larger view with a sidebar displaying the file's metadata.
   - Provide options for deleting, removing, or hiding files.
   - Store all files and their metadata in user-specific tables.
4. **Folder Management:**
   - Enable users to create, rename, and organize folders within their vault.
   - Support moving files between folders and managing folder hierarchy.
5. **Search Functionality:**
   - Implement search to find files and folders based on names, types, or dates.
   - Include filters to refine search results by file type, size, or date.
6. **Sharing Functionality:**
   - Allow files/folders sharing via shareable links or email invitations.
   - Set permissions (e.g., view-only, edit) for shared files/folders.
7. **Custom Metadata:**
   - Enable users to add custom metadata (e.g., tags, descriptions) to files for better organization and retrieval.
8. **File Upload Progress:**
   - Provide a visual progress indicator during file uploads using the [ShadCN UI progress bar component](https://shadcn-extension.vercel.app/docs/progress-bar).
9. **Hidden Files:**
   - Allow files to be hidden with a 6-digit PIN using the [ShadCN UI OTP input component](https://shadcn-extension.vercel.app/docs/otp-input). Prompt users to create a PIN when hiding a file and store these PINs in user-specific tables.
10. **File Actions:**
    - Include a dedicated remove button for each file.
    - Display an overview of total storage used in MB, with visual representation using graphs.
11. **Folder Security:**
    - Implement security features for folders such as PIN verification.
12. **Notifications:**
    - Implement toast notifications for all actions using the `sonner` package: `Toast("message")`.

Ensure seamless integration with Clerk for authentication, storage of all data in user-specific tables, and an intuitive user experience for managing files and folders, including uploads, search, sharing, custom metadata, and progress visualization.