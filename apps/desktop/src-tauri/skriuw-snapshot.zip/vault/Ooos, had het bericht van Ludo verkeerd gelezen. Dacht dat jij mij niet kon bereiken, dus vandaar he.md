---
id: "004c9f15-f727-4299-b595-b2a0d5228dd0"
tags: []
sortOrder: 23
preferredEditorMode: "raw"
createdAt: 1770839757576
modifiedAt: 1770910504810
---
Ooos, had het bericht van Ludo verkeerd gelezen. Dacht dat jij mij niet kon bereiken, dus vandaar het appje. Ik heb je terug gemaild.