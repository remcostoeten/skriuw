---
id: "0af2b34e-8246-49c8-ae39-bbccffdd422d"
tags: []
sortOrder: 108
preferredEditorMode: "raw"
createdAt: 1747267122885
modifiedAt: 1747267182410
---

      _header: 'GET /api/v1/me?cache=http://192.168.1.217:8000 HTTP/1.1\r\n' +
        'Accept: application/json, text/plain, */*\r\n' +
        'X-Portal-Domain: http://192.168.1.217:8000\r\n' +
        'X-Feature-Next: 1\r\n' +
        'User-Agent: axios/1.9.0\r\n' +
        'Accept-Encoding: gzip, compress, deflate, br\r\n' +
        'Host: 192.168.1.217:8000\r\n' +
        'Connection: keep-alive\r\n' +
        '\r\n',
      _keepAliveTimeout: 0, sv
      _onPendingData: [Function: nop],
      agent: [Agent],
      socketPath: undefined,
      method: 'GET',
      maxHeaderSize: undefined,
      insecureHTTPParser: undefined,
      joinDuplicateHeaders: undefined,
      path: '/api/v1/me?cache=http://192.168.1.217:8000',
      _ended: true,
      res: [IncomingMessage],
      aborted: false,
      timeoutCb: [Function: emitRequestTimeout],
      upgradeOrConnect: false,
      parser: null,
      maxHeadersCount: null,
      reusedSocket: false,
      host: '192.168.1.217',
      protocol: 'http:',
      _redirectable: [Writable],
      Symbol(shapeMode): false,
      Symbol(kCapture): false,
      Symbol(kBytesWritten): 0,
      Symbol(kNeedDrain): false,
      Symbol(corked): 0,
      Symbol(kChunkedBuffer): [],
      Symbol(kChunkedLength): 0,
      Symbol(kSocket): [Socket],
      Symbol(kOutHeaders): [Object: null prototype],
      Symbol(errored): null,
      Symbol(kHighWaterMark): 65536,
      Symbol(kRejectNonStandardBodyWrites): false,
      Symbol(kUniqueHeaders): null
    },
    data: { errors: [Array] }
  },
  status: 404,
  page: '/auth'
}
 GET /auth?failure 500 in 1352ms
 ⨯ AxiosError: Request failed with status code 404
    at settle (file:///home/remcostoeten/dev/werk/node_modules/axios/lib/core/settle.js:19:12)
    at IncomingMessage.handleStreamEnd (file:///home/remcostoeten/dev/werk/node_modules/axios/lib/adapters/http.js:599:11)
    at IncomingMessage.emit (node:events:519:35)
    at endReadableNT (node:internal/streams/readable:1701:12)
    at process.processTicksAndRejections (node:internal/process/task_queues:90:21)
    at Axios.request (file:///home/remcostoeten/dev/werk/node_modules/axios/lib/core/Axios.js:45:41)
    at process.processTicksAndRejections (node:internal/process/task_queues:105:5)
    at async getMe (webpack-internal:///./src/Modules/academy-api/Hooks/useMe.ts:21:109)
    at async getServerSideProps$1 (webpack-internal:///./src/pages/auth/index.tsx:43:22)
    at async /home/remcostoeten/dev/werk/node_modules/@sentry/nextjs/build/cjs/common/utils/wrapperUtils.js:17:14
    at async /home/remcostoeten/dev/werk/node_modules/@sentry/nextjs/build/cjs/common/utils/wrapperUtils.js:70:13
    at async Object.apply (/home/remcostoeten/dev/werk/node_modules/@sentry/nextjs/build/cjs/common/pages-router-instrumentation/wrapGetServerSidePropsWithSentry.js:39:4)
    at async e8 (/home/remcostoeten/dev/werk/node_modules/next/dist/compiled/next-server/pages.runtime.dev.js:25:124)
    at async doRender (/home/remcostoeten/dev/werk/node_modules/next/dist/server/base-server.js:1414:30)
    at async cacheEntry.responseCache.get.routeKind (/home/remcostoeten/dev/werk/node_modules/next/dist/server/base-server.js:1588:28)
    at async DevServer.renderToResponseWithComponentsImpl (/home/remcostoeten/dev/werk/node_modules/next/dist/server/base-server.js:1496:28)
    at async DevServer.renderPageComponent (/home/remcostoeten/dev/werk/node_modules/next/dist/server/base-server.js:1924:24)
    at async DevServer.renderToResponseImpl (/home/remcostoeten/dev/werk/node_modules/next/dist/server/base-server.js:1962:32)
    at async DevServer.pipeImpl (/home/remcostoeten/dev/werk/node_modules/next/dist/server/base-server.js:922:25)
    at async NextNodeServer.handleCatchallRenderRequest (/home/remcostoeten/dev/werk/node_modules/next/dist/server/next-server.js:272:17) {
  code: 'ERR_BAD_REQUEST',
  config: {
    transitional: {
      silentJSONParsing: true,
      forcedJSONParsing: true,
      clarifyTimeoutError: false
    },
    adapter: [ 'xhr', 'http', 'fetch' ],
    transformRequest: [ [Function: transformRequest] ],
    transformResponse: [ [Function: transformResponse] ],
    timeout: 0,
    xsrfCookieName: 'XSRF-TOKEN',
    xsrfHeaderName: 'X-XSRF-TOKEN',
    maxContentLength: -1,
    maxBodyLength: -1,
    env: { FormData: [Function], Blob: [class Blob] },
    validateStatus: [Function: validateStatus],
    headers: Object [AxiosHeaders] {
      Accept: 'application/json, text/plain, */*',
      'Content-Type': undefined,
      'X-Portal-Domain': 'http://192.168.1.217:8000',
      'X-Feature-Next': '1',
      'User-Agent': 'axios/1.9.0',
      'Accept-Encoding': 'gzip, compress, deflate, br'
    },
    method: 'get',
    url: 'http://192.168.1.217:8000/api/v1/me?cache=http://192.168.1.217:8000',
    allowAbsoluteUrls: true,
    data: undefined
  },
  request: <ref *1> ClientRequest {
    _events: [Object: null prototype] {
      abort: [Function (anonymous)],
      aborted: [Function (anonymous)],
      connect: [Function (anonymous)],
      error: [Function (anonymous)],
      socket: [Function (anonymous)],
      timeout: [Function (anonymous)],
      finish: [Function: requestOnFinish]
    },
    _eventsCount: 7,
    _maxListeners: undefined,
    outputData: [],
    outputSize: 0,
    writable: true,
    destroyed: true,
    _last: true,
    chunkedEncoding: false,
    shouldKeepAlive: false,
    maxRequestsOnConnectionReached: false,
    _defaultKeepAlive: true,
    useChunkedEncodingByDefault: false,
    sendDate: false,
    _removedConnection: false,
    _removedContLen: false,
    _removedTE: false,
    strictContentLength: false,
    _contentLength: 0,
    _hasBody: true,
    _trailer: '',
    finished: true,
    _headerSent: true,
    _closed: true,
    _header: 'GET /api/v1/me?cache=http://192.168.1.217:8000 HTTP/1.1\r\n' +
      'Accept: application/json, text/plain, */*\r\n' +
      'X-Portal-Domain: http://192.168.1.217:8000\r\n' +
      'X-Feature-Next: 1\r\n' +
      'User-Agent: axios/1.9.0\r\n' +
      'Accept-Encoding: gzip, compress, deflate, br\r\n' +
      'Host: 192.168.1.217:8000\r\n' +
      'Connection: keep-alive\r\n' +
      '\r\n',
    _keepAliveTimeout: 0,
    _onPendingData: [Function: nop],
    agent: Agent {
      _events: [Object: null prototype],
      _eventsCount: 2,
      _maxListeners: undefined,
      defaultPort: 80,
      protocol: 'http:',
      options: [Object: null prototype],
      requests: [Object: null prototype] {},
      sockets: [Object: null prototype] {},
      freeSockets: [Object: null prototype] {},
      keepAliveMsecs: 1000,
      keepAlive: true,
      maxSockets: Infinity,
      maxFreeSockets: 256,
      scheduling: 'lifo',
      maxTotalSockets: Infinity,
      totalSocketCount: 0,
      Symbol(shapeMode): false,
      Symbol(kCapture): false
    },
    socketPath: undefined,
    method: 'GET',
    maxHeaderSize: undefined,
    insecureHTTPParser: undefined,
    joinDuplicateHeaders: undefined,
    path: '/api/v1/me?cache=http://192.168.1.217:8000',
    _ended: true,
    res: IncomingMessage {
      _events: [Object],
      _readableState: [ReadableState],
      _maxListeners: undefined,
      socket: [Socket],
      httpVersionMajor: 1,
      httpVersionMinor: 1,
      httpVersion: '1.1',
      complete: true,
      rawHeaders: [Array],
      rawTrailers: [],
      joinDuplicateHeaders: undefined,
      aborted: false,
      upgrade: false,
      url: '',
      method: null,
      statusCode: 404,
      statusMessage: 'Not Found',
      client: [Socket],
      _consuming: true,
      _dumped: false,
      req: [Circular *1],
      _eventsCount: 4,
      responseUrl: 'http://192.168.1.217:8000/api/v1/me?cache=http://192.168.1.217:8000',
      redirects: [],
      Symbol(shapeMode): true,
      Symbol(kCapture): false,
      Symbol(kHeaders): [Object],
      Symbol(kHeadersCount): 16,
      Symbol(kTrailers): null,
      Symbol(kTrailersCount): 0
    },
    aborted: false,
    timeoutCb: [Function: emitRequestTimeout],
    upgradeOrConnect: false,
    parser: null,
    maxHeadersCount: null,
    reusedSocket: false,
    host: '192.168.1.217',
    protocol: 'http:',
    _redirectable: Writable {
      _events: [Object],
      _writableState: [WritableState],
      _maxListeners: undefined,
      _options: [Object],
      _ended: true,
      _ending: true,
      _redirectCount: 0,
      _redirects: [],
      _requestBodyLength: 0,
      _requestBodyBuffers: [],
      _eventsCount: 3,
      _onNativeResponse: [Function (anonymous)],
      _currentRequest: [Circular *1],
      _currentUrl: 'http://192.168.1.217:8000/api/v1/me?cache=http://192.168.1.217:8000',
      Symbol(shapeMode): true,
      Symbol(kCapture): false
    },
    Symbol(shapeMode): false,
    Symbol(kCapture): false,
    Symbol(kBytesWritten): 0,
    Symbol(kNeedDrain): false,
    Symbol(corked): 0,
    Symbol(kChunkedBuffer): [],
    Symbol(kChunkedLength): 0,
    Symbol(kSocket): Socket {
      connecting: false,
      _hadError: false,
      _parent: null,
      _host: null,
      _closeAfterHandlingError: false,
      _events: [Object],
      _readableState: [ReadableState],
      _writableState: [WritableState],
      allowHalfOpen: false,
      _maxListeners: undefined,
      _eventsCount: 8,
      _sockname: null,
      _pendingData: null,
      _pendingEncoding: '',
      server: null,
      _server: null,
      timeout: 5000,
      parser: null,
      _httpMessage: [Circular *1],
      write: [Function: writeAfterFIN],
      Symbol(async_id_symbol): 331540,
      Symbol(kHandle): null,
      Symbol(lastWriteQueueSize): 0,
      Symbol(timeout): Timeout {
        _idleTimeout: -1,
        _idlePrev: null,
        _idleNext: null,
        _idleStart: 1194172,
        _onTimeout: null,
        _timerArgs: undefined,
        _repeat: null,
        _destroyed: true,
        Symbol(refed): false,
        Symbol(kHasPrimitive): false,
        Symbol(asyncId): 331539,
        Symbol(triggerId): 0,
        Symbol(kAsyncContextFrame): undefined
      },
      Symbol(kBuffer): null,
      Symbol(kBufferCb): null,
      Symbol(kBufferGen): null,
      Symbol(shapeMode): true,
      Symbol(kCapture): false,
      Symbol(kSetNoDelay): true,
      Symbol(kSetKeepAlive): true,
      Symbol(kSetKeepAliveInitialDelay): 60,
      Symbol(kBytesRead): 11913,
      Symbol(kBytesWritten): 286
    },
    Symbol(kOutHeaders): [Object: null prototype] {
      accept: [Array],
      'x-portal-domain': [Array],
      'x-feature-next': [Array],
      'user-agent': [Array],
      'accept-encoding': [Array],
      host: [Array]
    },
    Symbol(errored): null,
    Symbol(kHighWaterMark): 65536,
    Symbol(kRejectNonStandardBodyWrites): false,
    Symbol(kUniqueHeaders): null
  },
  response: {
    status: 404,
    statusText: 'Not Found',
    headers: Object [AxiosHeaders] {
      host: '192.168.1.217:8000',
      connection: 'close',
      'x-powered-by': 'PHP/8.3.19',
      'cache-control': 'no-cache, private',
      date: 'Wed, 14 May 2025 23:57:08 GMT',
      'content-type': 'application/json',
      'phpdebugbar-id': '01JV8KP16KW5GC2T09E0THGZHG',
      vary: 'Origin'
    },
    config: {
      transitional: [Object],
      adapter: [Array],
      transformRequest: [Array],
      transformResponse: [Array],
      timeout: 0,
      xsrfCookieName: 'XSRF-TOKEN',
      xsrfHeaderName: 'X-XSRF-TOKEN',
      maxContentLength: -1,
      maxBodyLength: -1,
      env: [Object],
      validateStatus: [Function: validateStatus],
      headers: [Object [AxiosHeaders]],
      method: 'get',
      url: 'http://192.168.1.217:8000/api/v1/me?cache=http://192.168.1.217:8000',
      allowAbsoluteUrls: true,
      data: undefined
    },
    request: <ref *1> ClientRequest {
      _events: [Object: null prototype],
      _eventsCount: 7,
      _maxListeners: undefined,
      outputData: [],
      outputSize: 0,
      writable: true,
      destroyed: true,
      _last: true,
      chunkedEncoding: false,
      shouldKeepAlive: false,
      maxRequestsOnConnectionReached: false,
      _defaultKeepAlive: true,
      useChunkedEncodingByDefault: false,
      sendDate: false,
      _removedConnection: false,
      _removedContLen: false,
      _removedTE: false,
      strictContentLength: false,
      _contentLength: 0,
      _hasBody: true,
      _trailer: '',
      finished: true,
      _headerSent: true,
      _closed: true,
      _header: 'GET /api/v1/me?cache=http://192.168.1.217:8000 HTTP/1.1\r\n' +
        'Accept: application/json, text/plain, */*\r\n' +
        'X-Portal-Domain: http://192.168.1.217:8000\r\n' +
        'X-Feature-Next: 1\r\n' +
        'User-Agent: axios/1.9.0\r\n' +
        'Accept-Encoding: gzip, compress, deflate, br\r\n' +
        'Host: 192.168.1.217:8000\r\n' +
        'Connection: keep-alive\r\n' +
        '\r\n',
      _keepAliveTimeout: 0,
      _onPendingData: [Function: nop],
      agent: [Agent],
      socketPath: undefined,
      method: 'GET',
      maxHeaderSize: undefined,
      insecureHTTPParser: undefined,
      joinDuplicateHeaders: undefined,
      path: '/api/v1/me?cache=http://192.168.1.217:8000',
      _ended: true,
      res: [IncomingMessage],
      aborted: false,
      timeoutCb: [Function: emitRequestTimeout],
      upgradeOrConnect: false,
      parser: null,
      maxHeadersCount: null,
      reusedSocket: false,
      host: '192.168.1.217',
      protocol: 'http:',
      _redirectable: [Writable],
      Symbol(shapeMode): false,
      Symbol(kCapture): false,
      Symbol(kBytesWritten): 0,
      Symbol(kNeedDrain): false,
      Symbol(corked): 0,
      Symbol(kChunkedBuffer): [],
      Symbol(kChunkedLength): 0,
      Symbol(kSocket): [Socket],
      Symbol(kOutHeaders): [Object: null prototype],
      Symbol(errored): null,
      Symbol(kHighWaterMark): 65536,
      Symbol(kRejectNonStandardBodyWrites): false,
      Symbol(kUniqueHeaders): null
    },
    data: { errors: [Array] }
  },
  status: 404,
  page: '/auth'
}
 GET /auth?return=/admin 500 in 323ms
 ⨯ AxiosError: Request failed with status code 404
    at settle (file:///home/remcostoeten/dev/werk/node_modules/axios/lib/core/settle.js:19:12)
    at IncomingMessage.handleStreamEnd (file:///home/remcostoeten/dev/werk/node_modules/axios/lib/adapters/http.js:599:11)
    at IncomingMessage.emit (node:events:519:35)
    at endReadableNT (node:internal/streams/readable:1701:12)
    at process.processTicksAndRejections (node:internal/process/task_queues:90:21)
    at Axios.request (file:///home/remcostoeten/dev/werk/node_modules/axios/lib/core/Axios.js:45:41)
    at process.processTicksAndRejections (node:internal/process/task_queues:105:5)
    at async getMe (webpack-internal:///./src/Modules/academy-api/Hooks/useMe.ts:21:109)
    at async getServerSideProps$1 (webpack-internal:///./src/pages/auth/index.tsx:43:22)
    at async /home/remcostoeten/dev/werk/node_modules/@sentry/nextjs/build/cjs/common/utils/wrapperUtils.js:17:14
    at async /home/remcostoeten/dev/werk/node_modules/@sentry/nextjs/build/cjs/common/utils/wrapperUtils.js:70:13
    at async Object.apply (/home/remcostoeten/dev/werk/node_modules/@sentry/nextjs/build/cjs/common/pages-router-instrumentation/wrapGetServerSidePropsWithSentry.js:39:4)
    at async e8 (/home/remcostoeten/dev/werk/node_modules/next/dist/compiled/next-server/pages.runtime.dev.js:25:124)
    at async doRender (/home/remcostoeten/dev/werk/node_modules/next/dist/server/base-server.js:1414:30)
    at async cacheEntry.responseCache.get.routeKind (/home/remcostoeten/dev/werk/node_modules/next/dist/server/base-server.js:1588:28)
    at async DevServer.renderToResponseWithComponentsImpl (/home/remcostoeten/dev/werk/node_modules/next/dist/server/base-server.js:1496:28)
    at async DevServer.renderPageComponent (/home/remcostoeten/dev/werk/node_modules/next/dist/server/base-server.js:1924:24)
    at async DevServer.renderToResponseImpl (/home/remcostoeten/dev/werk/node_modules/next/dist/server/base-server.js:1962:32)
    at async DevServer.pipeImpl (/home/remcostoeten/dev/werk/node_modules/next/dist/server/base-server.js:922:25)
    at async NextNodeServer.handleCatchallRenderRequest (/home/remcostoeten/dev/werk/node_modules/next/dist/server/next-server.js:272:17) {
  code: 'ERR_BAD_REQUEST',
  config: {
    transitional: {
      silentJSONParsing: true,
      forcedJSONParsing: true,
      clarifyTimeoutError: false
    },
    adapter: [ 'xhr', 'http', 'fetch' ],
    transformRequest: [ [Function: transformRequest] ],
    transformResponse: [ [Function: transformResponse] ],
    timeout: 0,
    xsrfCookieName: 'XSRF-TOKEN',
    xsrfHeaderName: 'X-XSRF-TOKEN',
    maxContentLength: -1,
    maxBodyLength: -1,
    env: { FormData: [Function], Blob: [class Blob] },
    validateStatus: [Function: validateStatus],
    headers: Object [AxiosHeaders] {
      Accept: 'application/json, text/plain, */*',
      'Content-Type': undefined,
      'X-Portal-Domain': 'http://192.168.1.217:8000',
      'X-Feature-Next': '1',
      'User-Agent': 'axios/1.9.0',
      'Accept-Encoding': 'gzip, compress, deflate, br'
    },
    method: 'get',
    url: 'http://192.168.1.217:8000/api/v1/me?cache=http://192.168.1.217:8000',
    allowAbsoluteUrls: true,
    data: undefined
  },
  request: <ref *1> ClientRequest {
    _events: [Object: null prototype] {
      abort: [Function (anonymous)],
      aborted: [Function (anonymous)],
      connect: [Function (anonymous)],
      error: [Function (anonymous)],
      socket: [Function (anonymous)],
      timeout: [Function (anonymous)],
      finish: [Function: requestOnFinish]
    },
    _eventsCount: 7,
    _maxListeners: undefined,
    outputData: [],
    outputSize: 0,
    writable: true,
    destroyed: true,
    _last: true,
    chunkedEncoding: false,
    shouldKeepAlive: false,
    maxRequestsOnConnectionReached: false,
    _defaultKeepAlive: true,
    useChunkedEncodingByDefault: false,
    sendDate: false,
    _removedConnection: false,
    _removedContLen: false,
    _removedTE: false,
    strictContentLength: false,
    _contentLength: 0,
    _hasBody: true,
    _trailer: '',
    finished: true,
    _headerSent: true,
    _closed: true,
    _header: 'GET /api/v1/me?cache=http://192.168.1.217:8000 HTTP/1.1\r\n' +
      'Accept: application/json, text/plain, */*\r\n' +
      'X-Portal-Domain: http://192.168.1.217:8000\r\n' +
      'X-Feature-Next: 1\r\n' +
      'User-Agent: axios/1.9.0\r\n' +
      'Accept-Encoding: gzip, compress, deflate, br\r\n' +
      'Host: 192.168.1.217:8000\r\n' +
      'Connection: keep-alive\r\n' +
      '\r\n',
    _keepAliveTimeout: 0,
    _onPendingData: [Function: nop],
    agent: Agent {
      _events: [Object: null prototype],
      _eventsCount: 2,
      _maxListeners: undefined,
      defaultPort: 80,
      protocol: 'http:',
      options: [Object: null prototype],
      requests: [Object: null prototype] {},
      sockets: [Object: null prototype] {},
      freeSockets: [Object: null prototype] {},
      keepAliveMsecs: 1000,
      keepAlive: true,
      maxSockets: Infinity,
      maxFreeSockets: 256,
      scheduling: 'lifo',
      maxTotalSockets: Infinity,
      totalSocketCount: 0,
      Symbol(shapeMode): false,
      Symbol(kCapture): false
    },
    socketPath: undefined,
    method: 'GET',
    maxHeaderSize: undefined,
    insecureHTTPParser: undefined,
    joinDuplicateHeaders: undefined,
    path: '/api/v1/me?cache=http://192.168.1.217:8000',
    _ended: true,
    res: IncomingMessage {
      _events: [Object],
      _readableState: [ReadableState],
      _maxListeners: undefined,
      socket: [Socket],
      httpVersionMajor: 1,
      httpVersionMinor: 1,
      httpVersion: '1.1',
      complete: true,
      rawHeaders: [Array],
      rawTrailers: [],
      joinDuplicateHeaders: undefined,
      aborted: false,
      upgrade: false,
      url: '',
      method: null,
      statusCode: 404,
      statusMessage: 'Not Found',
      client: [Socket],
      _consuming: true,
      _dumped: false,
      req: [Circular *1],
      _eventsCount: 4,
      responseUrl: 'http://192.168.1.217:8000/api/v1/me?cache=http://192.168.1.217:8000',
      redirects: [],
      Symbol(shapeMode): true,
      Symbol(kCapture): false,
      Symbol(kHeaders): [Object],
      Symbol(kHeadersCount): 16,
      Symbol(kTrailers): null,
      Symbol(kTrailersCount): 0
    },
    aborted: false,
    timeoutCb: [Function: emitRequestTimeout],
    upgradeOrConnect: false,
    parser: null,
    maxHeadersCount: null,
    reusedSocket: false,
    host: '192.168.1.217',
    protocol: 'http:',
    _redirectable: Writable {
      _events: [Object],
      _writableState: [WritableState],
      _maxListeners: undefined,
      _options: [Object],
      _ended: true,
      _ending: true,
      _redirectCount: 0,
      _redirects: [],
      _requestBodyLength: 0,
      _requestBodyBuffers: [],
      _eventsCount: 3,
      _onNativeResponse: [Function (anonymous)],
      _currentRequest: [Circular *1],
      _currentUrl: 'http://192.168.1.217:8000/api/v1/me?cache=http://192.168.1.217:8000',
      Symbol(shapeMode): true,
      Symbol(kCapture): false
    },
    Symbol(shapeMode): false,
    Symbol(kCapture): false,
    Symbol(kBytesWritten): 0,
    Symbol(kNeedDrain): false,
    Symbol(corked): 0,
    Symbol(kChunkedBuffer): [],
    Symbol(kChunkedLength): 0,
    Symbol(kSocket): Socket {
      connecting: false,
      _hadError: false,
      _parent: null,
      _host: null,
      _closeAfterHandlingError: false,
      _events: [Object],
      _readableState: [ReadableState],
      _writableState: [WritableState],
      allowHalfOpen: false,
      _maxListeners: undefined,
      _eventsCount: 8,
      _sockname: null,
      _pendingData: null,
      _pendingEncoding: '',
      server: null,
      _server: null,
      timeout: 5000,
      parser: null,
      _httpMessage: [Circular *1],
      write: [Function: writeAfterFIN],
      Symbol(async_id_symbol): 338113,
      Symbol(kHandle): null,
      Symbol(lastWriteQueueSize): 0,
      Symbol(timeout): Timeout {
        _idleTimeout: -1,
        _idlePrev: null,
        _idleNext: null,
        _idleStart: 1194382,
        _onTimeout: null,
        _timerArgs: undefined,
        _repeat: null,
        _destroyed: true,
        Symbol(refed): false,
        Symbol(kHasPrimitive): false,
        Symbol(asyncId): 338112,
        Symbol(triggerId): 0,
        Symbol(kAsyncContextFrame): undefined
      },
      Symbol(kBuffer): null,
      Symbol(kBufferCb): null,
      Symbol(kBufferGen): null,
      Symbol(shapeMode): true,
      Symbol(kCapture): false,
      Symbol(kSetNoDelay): true,
      Symbol(kSetKeepAlive): true,
      Symbol(kSetKeepAliveInitialDelay): 60,
      Symbol(kBytesRead): 11913,
      Symbol(kBytesWritten): 286
    },
    Symbol(kOutHeaders): [Object: null prototype] {
      accept: [Array],
      'x-portal-domain': [Array],
      'x-feature-next': [Array],
      'user-agent': [Array],
      'accept-encoding': [Array],
      host: [Array]
    },
    Symbol(errored): null,
    Symbol(kHighWaterMark): 65536,
    Symbol(kRejectNonStandardBodyWrites): false,
    Symbol(kUniqueHeaders): null
  },
  response: {
    status: 404,
    statusText: 'Not Found',
    headers: Object [AxiosHeaders] {
      host: '192.168.1.217:8000',
      connection: 'close',
      'x-powered-by': 'PHP/8.3.19',
      'cache-control': 'no-cache, private',
      date: 'Wed, 14 May 2025 23:57:08 GMT',
      'content-type': 'application/json',
      'phpdebugbar-id': '01JV8KP1DGZYKK9MBTBVTXBBPB',
      vary: 'Origin'
    },
    config: {
      transitional: [Object],
      adapter: [Array],
      transformRequest: [Array],
      transformResponse: [Array],
      timeout: 0,
      xsrfCookieName: 'XSRF-TOKEN',
      xsrfHeaderName: 'X-XSRF-TOKEN',
      maxContentLength: -1,
      maxBodyLength: -1,
      env: [Object],
      validateStatus: [Function: validateStatus],
      headers: [Object [AxiosHeaders]],
      method: 'get',
      url: 'http://192.168.1.217:8000/api/v1/me?cache=http://192.168.1.217:8000',
      allowAbsoluteUrls: true,
      data: undefined
    },
    request: <ref *1> ClientRequest {
      _events: [Object: null prototype],
      _eventsCount: 7,
      _maxListeners: undefined,
      outputData: [],
      outputSize: 0,
      writable: true,
      destroyed: true,
      _last: true,
      chunkedEncoding: false,
      shouldKeepAlive: false,
      maxRequestsOnConnectionReached: false,
      _defaultKeepAlive: true,
      useChunkedEncodingByDefault: false,
      sendDate: false,
      _removedConnection: false,
      _removedContLen: false,
      _removedTE: false,
      strictContentLength: false,
      _contentLength: 0,
      _hasBody: true,
      _trailer: '',
      finished: true,
      _headerSent: true,
      _closed: true,
      _header: 'GET /api/v1/me?cache=http://192.168.1.217:8000 HTTP/1.1\r\n' +
        'Accept: application/json, text/plain, */*\r\n' +
        'X-Portal-Domain: http://192.168.1.217:8000\r\n' +
        'X-Feature-Next: 1\r\n' +
        'User-Agent: axios/1.9.0\r\n' +
        'Accept-Encoding: gzip, compress, deflate, br\r\n' +
        'Host: 192.168.1.217:8000\r\n' +
        'Connection: keep-alive\r\n' +
        '\r\n',
      _keepAliveTimeout: 0,
      _onPendingData: [Function: nop],
      agent: [Agent],
      socketPath: undefined,
      method: 'GET',
      maxHeaderSize: undefined,
      insecureHTTPParser: undefined,
      joinDuplicateHeaders: undefined,
      path: '/api/v1/me?cache=http://192.168.1.217:8000',
      _ended: true,
      res: [IncomingMessage],
      aborted: false,
      timeoutCb: [Function: emitRequestTimeout],
      upgradeOrConnect: false,
      parser: null,
      maxHeadersCount: null,
      reusedSocket: false,
      host: '192.168.1.217',
      protocol: 'http:',
      _redirectable: [Writable],
      Symbol(shapeMode): false,
      Symbol(kCapture): false,
      Symbol(kBytesWritten): 0,
      Symbol(kNeedDrain): false,
      Symbol(corked): 0,
      Symbol(kChunkedBuffer): [],
      Symbol(kChunkedLength): 0,
      Symbol(kSocket): [Socket],
      Symbol(kOutHeaders): [Object: null prototype],
      Symbol(errored): null,
      Symbol(kHighWaterMark): 65536,
      Symbol(kRejectNonStandardBodyWrites): false,
      Symbol(kUniqueHeaders): null
    },
    data: { errors: [Array] }
  },
  status: 404,
  page: '/auth'
}
 GET /auth?return=/admin 500 in 193ms



 notice
 finished: true,
      _headerSent: true,
      _closed: true,
      _header: 'GET /api/v1/me?cache=http://192.168.1.217:8000 HTTP/1.1\r\n' +
        'Accept: application/json, text/plain, */*\r\n' +
        'X-Portal-Domain: http://192.168.1.217:8000\r\n' +
        'X-Feature-Next: 1\r\n' +
        'User-Agent: axios/1.9.0\r\n' +
        'Accept-Encoding: gzip, compr


        but if i visit  it with curl it works fine
        -dump-key\u003Edate\u003C\/span\u003E\u0022 =\u003E \u003Cspan class=sf-dump-note\u003Earray:1\u003C\/span\u003E [\u003Csamp data-depth=2 class=sf-dump-compact\u003E\n    \u003Cspan class=sf-dump-index\u003E0\u003C\/span\u003E =\u003E \u0022\u003Cspan class=sf-dump-str title=\u002229 characters\u0022\u003EWed, 14 May 2025 23:59:14 GMT\u003C\/span\u003E\u0022\n  \u003C\/samp\u003E]\n  \u0022\u003Cspan class=sf-dump-key\u003Econtent-type\u003C\/span\u003E\u0022 =\u003E \u003Cspan class=sf-dump-note\u003Earray:1\u003C\/span\u003E [\u003Csamp data-depth=2 class=sf-dump-compact\u003E\n    \u003Cspan class=sf-dump-index\u003E0\u003C\/span\u003E =\u003E \u0022\u003Cspan class=sf-dump-str title=\u002224 characters\u0022\u003Etext\/html; charset=UTF-8\u003C\/span\u003E\u0022\n  \u003C\/samp\u003E]\n\u003C\/samp\u003E]\n\u003C\/pre\u003E\u003Cscript\u003ESfdump(\u0022sf-dump-280699670\u0022, {\u0022maxDepth\u0022:0})\u003C\/script\u003E\n","session_attributes":"\u003Cpre class=sf-dump id=sf-dump-1929500762 data-indent-pad=\u0022  \u0022\u003E[]\n\u003C\/pre\u003E\u003Cscript\u003ESfdump(\u0022sf-dump-1929500762\u0022, {\u0022maxDepth\u0022:0})\u003C\/script\u003E\n"},"tooltip":{"status":"404 Not Found","full_url":"http:\/\/192.168.1.217:8000","controller_action":"Modules\\Core\\Http\\Web\\Generic\\Controllers\\StartupController@index"},"badge":"404 Not Found"}}, "01JV8KSWTSD6Q2A5CZNYDYV37T");

</script>
</body>
</html>
remcostoeten@pop-os:~$



