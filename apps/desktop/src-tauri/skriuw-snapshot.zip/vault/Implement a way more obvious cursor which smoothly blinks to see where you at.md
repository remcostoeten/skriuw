---
id: "f358f114-9d90-4d87-ad4d-3f33dbbf9ecc"
tags: []
sortOrder: 104
preferredEditorMode: "raw"
createdAt: 1748102113567
modifiedAt: 1748105685788
---
Implement a way more obvious cursor which smoothly blinks to see where you at

Make the help only toggle with ctrl alt ? 

? should toggle search just like in vim

dd should remove
5dd should remove 5  , any number
5bd should remove 5 previous etc

Also have a option to make the screen key recorder way more prominent in view

https://v0-neovim-emulator-keybind-creat.vercel.app/Take take take GGGGGGG