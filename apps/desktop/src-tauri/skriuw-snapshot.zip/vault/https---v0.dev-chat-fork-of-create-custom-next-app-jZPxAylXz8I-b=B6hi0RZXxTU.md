---
id: "60d8adf5-5cff-44ec-b168-bd50908098ca"
tags: []
sortOrder: 158
preferredEditorMode: "raw"
createdAt: 1737079857037
modifiedAt: 1737079857672
---
https://v0.dev/chat/fork-of-create-custom-next-app-jZPxAylXz8I?b=B6hi0RZXxTU