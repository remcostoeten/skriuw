---
id: "b1278ecf-cfb5-42fb-93af-651dbcd24d84"
tags: []
sortOrder: 210
preferredEditorMode: "block"
createdAt: 1726441675939
modifiedAt: 1726618195520
---
## run'openssl rand -base64 32'
NEXTAUTH_SECRET='hsrmRMMDx8IKEAsJE7DFgOzOOw97k6EATvY0C2lVNh4='

## Local url for next auth
NEXTAUTH_URL=http://localhost:3000

# Database (?not needed?)
AUTH_DRIZZLE_URL=sqlite:///.drizzle.sqlite

## https://turso.io/
DATABASE_URL=libsql://hahhh-remcostoeten.turso.io
DATABASE_AUTH_TOKEN=eyJhbGciOiJFZERTQSIsInR5cCI6IkpXVCJ9.eyJpYXQiOjE3MjY0MzI4OTksImlkIjoiZjU0ZDQzODMtZDQ2Ni00MjAxLTk0OGUtZTZhZjA4YTczY2UxIn0.xDTv8YSJPQiHcS9bsaKkd1I31P4vH8tgSzwMRc49Jl7zia8zgFNK_yuEr8oFCE4dE12HDr039_ZrLvEDg4JLBA

## https://github.com/settings/developers
GITHUB_CLIENT_ID=Ov23liaUq1zh2jzMKBV0
GITHUB_CLIENT_SECRET=2576732ba03d264385333f4db99b0dd6fd72644b

## https://console.cloud.google.com/apis/credentials
GOOGLE_CLIENT_ID=771038518815-qo4vdc4npe5p2np3rdgjidmr66auvfet.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=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

## Github access DATABASE_AUTH_TOKEN
GITHUB_TOKEN=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

WEATHER_API=a2ea91e925014beebc28dbae909f0c24

https://v0.dev/chat/mX1Nk09E9As
https://v0.dev/chat/s2OXmma7a4u
https://v0.dev/chat/ieaiQZ7Pg6H

