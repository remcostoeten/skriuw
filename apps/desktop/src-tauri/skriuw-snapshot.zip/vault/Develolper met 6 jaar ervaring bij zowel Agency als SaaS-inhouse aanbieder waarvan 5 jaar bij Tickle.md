---
id: "9177371a-35c2-45d4-90f0-3ebdebf09d37"
tags: []
sortOrder: 301
preferredEditorMode: "raw"
createdAt: 1677974533453
modifiedAt: 1678135710621
---
Develolper met 6 jaar ervaring bij zowel Agency als SaaS/inhouse aanbieder waarvan 5 jaar bij Tickles Digital Agency. Bij Tickles was ik verantwoordelijk de implementatie van  custom Magento 2 webshops varierend van klein tot groot  in allerlij sectoren.  Daarnava nbaan gewisseld waar  ik                                                                          ee rstekennismakign met React  heb gehad door te werken aan een SaaS-project. Vervolgens volledig gestort op het herschrijven van  de frontend, waarbij ik legacy code  heb herschreven naar semantische HTML en  mijn eigen SCSS-structuur wat future proof is en kan scalen.  Bij Distil en Tickles zat bijna enkel Vanilla/jQuery in de  stack, en omdat ik wel ambieer om mooie software te schrijven in moderne techonlogieen ben ik de laatste weken  volop     bezig met mijn eigen project site waar ik allerlij features bouw met als doel moderne framework  te leren.

Zoals ik zei accepteer ik je antwoord wel maar zou ik het wel fijn vinden om eens van je te begrijpen waarom je me altijd dingen toezegd  terwijl je op dat moment zelf al wel weet dat je het helemaal niet wilt doen

Ik accepteer je antwoord wel alleen  zou ik het wel fijn vinden als je me gewoon uit wil leggen waarom  je er initieel voor kiest om het tegenovergestelde te doen.

Zou fijn zijn als je dat iig wil uitleggen en verder laat ik je wel want is wel duidelijk  dat je geen behoefte/zin hebt om een gesprek te voeren en oprecht geintresseerd bent of irl wat wilt ondernemen