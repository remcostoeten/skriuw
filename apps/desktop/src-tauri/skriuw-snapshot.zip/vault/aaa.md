---
id: "c9116e45-0844-4edc-9cc2-03d3acdaad99"
tags: []
sortOrder: 109
preferredEditorMode: "raw"
createdAt: 1747266734681
modifiedAt: 1747266823005
---
aaa



APP_ENV=development
NEXT_PUBLIC_APP_ENV=development
NODE_ENV=development

#################
##   BACKEND   ##
#################
BACKEND_ENDPOINT=http://courseware.test
FALLBACK_ENDPOINT=$BACKEND_ENDPOINT
API_ENDPOINT=$BACKEND_ENDPOINT/api

# Change the domain communicated as X-PORTAL-DOMAIN header in API calls:
PORTAL_DOMAIN=$BACKEND_ENDPOINT

##############
##   AUTH   ##
##############
AUTH_COOKIE_NAME=auth_token
# BEARER_TOKEN="eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIyMCIsImp0aSI6IjA5ZGI1YTJmNTYxOTVlODQ2YTMyZDBlNjhlMDcxZTE4OWU3NjEyZGQzNjBkNDQyNDczMDhhNzQzYmRhMjI4OThmNWRhN2M1MWY3YjBhNjM3IiwiaWF0IjoxNzQyNDYxMjkxLjU1OTA1MSwibmJmIjoxNzQyNDYxMjkxLjU1OTA1MywiZXhwIjoxNzczOTk3MjkxLjU1NjA2Nywic3ViIjoiOTkyODUiLCJzY29wZXMiOltdfQ.drwveNSaZRgt5lPBw2AEce5to7xNyehMQfkNjcA-SYxr_2KGwQBxn2vQ_RcZ2O9YM5ijerQO41NBHH9icdyRH1_sO45VF8vZ9zrbWOhINlw1KGqzCIOSXtftCKbO8er0ktYrYDD_B3NWkPy1QPj0U7VWkHqMtwlLmTDUc0NG5SRzwYVXsvIWekrzcQ223N-4qYPVJJxwP3vwO2Happo881guPVTrtyU5ix8-2SU_dZhvL25XcHkrp5SgQvB0e7-lDDC54-bUZSU8dcBnosrz0_CHft3rC_TwToE2qCVis-aGQK0Gr2ZJVq19jeVm6fLhsOuRU_2wI9AOYdo0Y3jX22amix2dVIJwY5hvclLRrbeGVEHXDXCrwZSvUeoLPmcBrk-hMO9BSe7rIYmYZ0oNF9oOhW1tNxC8iLkINN1I8aB02QKxjRUbESLmG3urzPiJyuCsohiAY4h_1KjQkhdQcALRDolPOvnP4wPajyQkbowGvCyn0JhzVr22RpZWsG7oqxtaTV2FUcyaPx1jPONtn-ycR3AZ-kv5_EQNLiuOI-DboHlNfJLR44vOEDVNq4FdjH958yJz8WHFKjRhfMDXkAki_Lr4OhLbXwIwMrRXNLz7lJs_0A8WlT0ppsSJG2FgwQpgd0AkUS6KMYPXbAnF3wyK1NAtQvOVWB7fulphtjg"


BEARER_TOKEN=eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.eyJhdWQiOiIxIiwianRpIjoiMDJmY2M5ODY4MjcxNTY5NTA0ZTc3YmFlMTEwY2NlY2I2N2FjNDYxMDczZDA1MGYxNGM5ZTI3NzQ5MGVlODYwY2M1YmI3MzFjNGRlOGZmYmUiLCJpYXQiOjE3NDY2MTY5OTYuNjc5MTU1LCJuYmYiOjE3NDY2MTY5OTYuNjc5MTU2LCJleHAiOjE3NzgxNTI5OTYuNjc2MDM2LCJzdWIiOiIzMSIsInNjb3BlcyI6W119.ach3ysdMxeHAvgBa-fmbREyePBQO2vLiHKaNv0ccyM_hCtiM7YppjVKFdjuuj6tOXNXTXd6nHogvNt0Tp9TscFuYoi_saHXJJ9aSd8vzTJCR7A4blwS2xTGXc562d9yvhzZ3p2nToTBfP0oYdoyDL1AvzstL380yozQwvetHJRC972-eVapsRYEIwG59NKDVIloTm65c0BhxzNpARFdELNF1Om3FMZI5D9ApLDGwyWcHhvhpMDdt_8HGJIUc_bBPeP4xfs_iEnN8d9gO1q8do4NVonotEEDqARW8kmCgMFdee2-k3N9Dp47m1H3o0Yxs6fkRAQoY5yTr4Scbk-2z0g2fd1h0mzWWbLdRSZLk891TgZOulkDtS_ZGy29Ijo712Z7nok_QOXniTOYzk_K_PEyUOuE6zPjFUqeaX3r3KPpwj77AdtBtt1EYpMB5_CaXxQpE5mD-vxENwMbkdlkjZ7buzQ7YW8_Ee1h8UL7hn43L-Iec_PpKzkv4_MpS9tJjgEW8U8ptylOMuZ2gsfetGt75PSHvfwLzlcPA4lZdo66CLsusD6WHEps9rRccJHXNNsRo1zxjiywv8hIBC4kk5OSW31MjXUm7cInuMEZkn41yRxpmPpmWsMjzzlOnKsgAF84uRwW2TP4sM9Yu2ZSKB6Bn-LqtA0aeYG_R-2R07TA

### BEARER_TOKEN VAN LOCAL courseware ###

##################
# Only required during development
OAUTH_CLIENT_ID=23
OAUTH_CLIENT_SECRET=# Ask someone with staging database access

# Used to compute the localhost oauth login route during development
NEXT_PUBLIC_DEV_OAUTH_URL=$BACKEND_ENDPOINT
NEXT_PUBLIC_OAUTH_REDIRECT_URL=http://localhostcccccccccccccccccccccccccccccccccccccccccccccccc:3000/api/auth/token
NEXT_PUBLIC_OAUTH_CLIENT_ID=23


################
##  New Relic ##
################
NEW_RELIC_ENABLED=false


###################
##   DEBUGGING   ##
###################
NEXT_PUBLIC_REACT_SCAN=false
