---
id: "68413aee06134cde812371350bfe2e3e"
tags: []
sortOrder: 189
preferredEditorMode: "block"
createdAt: 1731211258983
modifiedAt: 1732506392100
---
emWere going to create our own in house, no dependency / library analytics page (with all components and server files needed)

- utilize SOLID. In features/analytics
- Components folder
- Server folder with schema which we import into the main schema index.ts.
- Server / actions / index.ts where we export all individual server actions.
- Utilities / optional utilities files, config files 

First logic / features:

- track total site visitor count ( if I press f 5 I should not be counted as more than 1.) store cookie AND store ip for 1 week or so(??l maybe other good idea?)
- Track each individual route visitor count 
- allow opt out certain routes via config file 
- Allow opt out/disable tracking off localhost via config file

Session tracker:
Count how many tiles someone tries to log in. Start counting if fail > 2
- Count how many tiles someone tries to log in. Start counting if fail >2
- Count how long someone is on a page with a session

- personal info tracking 
- besides page views we want for each visitor the followowing data:
        -  country
        - isNewVisior?
        - if that is no count how many times user is on the site 
        - Visit duration
        - visit device
        - Visit os
        - Visit browser
        - Visif continent
        - Device type : desktop mobile tablet laptop 
        - Bounce rate
        - Per page check if is first visit so we can have entry per individual page
        - Source entry is from
        -  other suggesiltiokd are welcome

Ui webpage 
Display utilizing shadcn and tailwind and served actions. No api route
Sepersretr of concerns

- total visiter count
- Followed by a interactive chart/graph to see history 
- blocks with visitor stats
- green or red trend with %  increase of gain. Vs last 7 day
- total page views with same stats
- Bounce rate with state
- Visitor duraatiok avg with stats 

Table paged overview WiFi percentage and entries and route

Source overview with entries and percentage 

Software overview

Second column:
Device overview  with decrease or increase pe r device and total market cap of all visitor devices

A interactive map with highlighted locations
Nelson it top 5-10 countries with percentage and count 

Language block 



Must be NextJS 15, SSR, no api routes. Properly typed, separate of concerns 



I’ve got db setup from turso SQLite via drizzle orm. I have custom roll your own jwt auth so create a importanlec schema file and server actions that post to there and also querie the posted data for the overviews dashboard

Also add all dates to schemas so we can filter on 7 days vs 31 etc.

Any other suggestions?