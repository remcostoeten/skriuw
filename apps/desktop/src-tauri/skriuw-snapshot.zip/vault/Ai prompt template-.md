---
id: "7965458ff19a4155adcf096910d9a1ab"
tags: []
sortOrder: 221
preferredEditorMode: "block"
createdAt: 1722478704291
modifiedAt: 1723334225442
---
Ai prompt template:

Tech stack: 
- [ ] Nextjs 14 (app router. no paged api
- [ ] Typescript
- [ ] libraries:
- [ ]    Zod (schemas over at @/core/models
- [ ]   Shadcnui ( over at @/components/ui) https://ui.shadcn.com/docs/
- [ ]    Framer motion
- [ ] Tailwindcss

Database via urso(SQLite) 
     Db file over at @/core/server/database.ts
      Db schema over wat @core/server/schema.ts
      (If possible  i'd like to split up the scheams so have 1 index schema file with seperate schemas files imported.

Auth via clerk.

All new videos wil je out here /dashboarx/feature/page.tsx colocated components go in  components folder next to the page. Ofjsdwizd @/compondnfs.

Hooks over at @/core/hooks

Criteria:: mostly ssr. Little client hooks.
Code must make use of newest next feature if possible (use, use optimistic, form with action={} instead of classic. Ok submit. Think about dx. Ui/ux, accsssibillif and seo
_____________________

Now for the feature.
I want a finance feature. When comming on the fiannce page you're prompted with some questions. 
1) euro or dollar
2) How much is your monthly income
3) how much is your current saving balance
4) do you have a save goal? yes> how much no > continue to overvieuw.

Category-
Via shadcn component allow to add expense categories: 
e.g. supermarket, car, sports. Allowto add multiple and a save button. They do not appear anywhere only in the database

Expense:
Button to create new expense:(shadcn again, maybe modal or popover)
-Title
-Optional: description:
-Optional: date (if no date is set do current date)
-Optional category (allow to choose from categories made earlier)
-$ or euro sign followed by how much u spent ( not optional)
- Submit new expense button
When submitted show toast message

-Display expenses.
Display expenses in a nice overview with the categorys inside labels/pills and at the end calculate all expenses onto eachother for the total expenses.

Income:
Add income button
Title: Income from who?
description: optional
Date (allow periode let'ssay salary 24-jun - 24-jul)
How much?
Save btn

Display income/total wealth for this month
Show 

-Total monthly recap
Show how much you had expenses, income, and substract them from each other. Show red if negative show green if positive. 

Try to add toast (from 'sonner') and tooltips everywhere for good info.

Make sure to use the latest nextjs and react functions like 'use' and 'useOptimistic' and server actions with form='action' instead of classic onsubmit. Alsomake sure to use skeleton loaders and most is SSR loaded thus try to avoid use effect etc

then allow to create expense via shadcn:
Title
optional date:
optional description
Currency sign + how much u spend
label/category  ( from categorys created earleir)


After submit display them and calcualte the total

