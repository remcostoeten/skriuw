---
id: "6df913c9-f178-44b5-9f64-cd0723cf4410"
tags: []
sortOrder: 133
preferredEditorMode: "raw"
createdAt: 1742211376774
modifiedAt: 1742211704156
---
 hey Adrian I hope you're doing well my name is Remco and I'm a front developer from the Netherlands I have worked at agencies and multi-national SaaS and yada yada yada but never tabbled into testing framework.

 Now I've built a wood scraper in the past in Brighton Chrome drive just to learn some chrome driver but right now I have been wanting to scrape my own followers on Instagram idealy through a cron.

 I have noticed the 12 limits network request Instagram sent out when you cultural followers and I'd like to have a way to retrieve all my followers and only use your name and maybe  UUID because that's always stable just for comparison to see who unfollowed and just for hobby purposes not for marketing stuff. So I was wondering if there would be a possibility that I could get a hold of the script you showcase in the script Instagram video or if you're willing to help me.

 I'm not sure if this is something for you but I have built quite a cool front and where you can upload a CSV file which I currently export through a browser extension which extract my followers and inside this application you are able to to categorise upload all the fees and compared them she relationships between them and it has a really neat front end I think so at least so it would be a perfect application to use your API in I understand that you probably do not provide it for free and if that is the case then I'm sorry for wasting your time because I am not in the financial possibility to pay for software currently but I just wanted to show you my project anyways it is deployed here LINK and it is open source HERE.

 It only accepts a certain fee format but I have built a demo button which you can't miss and if you click on that button to do these fees get added to your profile so say so you can go to the profile tap in compared to files and sheet results for yourself if you find it interestting


 Kind regards,

 Remco Stoeten

 I'm also on discord if that's quicker 