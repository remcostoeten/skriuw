---
id: "0fd69b26-e9e4-40e6-a881-283920475399"
tags: []
sortOrder: 400
preferredEditorMode: "raw"
createdAt: 1648258611695
modifiedAt: 1648259485428
---
20ml water = 450mg mela = 22,5mg/ml
10ml = 225 = 11.25 mg/ml
20ml water + 10ml pg = 15mg/ml