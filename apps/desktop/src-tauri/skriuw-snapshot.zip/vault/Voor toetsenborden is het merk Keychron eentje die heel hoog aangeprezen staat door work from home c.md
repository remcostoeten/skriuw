---
id: "6a3d2000-ecb8-4833-b068-0a8dbb5580a5"
tags: []
sortOrder: 332
preferredEditorMode: "raw"
createdAt: 1668353552424
modifiedAt: 1668374408501
---
Voor toetsenborden is het merk Keychron eentje die heel hoog aangeprezen staat door work from home communitys. Elke uit dit lijstje is prima, gewoon kijken welke layout je wilt (wel of geen numpad bijvoorbeeld), eventueel ff op youtube review kijken https://tweakers.net/toetsenborden/keychron/.Veel wireless en mac opties. Zolang het maar niet een apple toetsenbord is of een laptop, dat is rsi in <5 jaar.

Qua muizen is dit de #1 sold  van amazon en in die community ook populair, heb hem zelf ook voor werk enn is geniaal hoe smooth enn lekker hij in de hand ligt. https://tweakers.net/muizen/logitech/mx-master-3s_p1384466/vergelijken/ 

Ik heb zelf een anderhalfjaar terug deze stoel gekocht (T2) https://www.alternate.nl/Corsair/Gamestoelen . Een "gamestoel" maar Prima reviews en is nu alsnog een van mn beste aankopen voor thuisoffice imo. En als je g4p money hebt dan kan je kijken naar een Herman Miller stoel, zouden de GOAT moeten zijnn maar bizar duur.

En een zit-sta bureau is ook nice, krijg er zelf eentje binnekort, is wel een investering uiteraard maar met een motortje je hele bureau omhoog liften is nice
