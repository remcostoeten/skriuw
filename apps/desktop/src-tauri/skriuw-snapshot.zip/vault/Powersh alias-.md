---
id: "047c1d94-a7af-49c1-8016-300c98b4553c"
tags: []
sortOrder: 337
preferredEditorMode: "raw"
createdAt: 1667298583462
modifiedAt: 1667301461076
---
Powersh alias:
Originee : nieuwe (eigen)
ni filename.txt - touch  filename.txt

Export-Alias -Path D:\PS\Alias.txt
Import-Alias -Path D:\PS\Alias.txt -Force

Alias worden opgeslagen in $Profile. Code $Profile om te openen in VSC. Notepad $profile kan o

Alias aanmaken om naar directory tegaan.
$profile (gaat naar de alias)
function sites { cd "C:\Users\Remco\sites" }  


Alias aan maken:
set-alias -name AliasNaamn -value OrigienelNaam



set-alias -name touch -value ni

function sites { cd "C:\Users\Remco\sites"}
function sites { cd "C:\Users\Remco\sites" }