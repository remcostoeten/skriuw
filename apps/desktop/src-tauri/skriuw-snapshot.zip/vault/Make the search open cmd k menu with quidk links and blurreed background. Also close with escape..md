---
id: "b0d43cdaa9544ab3b6eced034b27cea6"
tags: []
sortOrder: 214
preferredEditorMode: "block"
createdAt: 1725590454368
modifiedAt: 1725590458514
---
Make the search open cmd k menu with quidk links and blurreed background. Also close with escape.

Make the right icons have tooltips for their label.

The most right icon is a drop-down which if clicked shows a user menu with my name, username, settings, theme switcher and logout.
 I use Lucia auth.

This is the users.ts


And users.tsx

Please try to leverage SSR and ISR with html loaders and great performance. On mobile make it a offcanvas menu.