---
id: "3b5e0fb4-c981-4796-b0d4-f76a10756dfa"
tags: []
sortOrder: 380
preferredEditorMode: "raw"
createdAt: 1656958255630
modifiedAt: 1656958258244
---
csgo launch options
-novid -tickrate 128 +fps max 0 +cl_showfps 1 -high -refresh 120 +cl_forcepreload 1 -nojoy  –r_emulate_gl