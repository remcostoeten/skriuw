---
id: "fbbda026-30e6-44c8-a612-b93faeb3174c"
tags: []
sortOrder: 311
preferredEditorMode: "raw"
createdAt: 1669203506580
modifiedAt: 1676775848387
---
Misschien is het verstandig om binnenkort even meeting te houden met de betrokennen of we mijn design stapsgewijs live willen zetten, of alles in een keer wanneer het af is. Meeste is echt vanaf 0 weer opnieuw opgebouwd dus 

Al mijn design werk van afgelopen maanden staat nog los van de live code, misschien is het verstandig om binnenkort even een meeting te organiseren om te kijken of we mijn design stapsgewijs live willen zetten (als pim af is?), of pas als ik alles helemaal af heb. In principe is de hele frontend vanaf 0 opnieuw opgebouwd dus het is wel de zaak dat er tegen die tijd echt goed getest moet worden

Zaterdag gewoon wat simpels eten, snack of pizza ofzo? M'n vader is eerst werken tot 16:00 ofzo en daarna gaat hij naar m'n oom direct dusd ie is w eg de hele dag

n Weet trouwens niet waar je zo'n bruisbal koopt dus maybe kan jij dat fixen? Of ff kijken waar op internet, fix ik wel glijmiddel  Weet niet waar je zo'n bruisbal haalt voor in bad dus maybe dat jij dat kan fixen, of ff kijken waar te bestellenq