---
id: "42dbe7a3-8693-4942-8c90-dd50492b6bfc"
tags: []
sortOrder: 248
preferredEditorMode: "raw"
createdAt: 1696433082433
modifiedAt: 1696433084491
---
<main id="start-of-content" class="shows-research__button">
        <div class="container">
            
            

            
    <article class="single-article">
        <!--
  Show the header of the page, which are the optional breadcrumbs and the title
-->
<header class="content-header ">
    <ol class="breadcrumb"><li class="breadcrumb__item"><a href="/">Home</a></li><li class="breadcrumb__item"><a href="/ik-en-de-fsv/">Ik en de FSV</a></li><li class="breadcrumb__item"></li></ol><ol class="breadcrumb breadcrumb--mobile"><li class="breadcrumb__item breadcrumb__item--mobile"><a href="/ik-en-de-fsv/">Terug naar "Ik en de FSV"</a></li></ol>

    <h1>Uw persoonlijke omgeving</h1>
</header>


        <div class="article-container single-article__content basic-page custom-layout">
        
            <div class="block-group">
    
        

<div id="personal-preferences" class="personal-preferences" data-django-csrf-token="eYrbROB4qeD0EZcEbsXaFrjHZStRwYsy2HAQ79kKdfHYKZyuuxUBDlvA73xMhFNh" data-user-id="d470173f-6acd-4ac2-8fe5-94dafa68b14a" data-public-key="-----BEGIN PGP PUBLIC KEY BLOCK-----

xjMEY/2+8BYJKwYBBAHaRw8BAQdAP5sMr1iDoIpVRBb4cYj4pcoPhT81OQKJ
q24BuwlNryTND0JlbGFzdGluZ2RpZW5zdMKMBBAWCgA+BQJj/b7wBAsJBwgJ
EGRPL6AWGM8KAxUICgQWAAIBAhkBAhsDAh4BFiEE8Nx5AZsI9uO1umknZE8v
oBYYzwoAACKiAP4rj8+W+pSvEMnVmGZWJg7q50lA2fyKMvSO4g1084akdAEA
uw7/qXEf8iMnmXwAqWD2N9jgTKgBnxlKmB+i1Ns8SAvOOARj/b7wEgorBgEE
AZdVAQUBAQdAi5WgMf9G19JFK4U9zQTkxDk0XUrL5fZoOXajvntAQ1UDAQgH
wngEGBYIACoFAmP9vvAJEGRPL6AWGM8KAhsMFiEE8Nx5AZsI9uO1umknZE8v
oBYYzwoAAI3JAP0buH99ViYi8Winz2ahSnTdUOEffNt15oes2mxWatArnAEA
q1bgxLDtq5yjLQcARBG17hBeRtTChFST6k3zCrDCtwQ=
=q3QB
-----END PGP PUBLIC KEY BLOCK-----" data-external-id="070550657">
    <div class="form">
        <h2>Melding van deling FSV-registratie</h2>
        
        <p data-block-key="dhpy5">Vermoedt u dat uw FSV-registratie is gedeeld met een andere organisatie binnen de overheid? En wilt u dat aan ons melden? Dan kunt u hieronder uw telefoonnummer aan ons doorgeven. Een medewerker van de Belastingdienst neemt dan telefonisch contact met u op. U kunt ook zelf een afspraak maken.</p>

        <form name="personal_preferences_form">
            <div>
                <div class="phone-row">
                    <div class="phone-label">
                        <label for="input-phone">Telefoonnummer:</label>
                    </div>
                    <div class="phone-input">
                        <input class="input" type="tel" name="phone" maxlength="24" minlength="24" placeholder="0612345678" id="input-phone">
                    </div>
               </div>
            </div>

            <div class="consent-section">
                <label>
                    <input type="checkbox" name="consent" value="yes" id="input-consent">
                    <span class="caption">
                        <small>
                            Ik ga akkoord met het verwerken van mijn gegevens door de Belastingdienst.
                        </small>
                    </span>
                </label>
            </div>

            <p>
                <small>
                    <a href="https://fsvportaal.belastingdienst.nl/het-programma/" rel="noopener noreferrer" target="_blank">Lees meer
                        over hoe de Belastingdienst omgaat met privacy en persoonsgegevens.</a>
                </small>
            </p>

            <div class="error-message" data-message-enter-phone-number="Voer uw telefoonnummer in." data-data-message-no-letters="Voer a.u.b. alleen nummers in, letters zijn niet toegestaan." data-message-no-consent="Om verder te kunnen gaan hebben wij uw akkoord nodig om uw gegevens te kunnen verwerken." data-message-could-not-encrypt-data="Kon de gegevens niet versleutelen." data-message-could-not-process-data="De server kon de versleutelde gegevens niet verwerken." data-message-could-not-send-data="Kon de versleutelde data niet versturen." data-message-no-public-key="Geen public key beschikbaar." data-message-error-importing-openpgpjs="De PGP-module kon niet worden geladen." style="display: none;"></div>

            <button type="submit" data-track-content="" data-content-name="melding_doorgeven" id="submit-button" class="submit-button button" disabled="">Verstuur</button>
        </form>
        
    </div>

    <div class="success">
        <h3 data-block-key="lhlq9">Bedankt voor het doorgeven van uw melding.</h3><p data-block-key="zmo3b">Wij hebben uw melding ‘Deling FSV-registratie’ ontvangen. Binnenkort nemen wij telefonisch contact met u op.</p><p data-block-key="wxxwa"></p><p data-block-key="lrmj0">Wilt u liever zelf een afspraak maken? Dat kan <a href="https://fsvportaal.belastingdienst.nl/online-afspraken/">hier</a>.</p><p data-block-key="f44vq">Wilt u toch op een ander nummer gebeld worden dan u heeft opgegeven? Dan kunt u ons gratis bellen op 0800 235 83 56. We zijn bereikbaar van maandag tot en met vrijdag, tussen 8.00 en 17.00 uur.</p><h3 data-block-key="urb5k">Persoonlijk overzicht</h3><p data-block-key="jdjnv">U kunt de behandeling van uw melding volgen via uw persoonlijk overzicht op het FSV Portaal. Uw persoonlijk overzicht kunt u <a href="https://fsvportaal.belastingdienst.nl/ik-en-de-fsv/uw-persoonlijke-omgeving/#form-personal-timeline-fieldset">hier</a> aanvragen.</p><h3 data-block-key="imtas">Extra formulier inzageverzoek</h3><p data-block-key="p80i9">In het telefoongesprek vertellen wij u dat u een inzageverzoek kunt doen bij de organisatie waarvan u vermoedt dat deze informatie over uw FSV-registratie heeft. U krijgt daarvoor een formulier per post thuisgestuurd. Wilt u een inzageverzoek doen bij meerdere organisaties? Dan kunt u een <a href="https://fsvportaal.belastingdienst.nl/documents/66/Aanvraagformulier_Melding_gegevensdeling_FSV-registratie.pdf">extra formulier hier downloaden</a>. In het document vindt u ook een uitleg hoe u het formulier kunt invullen.</p><p data-block-key="hgfra">Kijk voor meer informatie in het artikel <a href="https://fsvportaal.belastingdienst.nl/nieuws/wat-gebeurt-er-nadat-u-een-melding-deling-fsv-registratie-heeft-gedaan/">‘Wat gebeurt er nadat u een melding ‘Deling FSV-registratie’ heeft gedaan?’</a></p>
    </div>
</div>


    
        

<div id="encrypted-files-page" class="encrypted-files-page block-group" data-django-csrf-token="eYrbROB4qeD0EZcEbsXaFrjHZStRwYsy2HAQ79kKdfHYKZyuuxUBDlvA73xMhFNh" data-endpoint-user-encrypted-file="/encryption/api/v1/user-encrypted-file/" data-user-public-key="-----BEGIN PGP PUBLIC KEY BLOCK-----

xjMEZP69HBYJKwYBBAHaRw8BAQdAb8MBadDV9G6h5FdpAoig+NQTMLaVv2lO
uKdFyFl+zljNAMKMBBAWCgA+BQJk/r0cBAsJBwgJEBmZ4HvvaEWGAxUICgQW
AAIBAhkBAhsDAh4BFiEELpn4ZRfjwBgAZPxmGZnge+9oRYYAAOVnAQDUtW+v
xJEUxabTynZBJtecR7SgmKwcreVPWz2C2GDdWAD/aKvRl7jD7fdTX/9WpYtf
+OGHdzIWqa4jhkr2KeP5kgbOOARk/r0cEgorBgEEAZdVAQUBAQdAe6xIKycq
EAJb7zExTRiHQqMXfz/J7BditZ39laOeMGUDAQgHwngEGBYIACoFAmT+vRwJ
EBmZ4HvvaEWGAhsMFiEELpn4ZRfjwBgAZPxmGZnge+9oRYYAALWdAQDoMbHv
4afUrQUW4WsYE2kL8KMafyBMAB+YKS9Z2e92MQEA9umeyOc7lxyT6pWiVN0K
ae2zK7q237h74ERC45JD5Q0=
=oJR0
-----END PGP PUBLIC KEY BLOCK-----" data-user-private-key="-----BEGIN PGP PRIVATE KEY BLOCK-----

xYYEZP69HBYJKwYBBAHaRw8BAQdAb8MBadDV9G6h5FdpAoig+NQTMLaVv2lO
uKdFyFl+zlj+CQMIdsmBjPmDAULgyrsWVch6rApHq6OhxESQjJmmRP7TjPAf
uph/H2bP/oU+MLQw+Xdl9ulXdiYEHPWhfsRQLxdovoDmEGxk31nWWJtk7v7w
ds0AwowEEBYKAD4FAmT+vRwECwkHCAkQGZnge+9oRYYDFQgKBBYAAgECGQEC
GwMCHgEWIQQumfhlF+PAGABk/GYZmeB772hFhgAA5WcBANS1b6/EkRTFptPK
dkEm15xHtKCYrByt5U9bPYLYYN1YAP9oq9GXuMPt91Nf/1ali1/44Yd3Mhap
riOGSvYp4/mSBseLBGT+vRwSCisGAQQBl1UBBQEBB0B7rEgrJyoQAlvvMTFN
GIdCoxd/P8nsF2K1nf2Vo54wZQMBCAf+CQMI5JD3KKi4qc3gR5gzr+EDFnmY
VecqGAImkK/y5abLjwQJynTc12BCdkyOX1JsPcVmbfVjjI9hu4JYmQlxHW26
UdP3bi+r3MwgkYqp3gJWi8J4BBgWCAAqBQJk/r0cCRAZmeB772hFhgIbDBYh
BC6Z+GUX48AYAGT8ZhmZ4HvvaEWGAAC1nQEA6DGx7+Gn1K0FFuFrGBNpC/Cj
Gn8gTAAfmCkvWdnvdjEBAPbpnsjnO5cck+qVolTdCmntsyu6tt+4e+BEQuOS
Q+UN
=MAfV
-----END PGP PRIVATE KEY BLOCK-----" data-bd-public-key="-----BEGIN PGP PUBLIC KEY BLOCK-----

xjMEY/2+8BYJKwYBBAHaRw8BAQdAP5sMr1iDoIpVRBb4cYj4pcoPhT81OQKJ
q24BuwlNryTND0JlbGFzdGluZ2RpZW5zdMKMBBAWCgA+BQJj/b7wBAsJBwgJ
EGRPL6AWGM8KAxUICgQWAAIBAhkBAhsDAh4BFiEE8Nx5AZsI9uO1umknZE8v
oBYYzwoAACKiAP4rj8+W+pSvEMnVmGZWJg7q50lA2fyKMvSO4g1084akdAEA
uw7/qXEf8iMnmXwAqWD2N9jgTKgBnxlKmB+i1Ns8SAvOOARj/b7wEgorBgEE
AZdVAQUBAQdAi5WgMf9G19JFK4U9zQTkxDk0XUrL5fZoOXajvntAQ1UDAQgH
wngEGBYIACoFAmP9vvAJEGRPL6AWGM8KAhsMFiEE8Nx5AZsI9uO1umknZE8v
oBYYzwoAAI3JAP0buH99ViYi8Winz2ahSnTdUOEffNt15oes2mxWatArnAEA
q1bgxLDtq5yjLQcARBG17hBeRtTChFST6k3zCrDCtwQ=
=q3QB
-----END PGP PUBLIC KEY BLOCK-----" data-max-file-size="104857600" data-max-uploads="10">
    
        <div id="pane-upload" class="pane-upload mt-1">
            <h2>Inzageverzoek(en) uploaden</h2>
            <p>Upload hier de bestanden die u van de externe organisatie heeft ontvangen. U kunt meerdere bestanden uploaden.</p>
            
            <div class="upload">
                <div class="dropzone">
                    <div class="icon">
                        <img src="/static/img/icons/upload.svg" alt="">
                    </div>
                    <div class="text">
                        <strong>
                            Sleep hier uw bestand naartoe<br>
                            of
                        </strong>
                    </div>
                    <form>
                        <input type="file" multiple="" id="encrypt-file-input-file" accept="application/pdf,.pdf" onclick="this.value = null" style="pointer-events: auto;">
                        <button type="button" id="button-select-file" class="button-select-file button secondary">Kies bestand(en)</button>
                    </form>
                </div>
                <div class="dropzone-footer">
                    <div>Ondersteunde bestanden: pdf</div>
                    <div>Maximaal <span class="max-file-size">100 MB</span> per bestand</div>
                </div>

                <div id="error-messages" class="error-messages">
                    <div id="error-message-template" class="error-message" hidden="">
                        <div class="icon">
                            <img src="/static/img/icons/error.svg" alt="">
                        </div>
                        <div class="content-container">
                            <h3 class="title" data-title-default="Er ging iets mis..." data-title-file-size-too-large="Uw bestand is te groot" data-title-no-pdf-extension="Uw bestand is geen pdf" data-title-no-pdf-magic-number="Uw bestand is geen pdf"></h3>
                            <div class="message" data-message-file-size-too-large="U kunt bestanden van maximaal %1% uploaden." data-message-no-pdf-extension="Het is alleen toegestaan om pdf-documenten te uploaden." data-message-no-pdf-magic-number="Het is alleen toegestaan om pdf-documenten te uploaden." data-message-could-not-read-file="Uw bestand kon niet worden ingelezen." data-message-error-importing-openpgpjs="De PGP-module kon niet worden geladen." data-message-file-already-added="Dit bestand is al toegevoegd om te uploaden"></div>
                        </div>
                        <!-- <div class="close"><button class="button-close-error-message">[ X ]</button></div> -->
                    </div>
                </div>

                <div id="selected-files" class="selected-files">
                    <div id="selected-file-template" class="selected-file" hidden="">
                        <div class="icon">
                            <img src="/static/img/icons/file.svg" alt="" style="width: 24px">
                        </div>
                        <div class="file-container">
                            <div class="filename"></div>
                            <div class="file-size"></div>
                            <div class="file-status status-bar default" data-message-encrypting="Versleutelen..." data-message-uploading="Uploaden..."></div>
                        </div>
                        <div class="close">
                            <button class="button-reset">
                                <img src="/static/img/icons/delete-blue.svg" alt="" style="width: 18px">
                            </button>
                        </div>
                        <!-- <div class="spinner" hidden>
                            <img src="/static/img/spinner.svg" alt="" />
                        </div> -->
                        <div class="result-success" hidden=""></div>
                        <div class="result-failure" hidden=""></div>
                    </div></div>

                <div class="button-list">
                    <button type="button" id="button-submit-upload" class="button-submit-upload button" disabled="">Verstuur</button>
                </div>
            </div>
            <div class="success" hidden="">
                <div class="layout">
                    <div class="icon"></div>
                    <div class="content-container">
                        <h3 class="title">Uw bestanden zijn succesvol verstuurd naar ons</h3>
                        <div class="message">Wij hebben uw bestanden succesvol ontvangen en nemen zo spoedig mogelijk contact met u op.</div>
                    </div>
                </div>

                <div class="button-list">
                    <button type="button" id="button-view-files" class="button-view-files button secondary">Bekijk bestanden</button>
                    <button type="button" id="button-close" class="button-close button">Sluit af</button>
                </div>
            </div>
            <div class="failure" hidden="">
                <div class="layout">
                    <div class="icon"></div>
                    <div class="content-container">
                        <h3 class="title">Er is iets fout gegaan</h3>
                        <div class="message">Niet alle bestanden zijn succesvol geüpload, probeer het opnieuw.</div>
                    </div>
                </div>
            </div>
        </div>

        <div id="modal-encrypted-file-delete-confirm" class="modal-dialog-wrapper" hidden="">
            <div class="modal-dialog" role="alertdialog" aria-modal="true" aria-labelledby="modal-encrypted-file-delete-confirm-title" aria-describedby="modal-encrypted-file-delete-confirm-description">

                <h2 id="modal-encrypted-file-delete-confirm-title">Bestand verwijderen?</h2>
                <div id="modal-encrypted-file-delete-confirm-description">
                    <p>Weet u zeker dat u dit bestand ("<span class="filename"></span>") wilt verwijderen?</p>
                </div>

                <button id="modal-encrypted-file-delete-confirm-cancel" type="button" class="button secondary">Annuleren</button>
                <button id="modal-encrypted-file-delete-confirm-delete" type="button" class="button">Verwijderen</button>
            </div>
        </div>        

        <div id="modal-encrypted-file-error-message" class="modal-dialog-wrapper" hidden="">
            <div class="modal-dialog" role="alertdialog" aria-modal="true" aria-labelledby="modal-encrypted-file-error-message-title" aria-describedby="modal-encrypted-file-error-message-description">

                <h2 id="modal-encrypted-file-error-message-title">Er is iets fout gegaan...</h2>
                <div id="modal-encrypted-file-error-message-description" data-message-incorrect-passphrase="Incorrect wachtwoord" data-message-error-importing-openpgpjs="De PGP-module kon niet worden geladen." data-message-error-downloading-encrypted-file="Het downloaden van het versleutelde bestand is niet gelukt." data-message-error-no-passphrase-available="Uw wachtwoord is niet langer bekend. Voer a.u.b. uw wachtwoord opnieuw in." data-message-default-error="Er ging iets fout. Probeer het nogmaals."></div>

                <div class="button-list mt-1">
                    <button id="modal-encrypted-file-passphrase-close" type="button" class="button">Sluiten</button>
                </div>
            </div>
        </div>        

        <div class="table-overflow-wrapper table-overflows">
            <div class="table-container">
                    <table class="table">
                    <colgroup>
                        <col class="large">
                        <col class="medium">
                        <col class="medium">
                        <col class="small">
                    </colgroup>
                    
                    <thead>
                        <tr>
                            <th>Bestandsnaam</th>
                            <th>Afzender</th>
                            <th>Datum</th>
                            <th>
                                <span class="hide-visually">Schakelmenu's</span>
                            </th>
                        </tr>
                    </thead>
                    
                    <tbody>
                        
                    <tr id="767cfbd3-a55b-4fe1-b9be-dbf0f7291c7f">
                        <td class="document">Intakeformulier-stichtingenverenigingen.pdf</td>
                        <td class="user">Uzelf</td>
                        <!-- <td>130,5&nbsp;KB</td> -->
                        <!-- <td><button class="encrypted-file-download" data-file-id="767cfbd3-a55b-4fe1-b9be-dbf0f7291c7f" data-filename="Intakeformulier-stichtingenverenigingen.pdf" data-file-size="133653">download</button></td> -->
                        <td>28 september 2023</td>
                        <td>
                            <details class="kebab">
                                <summary>
                                    <span class="hide-visually">Schakel menu</span>
                                </summary>
                                <div class="kebab-menu">
                                    <ul>
                                        <li class="icon download">
                                            <button class="encrypted-file-download" data-file-id="767cfbd3-a55b-4fe1-b9be-dbf0f7291c7f" data-filename="Intakeformulier-stichtingenverenigingen.pdf" data-file-size="133653">Downloaden</button>
                                        </li>
                                        <li class="icon delete">
                                            <button class="encrypted-file-delete" data-file-id="767cfbd3-a55b-4fe1-b9be-dbf0f7291c7f" data-filename="Intakeformulier-stichtingenverenigingen.pdf">Verwijderen</button></li></ul></div></details></td>
                                        
                                    
                                
                            
                        
                    </tr>
                    
                    <tr id="7d4bf549-c9e7-450c-8d33-b92ee59be196">
                        <td class="document">2023-06-09 Conversion rate-1.pdf</td>
                        <td class="user">Uzelf</td>
                        <!-- <td>29,7&nbsp;KB</td> -->
                        <!-- <td><button class="encrypted-file-download" data-file-id="7d4bf549-c9e7-450c-8d33-b92ee59be196" data-filename="2023-06-09 Conversion rate-1.pdf" data-file-size="30450">download</button></td> -->
                        <td>18 september 2023</td>
                        <td>
                            <details class="kebab">
                                <summary>
                                    <span class="hide-visually">Schakel menu</span>
                                </summary>
                                <div class="kebab-menu">
                                    <ul>
                                        <li class="icon download">
                                            <button class="encrypted-file-download" data-file-id="7d4bf549-c9e7-450c-8d33-b92ee59be196" data-filename="2023-06-09 Conversion rate-1.pdf" data-file-size="30450">Downloaden</button>
                                        </li>
                                        <li class="icon delete">
                                            <button class="encrypted-file-delete" data-file-id="7d4bf549-c9e7-450c-8d33-b92ee59be196" data-filename="2023-06-09 Conversion rate-1.pdf">Verwijderen</button></li></ul></div></details></td>
                                        
                                    
                                
                            
                        
                    </tr>
                    
                    <tr id="d22b144a-01a8-49c5-9059-f2e7477e8fc6">
                        <td class="document">testfile.test</td>
                        <td class="user">Uzelf</td>
                        <!-- <td>121,2&nbsp;KB</td> -->
                        <!-- <td><button class="encrypted-file-download" data-file-id="d22b144a-01a8-49c5-9059-f2e7477e8fc6" data-filename="testfile.test" data-file-size="124142">download</button></td> -->
                        <td>11 september 2023</td>
                        <td>
                            <details class="kebab">
                                <summary>
                                    <span class="hide-visually">Schakel menu</span>
                                </summary>
                                <div class="kebab-menu">
                                    <ul>
                                        <li class="icon download">
                                            <button class="encrypted-file-download" data-file-id="d22b144a-01a8-49c5-9059-f2e7477e8fc6" data-filename="testfile.test" data-file-size="124142">Downloaden</button>
                                        </li>
                                        <li class="icon delete">
                                            <button class="encrypted-file-delete" data-file-id="d22b144a-01a8-49c5-9059-f2e7477e8fc6" data-filename="testfile.test">Verwijderen</button></li></ul></div></details></td>
                                        
                                    
                                
                            
                        
                    </tr>
                    
                </tbody>
            </table>
            </div>
        </div>

    
</div>

    
        


<div class="form-container--appointment">
    <!-- start form -->
    <form class="form__appointment" id="form__appointment" novalidate="">
        
        <h2>titel</h2>
        
        <input type="hidden" name="csrfmiddlewaretoken" value="eYrbROB4qeD0EZcEbsXaFrjHZStRwYsy2HAQ79kKdfHYKZyuuxUBDlvA73xMhFNh">

        <fieldset class="appointment-form-section-date-time" id="appointment-form-section-date-time">
            
            <p>omschrijving</p>
            
            <h3>Maak een keus</h3>
            <div class="contact__dropdown-menu formfield-container formfield-container--select" id="appointment_type__select_container" preselected="523578" style="display: none;">
                <label for="appointment_type">
                    Soort gesprek
                    <span class="appointment-date-spinner" id="appointment-appointment_type-spinner" aria-hidden="true" hidden="">
                        <img alt="" width="18" height="18" src="/static/img/spinner-blue.svg">
                    </span>    
                </label>
                <select name="appointment_type" id="appointment_type" required="">
                    <option value="" selected="" disabled="">Maak een keuze</option>
                <option value="438279">Videobelgesprek over de FSV</option><option value="523554">Telefoongesprek over mijn verzoek om schadevergoeding</option><option value="523578">Telefoongesprek over mijn melding van deling FSV-registratie</option></select>
            </div>
            <div class="error" id="error-appointment_type" aria-live="polite" hidden="">Kies een soort gesprek</div>

            <div id="appointment_subject__select_container" style="display: none;">
                <label for="subject">
                    Onderwerp
                    <span class="appointment-subject-spinner" id="appointment-subject-spinner" aria-hidden="true" hidden="">
                        <img alt="" width="18" height="18" src="/static/img/spinner-blue.svg">
                    </span>
                </label>
                <div class="formfield-container--wrapper">
                    <div class="formfield-container formfield-container--select">
                        <select name="subject" id="subject" required="">
                            <option value="" selected="" disabled="" style="display: none;">---</option>
                            <option style="display: none;">De FSV</option>
                            <option style="display: none;">Mijn onderzoeksresultaten</option>
                            <option style="display: none;">Een ontvangen brief</option>
                            <option style="display: none;">Een inzageverzoek of melding</option>
                            <option style="display: none;">Het FSV Portaal</option>
                            <option style="display: none;">Overige</option>
                            <option style="display: none;">Mijn verzoek om schadevergoeding</option>
                            <option style="display: block;">Mijn melding van deling FSV-registratie</option>
                        </select>
                    </div>
                </div>
                <div class="error" id="error-subject" aria-live="polite" hidden="">Selecteer een onderwerp</div>
            </div>

            <label for="date">
                Kies een datum
                <span class="appointment-date-spinner" id="appointment-date-spinner" aria-hidden="true" hidden="">
                    <img alt="" width="18" height="18" src="/static/img/spinner-blue.svg">
                </span>
            </label>
            <div class="formfield-container--wrapper">
                <div class="formfield-container formfield-container--select">                    
                    <select name="date" id="date" required="">
                        <option value="" selected="" disabled="">Datum</option>
                    <option value="2023-10-05">donderdag 5 oktober 2023</option><option value="2023-10-06">vrijdag 6 oktober 2023</option><option value="2023-10-09">maandag 9 oktober 2023</option><option value="2023-10-10">dinsdag 10 oktober 2023</option><option value="2023-10-11">woensdag 11 oktober 2023</option><option value="2023-10-12">donderdag 12 oktober 2023</option><option value="2023-10-13">vrijdag 13 oktober 2023</option><option value="2023-10-16">maandag 16 oktober 2023</option><option value="2023-10-17">dinsdag 17 oktober 2023</option><option value="2023-10-18">woensdag 18 oktober 2023</option><option value="2023-10-19">donderdag 19 oktober 2023</option><option value="2023-10-20">vrijdag 20 oktober 2023</option><option value="2023-10-23">maandag 23 oktober 2023</option><option value="2023-10-24">dinsdag 24 oktober 2023</option><option value="2023-10-25">woensdag 25 oktober 2023</option><option value="2023-10-26">donderdag 26 oktober 2023</option><option value="2023-10-27">vrijdag 27 oktober 2023</option><option value="2023-10-30">maandag 30 oktober 2023</option><option value="2023-10-31">dinsdag 31 oktober 2023</option><option value="2023-11-01">woensdag 1 november 2023</option><option value="2023-11-02">donderdag 2 november 2023</option><option value="2023-11-03">vrijdag 3 november 2023</option></select>
                </div>
            </div>
            <div class="error" id="error-date" aria-live="polite" hidden="">Selecteer een datum</div>

            <label for="start_time">Kies een tijd</label>
            <div class="formfield-container--wrapper">
                <div class="formfield-container formfield-container--select">
                    <select name="start_time" id="start_time" required="" disabled="">
                        <option value="" selected="" disabled="">Tijd</option>
                    </select>
                    <span class="error" aria-live="polite"></span>
                </div>
            </div>
            <div class="error" id="error-start_time" aria-live="polite" hidden="">Selecteer een tijd</div>

            <button type="button" class="button button-primary" id="appointment-form-button-next">Verder</button>
        </fieldset>

        <fieldset class="appointment-form-section-personal-info" id="appointment-form-section-personal-info" hidden="">
            
            <p>lkjkjlk</p>
            

            <h3>Vul uw contactgegevens in</h3>
            <div class="formfield-container--wrapper">
                <div class="formfield-container">
                    <label for="first_name">Voornaam</label>
                    <input type="text" name="first_name" id="first_name" required="" maxlength="64">
                    <span class="error" id="error-first_name" aria-live="polite" hidden="">Vul voornaam in</span>
                </div>
                <div class="formfield-container">
                    <label for="last_name">Achternaam</label>
                    <input type="text" name="last_name" id="last_name" required="" maxlength="64">
                    <span class="error" id="error-last_name" aria-live="polite" hidden="">Vul achternaam in</span>
                </div>
            </div>
            <div class="formfield-container--wrapper">
                <div class="formfield-container">
                    <label for="email">E-mailadres</label>
                    <input type="email" name="email" id="email" required="" maxlength="64">
                    <span class="error" id="error-email" aria-live="polite" hidden="">Vul een geldig e-mailadres in</span>
                </div>
                <div class="formfield-container">
                    <label for="phone">(Mobiel) telefoonnummer</label>
                    <input type="tel" name="phone" id="phone" required="" maxlength="64" pattern="(^\+[0-9]{2}|^\+[0-9]{2}\(0\)|^\(\+[0-9]{2}\)\(0\)|^00[0-9]{2}|^0)([0-9]{9}$|[0-9\-\s]{10}$)">
                    <span class="error" id="error-phone" aria-live="polite" hidden="">Vul een geldig (mobiel) telefoonnummer in</span>
                </div>
            </div>

            <div class="formfield-container">
                <label for="description">
                    Uw bericht
                    <small>(maximaal 256 tekens)</small>
                </label>
                <textarea name="description" id="description" maxlength="256"></textarea>
                <small>0/256</small>
            </div>

           <div class="privacy-statement">
                <hr>

                <p>
                    <input type="checkbox" name="akkoord" value="akkoord" required="" id="privacy-checkbox">
                    <label for="privacy-checkbox"><small>Ik ga akkoord met het verwerken van mijn gegevens door de Belastingdienst</small></label>
                </p>
                <p>
                    <small>
                        <a href="https://fsvportaal.belastingdienst.nl/het-programma/" target="_blank">Lees meer over hoe de Belastingdienst omgaat met privacy en persoonsgegevens</a>
                    </small>
                </p>
            </div>

            <button type="button" class="button" id="appointment-form-button-back">Terug</button>
            <button type="button" class="button button-primary" id="appointment-form-button-send" data-track-content="" data-content-name="afspraak_maken" disabled="">Verzenden</button>

            <input type="hidden" id="source_user_id" name="source_user_id" value="d470173f-6acd-4ac2-8fe5-94dafa68b14a">
        </fieldset>
    </form>
    <!-- end form -->

    <!-- start succes message -->
    <div class="form-message" id="appointment_success" hidden="">
        <h2>Bedankt voor het maken van een afspraak</h2>
        <p>U ontvangt een bevestiging per e-mail.</p>
    </div>
    <!-- end succes message -->

    <!-- start error message -->
    <div class="form-message" id="appointment_error" hidden="">
        <h2>Er is iets misgegaan</h2>
        <p>Er is iets misgegaan. Probeert u het later nog eens.</p>
        <p>Onze excuses voor het ongemak.</p>
    </div>
    <!-- end error message -->
</div>

    
        <h2 id="test-voor-personal-perferences">test voor personal perferences</h2>

    
        

<div id="personal-preferences" class="personal-preferences" data-django-csrf-token="eYrbROB4qeD0EZcEbsXaFrjHZStRwYsy2HAQ79kKdfHYKZyuuxUBDlvA73xMhFNh" data-user-id="d470173f-6acd-4ac2-8fe5-94dafa68b14a" data-public-key="-----BEGIN PGP PUBLIC KEY BLOCK-----

xjMEY/2+8BYJKwYBBAHaRw8BAQdAP5sMr1iDoIpVRBb4cYj4pcoPhT81OQKJ
q24BuwlNryTND0JlbGFzdGluZ2RpZW5zdMKMBBAWCgA+BQJj/b7wBAsJBwgJ
EGRPL6AWGM8KAxUICgQWAAIBAhkBAhsDAh4BFiEE8Nx5AZsI9uO1umknZE8v
oBYYzwoAACKiAP4rj8+W+pSvEMnVmGZWJg7q50lA2fyKMvSO4g1084akdAEA
uw7/qXEf8iMnmXwAqWD2N9jgTKgBnxlKmB+i1Ns8SAvOOARj/b7wEgorBgEE
AZdVAQUBAQdAi5WgMf9G19JFK4U9zQTkxDk0XUrL5fZoOXajvntAQ1UDAQgH
wngEGBYIACoFAmP9vvAJEGRPL6AWGM8KAhsMFiEE8Nx5AZsI9uO1umknZE8v
oBYYzwoAAI3JAP0buH99ViYi8Winz2ahSnTdUOEffNt15oes2mxWatArnAEA
q1bgxLDtq5yjLQcARBG17hBeRtTChFST6k3zCrDCtwQ=
=q3QB
-----END PGP PUBLIC KEY BLOCK-----" data-external-id="070550657">
    <div class="form">
        <h2>Melding van deling FSV-registratie</h2>
        
        <p data-block-key="vbk80">Vermoedt u dat uw FSV-registratie is gedeeld met een andere organisatie binnen de overheid? En wilt u dat aan ons melden? Dan kunt u hieronder uw telefoonnummer aan ons doorgeven. Een medewerker van de Belastingdienst neemt dan telefonisch contact met u op. U kunt ook zelf een afspraak maken.</p>

        <form name="personal_preferences_form">
            <div>
                <div class="phone-row">
                    <div class="phone-label">
                        <label for="input-phone">Telefoonnummer:</label>
                    </div>
                    <div class="phone-input">
                        <input class="input" type="tel" name="phone" maxlength="24" minlength="24" placeholder="0612345678" id="input-phone">
                    </div>
               </div>
            </div>

            <div class="consent-section">
                <label>
                    <input type="checkbox" name="consent" value="yes" id="input-consent">
                    <span class="caption">
                        <small>
                            Ik ga akkoord met het verwerken van mijn gegevens door de Belastingdienst.
                        </small>
                    </span>
                </label>
            </div>

            <p>
                <small>
                    <a href="https://fsvportaal.belastingdienst.nl/het-programma/" rel="noopener noreferrer" target="_blank">Lees meer
                        over hoe de Belastingdienst omgaat met privacy en persoonsgegevens.</a>
                </small>
            </p>

            <div class="error-message" aria-live="polite" data-message-enter-phone-number="Voer uw telefoonnummer in." data-data-message-no-letters="Voer a.u.b. alleen nummers in, letters zijn niet toegestaan." data-message-no-consent="Om verder te kunnen gaan hebben wij uw akkoord nodig om uw gegevens te kunnen verwerken." data-message-could-not-encrypt-data="Kon de gegevens niet versleutelen." data-message-could-not-process-data="De server kon de versleutelde gegevens niet verwerken." data-message-could-not-send-data="Kon de versleutelde data niet versturen." data-message-no-public-key="Geen public key beschikbaar." data-message-error-importing-openpgpjs="De PGP-module kon niet worden geladen."></div>

            <button type="submit" data-track-content="" data-content-name="melding_doorgeven" id="submit-button" class="submit-button button" disabled="">Verstuur</button>
        </form>
        
    </div>

    <div class="success">
        <h3 data-block-key="9qdph">Bedankt voor het doorgeven van uw melding.</h3><p data-block-key="8ozra">Wij hebben uw melding ‘Deling FSV-registratie’ ontvangen. Binnenkort nemen wij telefonisch contact met u op.</p><p data-block-key="py4tg"></p><p data-block-key="vxmt9">Wilt u liever zelf een afspraak maken? Dat kan <a href="https://fsvportaal.belastingdienst.nl/online-afspraken/">hier</a>.</p><p data-block-key="6b4jr">Wilt u toch op een ander nummer gebeld worden dan u heeft opgegeven? Dan kunt u ons gratis bellen op 0800 235 83 56. We zijn bereikbaar van maandag tot en met vrijdag, tussen 8.00 en 17.00 uur.</p><h3 data-block-key="g1q7f">Persoonlijk overzicht</h3><p data-block-key="i6v86">U kunt de behandeling van uw melding volgen via uw persoonlijk overzicht op het FSV Portaal. Uw persoonlijk overzicht kunt u <a href="https://fsvportaal.belastingdienst.nl/ik-en-de-fsv/uw-persoonlijke-omgeving/#form-personal-timeline-fieldset">hier</a> aanvragen.</p><h3 data-block-key="ivwyv">Extra formulier inzageverzoek</h3><p data-block-key="a6umk">In het telefoongesprek vertellen wij u dat u een inzageverzoek kunt doen bij de organisatie waarvan u vermoedt dat deze informatie over uw FSV-registratie heeft. U krijgt daarvoor een formulier per post thuisgestuurd. Wilt u een inzageverzoek doen bij meerdere organisaties? Dan kunt u een <a href="https://fsvportaal.belastingdienst.nl/documents/66/Aanvraagformulier_Melding_gegevensdeling_FSV-registratie.pdf">extra formulier hier downloaden</a>. In het document vindt u ook een uitleg hoe u het formulier kunt invullen.</p><p data-block-key="qurxr">Kijk voor meer informatie in het artikel <a href="https://fsvportaal.belastingdienst.nl/nieuws/wat-gebeurt-er-nadat-u-een-melding-deling-fsv-registratie-heeft-gedaan/">‘Wat gebeurt er nadat u een melding ‘Deling FSV-registratie’ heeft gedaan?’</a></p>
    </div>
</div>


    
</div>

        
            <div class="block-group">
    
        <h2 id="uw-persoonsgegevens-stonden-in-de-fraude-signalering-voorziening-fsv-van-de-belastingdienst-dat-spijt-ons">Uw persoonsgegevens stonden in de Fraude Signalering Voorziening (FSV) van de Belastingdienst. Dat spijt ons.</h2>

    
        <div class="paragraph"><p data-block-key="nmijh">We onderzoeken welke gevolgen uw FSV-registratie heeft gehad bij de Belastingdienst. U wordt of bent al geïnformeerd als dit onderzoek is afgesloten. U hoeft daar niets voor te doen.</p></div>

    
</div>

        
            <div class="paragraph"><p data-block-key="g9wqm">Heeft u een brief gekregen over uw FSV-registratie? En wilt u hierover in gesprek met een medewerker van de Belastingdienst? Dan kunt u de chatfunctie op deze pagina gebruiken.</p></div>

        
            
<!-- The main purpose of this template is to render one of the UI components corresponding to the stage in which the personal data request for the user is. -->

<script id="logged_in_user_id" type="application/json">"d470173f-6acd-4ac2-8fe5-94dafa68b14a"</script>

<form class="fsv-form block-group personal-timeline" id="form-personal-timeline">
    <div id="personal-timeline-data" data-private-key="-----BEGIN PGP PRIVATE KEY BLOCK-----

xYYEZP69HBYJKwYBBAHaRw8BAQdAb8MBadDV9G6h5FdpAoig+NQTMLaVv2lO
uKdFyFl+zlj+CQMIdsmBjPmDAULgyrsWVch6rApHq6OhxESQjJmmRP7TjPAf
uph/H2bP/oU+MLQw+Xdl9ulXdiYEHPWhfsRQLxdovoDmEGxk31nWWJtk7v7w
ds0AwowEEBYKAD4FAmT+vRwECwkHCAkQGZnge+9oRYYDFQgKBBYAAgECGQEC
GwMCHgEWIQQumfhlF+PAGABk/GYZmeB772hFhgAA5WcBANS1b6/EkRTFptPK
dkEm15xHtKCYrByt5U9bPYLYYN1YAP9oq9GXuMPt91Nf/1ali1/44Yd3Mhap
riOGSvYp4/mSBseLBGT+vRwSCisGAQQBl1UBBQEBB0B7rEgrJyoQAlvvMTFN
GIdCoxd/P8nsF2K1nf2Vo54wZQMBCAf+CQMI5JD3KKi4qc3gR5gzr+EDFnmY
VecqGAImkK/y5abLjwQJynTc12BCdkyOX1JsPcVmbfVjjI9hu4JYmQlxHW26
UdP3bi+r3MwgkYqp3gJWi8J4BBgWCAAqBQJk/r0cCRAZmeB772hFhgIbDBYh
BC6Z+GUX48AYAGT8ZhmZ4HvvaEWGAAC1nQEA6DGx7+Gn1K0FFuFrGBNpC/Cj
Gn8gTAAfmCkvWdnvdjEBAPbpnsjnO5cck+qVolTdCmntsyu6tt+4e+BEQuOS
Q+UN
=MAfV
-----END PGP PRIVATE KEY BLOCK-----" data-event-data="[{&quot;abbr&quot;: &quot;R_Date&quot;, &quot;header&quot;: &quot;Dit is een date&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;hlig1\&quot;>Met een hele mooie beschrijving</p>&quot;, &quot;datatype&quot;: &quot;date&quot;}, {&quot;abbr&quot;: &quot;R_date_wth_category&quot;, &quot;header&quot;: &quot;datum met categorie&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;gnfdq\&quot;>hallo</p>&quot;, &quot;datatype&quot;: &quot;date with category&quot;}, {&quot;abbr&quot;: &quot;R_date&quot;, &quot;header&quot;: &quot;datum&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;8q7t9\&quot;>een enkele datum</p>&quot;, &quot;datatype&quot;: &quot;date&quot;}, {&quot;abbr&quot;: &quot;R_date_with_category&quot;, &quot;header&quot;: &quot;Datum met category&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;w95iw\&quot;>conten</p>&quot;, &quot;datatype&quot;: &quot;date with category&quot;}, {&quot;abbr&quot;: &quot;R_Datee&quot;, &quot;header&quot;: &quot;Dit is een date two&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;fy15v\&quot;>Met een hele mooie beschrijving</p>&quot;, &quot;datatype&quot;: &quot;date&quot;}, {&quot;abbr&quot;: &quot;R_date_range_two&quot;, &quot;header&quot;: &quot;date ranges&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;aofq6\&quot;>jo</p>&quot;, &quot;datatype&quot;: &quot;date range&quot;}, {&quot;abbr&quot;: &quot;R_dates&quot;, &quot;header&quot;: &quot;meerdere datums&quot;, &quot;content&quot;: &quot;&quot;, &quot;datatype&quot;: &quot;date&quot;}, {&quot;abbr&quot;: &quot;R_Dateee&quot;, &quot;header&quot;: &quot;Dit is een date drie&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;dus0o\&quot;>Met een hele mooie beschrijving</p>&quot;, &quot;datatype&quot;: &quot;date&quot;}, {&quot;abbr&quot;: &quot;R_date_range&quot;, &quot;header&quot;: &quot;header date range&quot;, &quot;content&quot;: &quot;&quot;, &quot;datatype&quot;: &quot;date range&quot;}, {&quot;abbr&quot;: &quot;R_registratie_middel_Dividendbelasting_jaar&quot;, &quot;header&quot;: &quot;datum eerste register&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;v89lp\&quot;>a;lkdfja;lsdkfjads;lkfj</p><p data-block-key=\&quot;314cq\&quot;>R_registratie_middel_Dividendbelasting_jaar</p>&quot;, &quot;datatype&quot;: &quot;bool&quot;}, {&quot;abbr&quot;: &quot;R_year_with_cat&quot;, &quot;header&quot;: &quot;jaar met categorie&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;iztqg\&quot;>content voor jaar met categorie</p>&quot;, &quot;datatype&quot;: &quot;year with category&quot;}, {&quot;abbr&quot;: &quot;R_year_range&quot;, &quot;header&quot;: &quot;year range&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;179dz\&quot;>jo</p>&quot;, &quot;datatype&quot;: &quot;year range&quot;}, {&quot;abbr&quot;: &quot;E_bpg_in_fsv_geregistreerd_ja&quot;, &quot;header&quot;: &quot;Er zijn bijzondere persoonsgegevens van u geregistreerd in de FSV.&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;e3yfi\&quot;>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas ut ligula ut arcu fermentum mattis. Suspendisse ut nisl at orci tincidunt bibendum. Integer id erat at nisi finibus porttitor consequat gravida mauris. Sed cursus porttitor pharetra. Nam mi arcu, pellentesque id scelerisque ullamcorper, lobortis id tortor. Curabitur posuere pellentesque leo et consequat. Donec ex risus, volutpat vel porta non, venenatis sit amet turpis. Integer sapien nunc, pulvinar vel felis vel, sodales blandit ante. Aenean lacinia, diam quis tempor pretium, lectus lacus porttitor nisi, tincidunt feugiat urna purus sit amet sem. Suspendisse blandit diam nulla, et cursus ex tincidunt a. Maecenas ut augue eu orci scelerisque porta. Nulla et felis placerat, luctus diam eget, viverra mi. Vestibulum ultrices vel est ac sagittis. Vestibulum auctor quam sodales, venenatis urna quis, posuere ante.</p>&quot;, &quot;datatype&quot;: &quot;bool&quot;}, {&quot;abbr&quot;: &quot;E_bpg_in_fsv_geregistreerd_nee&quot;, &quot;header&quot;: &quot;Er zijn geen bijzondere persoonsgegevens van u geregistreerd in de FSV&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;kxr73\&quot;>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas ut ligula ut arcu fermentum mattis. Suspendisse ut nisl at orci tincidunt bibendum. Integer id erat at nisi finibus porttitor consequat gravida mauris. Sed cursus porttitor pharetra. Nam mi arcu, pellentesque id scelerisque ullamcorper, lobortis id tortor. Curabitur posuere pellentesque leo et consequat. Donec ex risus, volutpat vel porta non, venenatis sit amet turpis. Integer sapien nunc, pulvinar vel felis vel, sodales blandit ante. Aenean lacinia, diam quis tempor pretium, lectus lacus porttitor nisi, tincidunt feugiat urna purus sit amet sem. Suspendisse blandit diam nulla, et cursus ex tincidunt a. Maecenas ut augue eu orci scelerisque porta. Nulla et felis placerat, luctus diam eget, viverra mi. Vestibulum ultrices vel est ac sagittis. Vestibulum auctor quam sodales, venenatis urna quis, posuere ante.</p>&quot;, &quot;datatype&quot;: &quot;bool&quot;}, {&quot;abbr&quot;: &quot;E_externe_gegevens_gedeeld_ja&quot;, &quot;header&quot;: &quot;Uw FSV-gegevens zijn genoemd in communicatie met andere overheidsorganisaties.&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;cbhnx\&quot;>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas ut ligula ut arcu fermentum mattis. Suspendisse ut nisl at orci tincidunt bibendum. Integer id erat at nisi finibus porttitor consequat gravida mauris. Sed cursus porttitor pharetra. Nam mi arcu, pellentesque id scelerisque ullamcorper, lobortis id tortor. Curabitur posuere pellentesque leo et consequat. Donec ex risus, volutpat vel porta non, venenatis sit amet turpis. Integer sapien nunc, pulvinar vel felis vel, sodales blandit ante. Aenean lacinia, diam quis tempor pretium, lectus lacus porttitor nisi, tincidunt feugiat urna purus sit amet sem. Suspendisse blandit diam nulla, et cursus ex tincidunt a. Maecenas ut augue eu orci scelerisque porta. Nulla et felis placerat, luctus diam eget, viverra mi. Vestibulum ultrices vel est ac sagittis. Vestibulum auctor quam sodales, venenatis urna quis, posuere ante.</p>&quot;, &quot;datatype&quot;: &quot;bool&quot;}, {&quot;abbr&quot;: &quot;M_melding_delen_gegevens_ja&quot;, &quot;header&quot;: &quot;deling gegevens ja&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;pqyae\&quot;>Flannel JOMO DSA Brooklyn.  Freegan umami thundercats marxism, austin  stumptown waistcoat.  Artisan pabst bitters, cardigan subway tile  intelligentsia solarpunk bodega boys raclette offal cred flexitarian.   Blog crucifix pinterest lumbersexual semiotics schlitz brunch palo santo  listicle raclette.  Green juice cardigan ugh yr bodega boys gluten-free  slow-carb authentic, flannel migas hammock small batch mumblecore fixie  salvia.</p>&quot;, &quot;datatype&quot;: &quot;date&quot;}, {&quot;abbr&quot;: &quot;T_tegemoetkoming_bpg&quot;, &quot;header&quot;: &quot;tegenmoetkoming&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;e0zep\&quot;>content</p>&quot;, &quot;datatype&quot;: &quot;bool&quot;}, {&quot;abbr&quot;: &quot;R_registratie_middel_inkomstenbelasting_belastingjaar&quot;, &quot;header&quot;: &quot;Inkomstenbelasting&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;50ug4\&quot;>Meh gatekeep sunt deserunt, unicorn selvage distillery hella.  Snackwave  minim master cleanse, jawn pour-over mukbang tbh stumptown.   Adipisicing meggings gluten-free magna labore mustache.  Banh mi  typewriter shaman, jianbing etsy lyft messenger bag.  Labore twee  williamsburg live-edge, sartorial vice proident grailed ennui direct  trade migas.</p>&quot;, &quot;datatype&quot;: &quot;year&quot;}, {&quot;abbr&quot;: &quot;R_registratie_middel_Loonbelasting_jaar&quot;, &quot;header&quot;: &quot;registratie middel loonbelasting&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;hnwho\&quot;>I&amp;#x27;m baby dSA art party pok pok yes plz, pour-over iPhone lo-fi. Mukbang asymmetrical woke umami hashtag. Iceland direct trade fingerstache man bun scenester echo park cray sartorial readymade selvage glossier ramps. Crucifix master cleanse stumptown gatekeep man bun XOXO retro knausgaard unicorn air plant mlkshk woke. JOMO biodiesel tousled, meditation kickstarter bitters chicharrones offal vibecession banh mi cornhole celiac. Polaroid fit banh mi, authentic humblebrag squid quinoa next level kale chips stumptown. Chartreuse gatekeep cardigan banh mi subway tile copper mug kinfolk.</p>&quot;, &quot;datatype&quot;: &quot;year&quot;}, {&quot;abbr&quot;: &quot;E_bpg_met_effect_nee&quot;, &quot;header&quot;: &quot;header&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;hhh9h\&quot;>E_bpg_met_effect_nee</p><p data-block-key=\&quot;e8vn4\&quot;><a href=\&quot;/\&quot;>Home</a></p>&quot;, &quot;datatype&quot;: &quot;bool&quot;}, {&quot;abbr&quot;: &quot;E_externe_gegevens_gedeeld_nee&quot;, &quot;header&quot;: &quot;Uw FSV-gegevens zijn niet gedeeld met andere organisaties.&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;yssb1\&quot;>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas ut ligula ut arcu fermentum mattis. Suspendisse ut nisl at orci tincidunt bibendum. Integer id erat at nisi finibus porttitor consequat gravida mauris. Sed cursus porttitor pharetra. Nam mi arcu, pellentesque id scelerisque ullamcorper, lobortis id tortor. Curabitur posuere pellentesque leo et consequat. Donec ex risus, volutpat vel porta non, venenatis sit amet turpis. Integer sapien nunc, pulvinar vel felis vel, sodales blandit ante. Aenean lacinia, diam quis tempor pretium, lectus lacus porttitor nisi, tincidunt feugiat urna purus sit amet sem. Suspendisse blandit diam nulla, et cursus ex tincidunt a. Maecenas ut augue eu orci scelerisque porta. Nulla et felis placerat, luctus diam eget, viverra mi. Vestibulum ultrices vel est ac sagittis. Vestibulum auctor quam sodales, venenatis urna quis, posuere ante.</p>&quot;, &quot;datatype&quot;: &quot;bool&quot;}, {&quot;abbr&quot;: &quot;E_resultaat_geen_effect&quot;, &quot;header&quot;: &quot;Het onderzoek naar de gevolgen van uw FSV-registratie is afgerond. Uit ons onderzoek blijkt dat u geen gevolgen heeft gehad van uw FSV registratie.&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;a0ab7\&quot;>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas ut ligula ut arcu fermentum mattis. Suspendisse ut nisl at orci tincidunt bibendum. Integer id erat at nisi finibus porttitor consequat gravida mauris. Sed cursus porttitor pharetra. Nam mi arcu, pellentesque id scelerisque ullamcorper, lobortis id tortor. Curabitur posuere pellentesque leo et consequat. Donec ex risus, volutpat vel porta non, venenatis sit amet turpis. Integer sapien nunc, pulvinar vel felis vel, sodales blandit ante. Aenean lacinia, diam quis tempor pretium, lectus lacus porttitor nisi, tincidunt feugiat urna purus sit amet sem. Suspendisse blandit diam nulla, et cursus ex tincidunt a. Maecenas ut augue eu orci scelerisque porta. Nulla et felis placerat, luctus diam eget, viverra mi. Vestibulum ultrices vel est ac sagittis. Vestibulum auctor quam sodales, venenatis urna quis, posuere ante.</p>&quot;, &quot;datatype&quot;: &quot;bool&quot;}, {&quot;abbr&quot;: &quot;E_resultaat_verder_onderzoeken&quot;, &quot;header&quot;: &quot;Het onderzoek naar de gevolgen van uw FSV-registratie is nog niet afgerond.&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;0av02\&quot;>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas ut ligula ut arcu fermentum mattis. Suspendisse ut nisl at orci tincidunt bibendum. Integer id erat at nisi finibus porttitor consequat gravida mauris. Sed cursus porttitor pharetra. Nam mi arcu, pellentesque id scelerisque ullamcorper, lobortis id tortor. Curabitur posuere pellentesque leo et consequat. Donec ex risus, volutpat vel porta non, venenatis sit amet turpis. Integer sapien nunc, pulvinar vel felis vel, sodales blandit ante. Aenean lacinia, diam quis tempor pretium, lectus lacus porttitor nisi, tincidunt feugiat urna purus sit amet sem. Suspendisse blandit diam nulla, et cursus ex tincidunt a. Maecenas ut augue eu orci scelerisque porta. Nulla et felis placerat, luctus diam eget, viverra mi. Vestibulum ultrices vel est ac sagittis. Vestibulum auctor quam sodales, venenatis urna quis, posuere ante.</p>&quot;, &quot;datatype&quot;: &quot;bool&quot;}, {&quot;abbr&quot;: &quot;E_resultaat_verklaarbaar_effect&quot;, &quot;header&quot;: &quot;Het onderzoek naar de gevolgen van uw FSV-registratie is afgerond. Uit ons ondezoek blijkt dat u geen gevolgen heeft gehad van uw FSV registratie.&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;gqons\&quot;>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas ut ligula ut arcu fermentum mattis. Suspendisse ut nisl at orci tincidunt bibendum. Integer id erat at nisi finibus porttitor consequat gravida mauris. Sed cursus porttitor pharetra. Nam mi arcu, pellentesque id scelerisque ullamcorper, lobortis id tortor. Curabitur posuere pellentesque leo et consequat. Donec ex risus, volutpat vel porta non, venenatis sit amet turpis. Integer sapien nunc, pulvinar vel felis vel, sodales blandit ante. Aenean lacinia, diam quis tempor pretium, lectus lacus porttitor nisi, tincidunt feugiat urna purus sit amet sem. Suspendisse blandit diam nulla, et cursus ex tincidunt a. Maecenas ut augue eu orci scelerisque porta. Nulla et felis placerat, luctus diam eget, viverra mi. Vestibulum ultrices vel est ac sagittis. Vestibulum auctor quam sodales, venenatis urna quis, posuere ante.</p>&quot;, &quot;datatype&quot;: &quot;bool&quot;}, {&quot;abbr&quot;: &quot;E_resultaat_wel_effect&quot;, &quot;header&quot;: &quot;Het onderzoek naar de gevolgen van uw FSV-registratie is afgerond. Uit ons onderzoek blijkt dat u gevolgen heeft gehad van uw FSV registratie.&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;xllim\&quot;>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas ut ligula ut arcu fermentum mattis. Suspendisse ut nisl at orci tincidunt bibendum. Integer id erat at nisi finibus porttitor consequat gravida mauris. Sed cursus porttitor pharetra. Nam mi arcu, pellentesque id scelerisque ullamcorper, lobortis id tortor. Curabitur posuere pellentesque leo et consequat. Donec ex risus, volutpat vel porta non, venenatis sit amet turpis. Integer sapien nunc, pulvinar vel felis vel, sodales blandit ante. Aenean lacinia, diam quis tempor pretium, lectus lacus porttitor nisi, tincidunt feugiat urna purus sit amet sem. Suspendisse blandit diam nulla, et cursus ex tincidunt a. Maecenas ut augue eu orci scelerisque porta. Nulla et felis placerat, luctus diam eget, viverra mi. Vestibulum ultrices vel est ac sagittis. Vestibulum auctor quam sodales, venenatis urna quis, posuere ante.</p>&quot;, &quot;datatype&quot;: &quot;bool&quot;}, {&quot;abbr&quot;: &quot;E_ve_afwijzing_btr_of_kws_ja&quot;, &quot;header&quot;: &quot;U heeft een afwijzing van een persoonlijke betalingsregeling of kwijtschelding van belasting- of toeslagschuld gehad. Deze afwijzing stond los van uw registratie in FSV.&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;2nnl6\&quot;>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas ut ligula ut arcu fermentum mattis. Suspendisse ut nisl at orci tincidunt bibendum. Integer id erat at nisi finibus porttitor consequat gravida mauris. Sed cursus porttitor pharetra. Nam mi arcu, pellentesque id scelerisque ullamcorper, lobortis id tortor. Curabitur posuere pellentesque leo et consequat. Donec ex risus, volutpat vel porta non, venenatis sit amet turpis. Integer sapien nunc, pulvinar vel felis vel, sodales blandit ante. Aenean lacinia, diam quis tempor pretium, lectus lacus porttitor nisi, tincidunt feugiat urna purus sit amet sem. Suspendisse blandit diam nulla, et cursus ex tincidunt a. Maecenas ut augue eu orci scelerisque porta. Nulla et felis placerat, luctus diam eget, viverra mi. Vestibulum ultrices vel est ac sagittis. Vestibulum auctor quam sodales, venenatis urna quis, posuere ante.</p>&quot;, &quot;datatype&quot;: &quot;bool&quot;}, {&quot;abbr&quot;: &quot;E_ve_afwijzing_btr_of_kws_nee&quot;, &quot;header&quot;: &quot;U heeft geen afwijzing van een persoonlijke betalingsregeling of kwijtschelding van belasting- of toeslagschuld gehad welke een gevolg is geweest van uw FSV registratie.&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;kh75x\&quot;>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas ut ligula ut arcu fermentum mattis. Suspendisse ut nisl at orci tincidunt bibendum. Integer id erat at nisi finibus porttitor consequat gravida mauris. Sed cursus porttitor pharetra. Nam mi arcu, pellentesque id scelerisque ullamcorper, lobortis id tortor. Curabitur posuere pellentesque leo et consequat. Donec ex risus, volutpat vel porta non, venenatis sit amet turpis. Integer sapien nunc, pulvinar vel felis vel, sodales blandit ante. Aenean lacinia, diam quis tempor pretium, lectus lacus porttitor nisi, tincidunt feugiat urna purus sit amet sem. Suspendisse blandit diam nulla, et cursus ex tincidunt a. Maecenas ut augue eu orci scelerisque porta. Nulla et felis placerat, luctus diam eget, viverra mi. Vestibulum ultrices vel est ac sagittis. Vestibulum auctor quam sodales, venenatis urna quis, posuere ante.</p>&quot;, &quot;datatype&quot;: &quot;bool&quot;}, {&quot;abbr&quot;: &quot;E_ve_ih_correctie_ja&quot;, &quot;header&quot;: &quot;Uw aangifte inkomstenbelasting bleek niet juist ingevuld. Er is hierop een correctie geweest. Deze correctie stond los van uw registratie in FSV.&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;z9ane\&quot;>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas ut ligula ut arcu fermentum mattis. Suspendisse ut nisl at orci tincidunt bibendum. Integer id erat at nisi finibus porttitor consequat gravida mauris. Sed cursus porttitor pharetra. Nam mi arcu, pellentesque id scelerisque ullamcorper, lobortis id tortor. Curabitur posuere pellentesque leo et consequat. Donec ex risus, volutpat vel porta non, venenatis sit amet turpis. Integer sapien nunc, pulvinar vel felis vel, sodales blandit ante. Aenean lacinia, diam quis tempor pretium, lectus lacus porttitor nisi, tincidunt feugiat urna purus sit amet sem. Suspendisse blandit diam nulla, et cursus ex tincidunt a. Maecenas ut augue eu orci scelerisque porta. Nulla et felis placerat, luctus diam eget, viverra mi. Vestibulum ultrices vel est ac sagittis. Vestibulum auctor quam sodales, venenatis urna quis, posuere ante.</p>&quot;, &quot;datatype&quot;: &quot;bool&quot;}, {&quot;abbr&quot;: &quot;E_ve_ih_correctie_nee&quot;, &quot;header&quot;: &quot;Er is geen correctie geweest van uw inkomstenbelasting welke een gevolg is geweest van FSV.&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;jp2jv\&quot;>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas ut ligula ut arcu fermentum mattis. Suspendisse ut nisl at orci tincidunt bibendum. Integer id erat at nisi finibus porttitor consequat gravida mauris. Sed cursus porttitor pharetra. Nam mi arcu, pellentesque id scelerisque ullamcorper, lobortis id tortor. Curabitur posuere pellentesque leo et consequat. Donec ex risus, volutpat vel porta non, venenatis sit amet turpis. Integer sapien nunc, pulvinar vel felis vel, sodales blandit ante. Aenean lacinia, diam quis tempor pretium, lectus lacus porttitor nisi, tincidunt feugiat urna purus sit amet sem. Suspendisse blandit diam nulla, et cursus ex tincidunt a. Maecenas ut augue eu orci scelerisque porta. Nulla et felis placerat, luctus diam eget, viverra mi. Vestibulum ultrices vel est ac sagittis. Vestibulum auctor quam sodales, venenatis urna quis, posuere ante.</p>&quot;, &quot;datatype&quot;: &quot;bool&quot;}, {&quot;abbr&quot;: &quot;E_ve_lh_of_ob_correctie_ja&quot;, &quot;header&quot;: &quot;Uw aangifte loonheffing of omzetbelasting bleek niet juist ingevuld. Er is hierop een correctie geweest. Deze correctie stond los van uw registratie in FSV.&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;yus8i\&quot;>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas ut ligula ut arcu fermentum mattis. Suspendisse ut nisl at orci tincidunt bibendum. Integer id erat at nisi finibus porttitor consequat gravida mauris. Sed cursus porttitor pharetra. Nam mi arcu, pellentesque id scelerisque ullamcorper, lobortis id tortor. Curabitur posuere pellentesque leo et consequat. Donec ex risus, volutpat vel porta non, venenatis sit amet turpis. Integer sapien nunc, pulvinar vel felis vel, sodales blandit ante. Aenean lacinia, diam quis tempor pretium, lectus lacus porttitor nisi, tincidunt feugiat urna purus sit amet sem. Suspendisse blandit diam nulla, et cursus ex tincidunt a. Maecenas ut augue eu orci scelerisque porta. Nulla et felis placerat, luctus diam eget, viverra mi. Vestibulum ultrices vel est ac sagittis. Vestibulum auctor quam sodales, venenatis urna quis, posuere ante.</p>&quot;, &quot;datatype&quot;: &quot;bool&quot;}, {&quot;abbr&quot;: &quot;R_registratie_reden_gecommuniceerd_Buitenlands_vermogen&quot;, &quot;header&quot;: &quot;gecommuniceerd buitenlands vermogen&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;zij0q\&quot;>I&amp;#x27;m baby dSA art party pok pok yes plz, pour-over iPhone lo-fi.  Mukbang  asymmetrical woke umami hashtag.  Iceland direct trade fingerstache man  bun scenester echo park cray sartorial readymade selvage glossier  ramps.  Crucifix master cleanse stumptown gatekeep man bun XOXO retro  knausgaard unicorn air plant mlkshk woke.  JOMO biodiesel tousled,  meditation kickstarter bitters chicharrones offal vibecession banh mi  cornhole celiac.  Polaroid fit banh mi, authentic humblebrag squid  quinoa next level kale chips stumptown.  Chartreuse gatekeep cardigan  banh mi subway tile copper mug kinfolk.</p>&quot;, &quot;datatype&quot;: &quot;bool&quot;}, {&quot;abbr&quot;: &quot;E_ve_lh_of_ob_correctie_nee&quot;, &quot;header&quot;: &quot;Er is geen correctie geweest van uw loonheffing of omzetblasting welke een gevolg is geweest van FSV.&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;jqvbk\&quot;>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas ut ligula ut arcu fermentum mattis. Suspendisse ut nisl at orci tincidunt bibendum. Integer id erat at nisi finibus porttitor consequat gravida mauris. Sed cursus porttitor pharetra. Nam mi arcu, pellentesque id scelerisque ullamcorper, lobortis id tortor. Curabitur posuere pellentesque leo et consequat. Donec ex risus, volutpat vel porta non, venenatis sit amet turpis. Integer sapien nunc, pulvinar vel felis vel, sodales blandit ante. Aenean lacinia, diam quis tempor pretium, lectus lacus porttitor nisi, tincidunt feugiat urna purus sit amet sem. Suspendisse blandit diam nulla, et cursus ex tincidunt a. Maecenas ut augue eu orci scelerisque porta. Nulla et felis placerat, luctus diam eget, viverra mi. Vestibulum ultrices vel est ac sagittis. Vestibulum auctor quam sodales, venenatis urna quis, posuere ante.</p>&quot;, &quot;datatype&quot;: &quot;bool&quot;}, {&quot;abbr&quot;: &quot;E_ve_msnp_afwijzing_ja&quot;, &quot;header&quot;: &quot;U heeft een afwijzing voor een traject voor minnelijke schuldsanering (Msnp) gehad. Deze correctie stond los van uw registratie in FSV.&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;aaihy\&quot;>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas ut ligula ut arcu fermentum mattis. Suspendisse ut nisl at orci tincidunt bibendum. Integer id erat at nisi finibus porttitor consequat gravida mauris. Sed cursus porttitor pharetra. Nam mi arcu, pellentesque id scelerisque ullamcorper, lobortis id tortor. Curabitur posuere pellentesque leo et consequat. Donec ex risus, volutpat vel porta non, venenatis sit amet turpis. Integer sapien nunc, pulvinar vel felis vel, sodales blandit ante. Aenean lacinia, diam quis tempor pretium, lectus lacus porttitor nisi, tincidunt feugiat urna purus sit amet sem. Suspendisse blandit diam nulla, et cursus ex tincidunt a. Maecenas ut augue eu orci scelerisque porta. Nulla et felis placerat, luctus diam eget, viverra mi. Vestibulum ultrices vel est ac sagittis. Vestibulum auctor quam sodales, venenatis urna quis, posuere ante.</p>&quot;, &quot;datatype&quot;: &quot;bool&quot;}, {&quot;abbr&quot;: &quot;E_ve_msnp_afwijzing_nee&quot;, &quot;header&quot;: &quot;Er is geen correctie geweest van uw MSNP afwijzing welke een gevolg is geweest van FSV.&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;jcqs5\&quot;>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas ut ligula ut arcu fermentum mattis. Suspendisse ut nisl at orci tincidunt bibendum. Integer id erat at nisi finibus porttitor consequat gravida mauris. Sed cursus porttitor pharetra. Nam mi arcu, pellentesque id scelerisque ullamcorper, lobortis id tortor. Curabitur posuere pellentesque leo et consequat. Donec ex risus, volutpat vel porta non, venenatis sit amet turpis. Integer sapien nunc, pulvinar vel felis vel, sodales blandit ante. Aenean lacinia, diam quis tempor pretium, lectus lacus porttitor nisi, tincidunt feugiat urna purus sit amet sem. Suspendisse blandit diam nulla, et cursus ex tincidunt a. Maecenas ut augue eu orci scelerisque porta. Nulla et felis placerat, luctus diam eget, viverra mi. Vestibulum ultrices vel est ac sagittis. Vestibulum auctor quam sodales, venenatis urna quis, posuere ante.</p>&quot;, &quot;datatype&quot;: &quot;bool&quot;}, {&quot;abbr&quot;: &quot;R_registratie_middel_toeslagen_belastingjaar_2000&quot;, &quot;header&quot;: &quot;toeslagen 2000&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;86vt4\&quot;>Ipsum tote bag knausgaard, typewriter nisi echo park magna ascot.   Shabby chic elit meggings sustainable seitan twee flannel tattooed plaid  irure listicle food truck.  Deep v lyft plaid godard grailed.  Art  party waistcoat wayfarers master cleanse mukbang tilde ut yes plz  lumbersexual excepteur adipisicing.  Before they sold out marxism magna  crucifix gentrify velit.</p>&quot;, &quot;datatype&quot;: &quot;year&quot;}, {&quot;abbr&quot;: &quot;E_ve_tsl_correctie_ja&quot;, &quot;header&quot;: &quot;Uw toeslagenaanvraag bleek niet juist ingevuld. Er is hierop een correctie geweest. Deze correctie stond los van uw registratie in FSV.&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;8e361\&quot;>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas ut ligula ut arcu fermentum mattis. Suspendisse ut nisl at orci tincidunt bibendum. Integer id erat at nisi finibus porttitor consequat gravida mauris. Sed cursus porttitor pharetra. Nam mi arcu, pellentesque id scelerisque ullamcorper, lobortis id tortor. Curabitur posuere pellentesque leo et consequat. Donec ex risus, volutpat vel porta non, venenatis sit amet turpis. Integer sapien nunc, pulvinar vel felis vel, sodales blandit ante. Aenean lacinia, diam quis tempor pretium, lectus lacus porttitor nisi, tincidunt feugiat urna purus sit amet sem. Suspendisse blandit diam nulla, et cursus ex tincidunt a. Maecenas ut augue eu orci scelerisque porta. Nulla et felis placerat, luctus diam eget, viverra mi. Vestibulum ultrices vel est ac sagittis. Vestibulum auctor quam sodales, venenatis urna quis, posuere ante.</p>&quot;, &quot;datatype&quot;: &quot;bool&quot;}, {&quot;abbr&quot;: &quot;E_ve_tsl_correctie_nee&quot;, &quot;header&quot;: &quot;Er is geen correctie geweest van uw toeslagen welke een gevolg is geweest van FSV.&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;3qqj8\&quot;>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Maecenas ut ligula ut arcu fermentum mattis. Suspendisse ut nisl at orci tincidunt bibendum. Integer id erat at nisi finibus porttitor consequat gravida mauris. Sed cursus porttitor pharetra. Nam mi arcu, pellentesque id scelerisque ullamcorper, lobortis id tortor. Curabitur posuere pellentesque leo et consequat. Donec ex risus, volutpat vel porta non, venenatis sit amet turpis. Integer sapien nunc, pulvinar vel felis vel, sodales blandit ante. Aenean lacinia, diam quis tempor pretium, lectus lacus porttitor nisi, tincidunt feugiat urna purus sit amet sem. Suspendisse blandit diam nulla, et cursus ex tincidunt a. Maecenas ut augue eu orci scelerisque porta. Nulla et felis placerat, luctus diam eget, viverra mi. Vestibulum ultrices vel est ac sagittis. Vestibulum auctor quam sodales, venenatis urna quis, posuere ante.</p>&quot;, &quot;datatype&quot;: &quot;bool&quot;}, {&quot;abbr&quot;: &quot;R_year_two&quot;, &quot;header&quot;: &quot;header&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;owvdg\&quot;>lkj;lkj;lk</p>&quot;, &quot;datatype&quot;: &quot;year&quot;}, {&quot;abbr&quot;: &quot;M_gebeld_succes_ja&quot;, &quot;header&quot;: &quot;succesvol gebeld&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;r9iy4\&quot;>Flannel JOMO DSA Brooklyn.  Freegan umami thundercats marxism, austin  stumptown waistcoat.  Artisan pabst bitters, cardigan subway tile  intelligentsia solarpunk bodega boys raclette offal cred flexitarian.   Blog crucifix pinterest lumbersexual semiotics schlitz brunch palo santo  listicle raclette.  Green juice cardigan ugh yr bodega boys gluten-free  slow-carb authentic, flannel migas hammock small batch mumblecore fixie  salvia.</p>&quot;, &quot;datatype&quot;: &quot;date&quot;}, {&quot;abbr&quot;: &quot;R_year_ranges&quot;, &quot;header&quot;: &quot;header voor year ranges&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;wxm13\&quot;>ladidi</p>&quot;, &quot;datatype&quot;: &quot;year range&quot;}, {&quot;abbr&quot;: &quot;M_onderzoek_gaande_ja&quot;, &quot;header&quot;: &quot;Onderzoek gaande&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;o94o0\&quot;>Gatekeep kogi mlkshk bitters readymade shabby chic.  Jean shorts ethical  thundercats mustache.  Williamsburg meh authentic schlitz readymade.   Viral mustache hexagon ennui williamsburg.  Snackwave synth fashion axe  quinoa put a bird on it umami hella everyday carry.  Fingerstache 3 wolf  moon yuccie thundercats banjo cloud bread biodiesel bruh.</p>&quot;, &quot;datatype&quot;: &quot;bool&quot;}, {&quot;abbr&quot;: &quot;E_te_lang_it_p_ja&quot;, &quot;header&quot;: &quot;E_te_lang_it_p_ja&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;wrh6k\&quot;>E_te_lang_it_p_ja</p>&quot;, &quot;datatype&quot;: &quot;bool&quot;}, {&quot;abbr&quot;: &quot;R_registratie_middel_diverse_belastingen_belastingjaar&quot;, &quot;header&quot;: &quot;header diverse belastingen belastingjaar&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;8gqqh\&quot;>hallo.</p>&quot;, &quot;datatype&quot;: &quot;year&quot;}, {&quot;abbr&quot;: &quot;R_registratie_middel_loonheffingen_belastingjaar&quot;, &quot;header&quot;: &quot;header loonheffingen belastingjaar&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;fyhsz\&quot;>R_registratie_middel_loonheffingen_belastingjaar</p><p data-block-key=\&quot;c0snr\&quot;>R_registratie_middel_loonheffingen_belastingjaar</p>&quot;, &quot;datatype&quot;: &quot;year&quot;}, {&quot;abbr&quot;: &quot;E_gsl_bpg_met_effect_nee&quot;, &quot;header&quot;: &quot;effect hedader&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;izn3w\&quot;>E_gsl_bpg_met_effect_neeE_gsl_bpg_met_effect_nee</p>&quot;, &quot;datatype&quot;: &quot;category&quot;}, {&quot;abbr&quot;: &quot;E_gsl_afwijzing_kws_ja&quot;, &quot;header&quot;: &quot;E_gsl_afwijzing_kws_ja&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;pwy62\&quot;>E_gsl_afwijzing_kws_ja</p>&quot;, &quot;datatype&quot;: &quot;year&quot;}, {&quot;abbr&quot;: &quot;E_gsl_te_lang_it_p_ja&quot;, &quot;header&quot;: &quot;E_gsl_te_lang_it_p_ja&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;y28fp\&quot;>E_gsl_te_lang_it_p_ja</p>&quot;, &quot;datatype&quot;: &quot;date range&quot;}, {&quot;abbr&quot;: &quot;R_eerste_datum_fsv_registratie&quot;, &quot;header&quot;: &quot;Uw gegevens stonden voor het eerst geregistreerd in de FSV.&quot;, &quot;content&quot;: &quot;&quot;, &quot;datatype&quot;: &quot;date&quot;}, {&quot;abbr&quot;: &quot;M_onderzoek_afgerond&quot;, &quot;header&quot;: &quot;onderzoek afgerond&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;sp2y1\&quot;>Sriracha blackbird spyplane tonx affogato church-key hoodie sus next level bushwick hell of dreamcatcher chia chartreuse ascot. Etsy lo-fi VHS street art swag, heirloom kitsch messenger bag fixie banh mi slow-carb. Authentic schlitz kinfolk wayfarers try-hard, readymade synth dreamcatcher chambray man braid twee glossier raclette yr.</p>&quot;, &quot;datatype&quot;: &quot;date&quot;}, {&quot;abbr&quot;: &quot;E_test_links&quot;, &quot;header&quot;: &quot;Dit is een test om te kijken of interne en externe links het doen&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;jf4zu\&quot;><a href=\&quot;/nieuws/\&quot;>Interne link</a> (gaat naar nieuws)</p><p data-block-key=\&quot;6ovtt\&quot;><a href=\&quot;https://nos.nl\&quot;>Externe link</a> (gaat naar nos.nl)</p><p data-block-key=\&quot;gqmq\&quot;><a href=\&quot;mailto:wilfred@pleio.nl\&quot;>Email link</a></p><p data-block-key=\&quot;e77vd\&quot;><a href=\&quot;tel:0624269159\&quot;>Telefoonlink</a></p><p data-block-key=\&quot;47uiu\&quot;><a href=\&quot;#anchor\&quot;>anchor link</a></p><h5 data-block-key=\&quot;d213e\&quot;>anchor</h5><p data-block-key=\&quot;37hj9\&quot;></p><p data-block-key=\&quot;dfcc4\&quot;></p>&quot;, &quot;datatype&quot;: &quot;bool&quot;}, {&quot;abbr&quot;: &quot;M_Testcsv&quot;, &quot;header&quot;: &quot;M_Testcsv&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;qe083\&quot;>M_Testcsv</p>&quot;, &quot;datatype&quot;: &quot;bool&quot;}, {&quot;abbr&quot;: &quot;M_a&quot;, &quot;header&quot;: &quot;header a&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;ypflk\&quot;>content a</p>&quot;, &quot;datatype&quot;: &quot;date&quot;}, {&quot;abbr&quot;: &quot;M_b&quot;, &quot;header&quot;: &quot;header b zonder content&quot;, &quot;content&quot;: &quot;&quot;, &quot;datatype&quot;: &quot;date&quot;}, {&quot;abbr&quot;: &quot;M_Cdddddd&quot;, &quot;header&quot;: &quot;test&quot;, &quot;content&quot;: &quot;&quot;, &quot;datatype&quot;: &quot;date&quot;}, {&quot;abbr&quot;: &quot;M_c&quot;, &quot;header&quot;: &quot;test&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;n6tvi\&quot;>test</p>&quot;, &quot;datatype&quot;: &quot;date&quot;}, {&quot;abbr&quot;: &quot;E_afwijzing_kws_ja&quot;, &quot;header&quot;: &quot;afwijzining&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;306om\&quot;>E_afwijzing_kws_ja</p><p data-block-key=\&quot;m39p\&quot;><a href=\&quot;/over-deze-website/\&quot;>Over deze website</a></p>&quot;, &quot;datatype&quot;: &quot;bool&quot;}, {&quot;abbr&quot;: &quot;M_brief_ja&quot;, &quot;header&quot;: &quot;M_brief_ja&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;t5def\&quot;>M_brief_ja</p><p data-block-key=\&quot;1s1dd\&quot;><a href=\&quot;/over/over-de-fsv/\&quot;>telefoonnummer doorgeven</a></p>&quot;, &quot;datatype&quot;: &quot;bool&quot;}, {&quot;abbr&quot;: &quot;R_registratie_middel_onbekend_belastingjaar&quot;, &quot;header&quot;: &quot;header onbekend belastingjaar&quot;, &quot;content&quot;: &quot;<p data-block-key=\&quot;dvvrz\&quot;>R_registratie_middel_onbekend_belastingjaar</p><p data-block-key=\&quot;dtr55\&quot;>R_registratie_middel_onbekend_belastingjaar</p><p data-block-key=\&quot;eg69f\&quot;>R_registratie_middel_onbekend_belastingjaar</p><p data-block-key=\&quot;2pr07\&quot;><a href=\&quot;/over/\&quot;>Over de FSV</a></p>&quot;, &quot;datatype&quot;: &quot;year&quot;}]" data-encrypted-timeline="-----ORTVA CTC ZRFFNTR-----

jI4QMZIeNJAcW18FNDqNXFePEuc8998e0s5mOnMhJMnoSsOdMpkGD2eNYNp1
bm4jQRanHwPhk6lvP++36JzyRMnlBQMMAQIdzv0ypaeV6qLPSB6AAaT5cjkD
z7A0jDi20fV0NqsSh6PlT40u0QH3Pk12ma+o3EMbKtA3Kw3Xdfjux1Tb33CS
yJCaNp0+K9cpT9d8TXo70zigwB97R2r8QVvEgG53OeSuQQ1gkvhQqPgHpbgC
G7M0hMMp7//o83soWSvEAico/Ln0qAIcuDS0aJR3cAWYNxu03nd6ayNgHu0B
sfMhQHB9Vyx3vIkXfUG61qZK5DiXqEPFfjEnmcDf/WqVRBngLWqKA8RZTAjS
EdhN6DgDnruFqKRk5ecKWQvgqUFICMvyr1yxl6+Do2b3NGLby1AiZja8fIhD
k8W5s0e7uN7USKaEkYpM7YhJ8pJE2XtNnyncq8xrrG4rf1cYy8kMDRKbrji2
tuQ3f92yRj7PG85rgXiUpumis7khD/aWIfo+6XwoSU6OfokAO5mr7uRjK+zx
bXHKe5y/16EzqHC62xzVIz0/7OXU1SxKyA5larY52VasvlSBypJmAqrQyN60
Zd2b3WXOt7mBCQRS9SyJPUBEFj+rG3wz8sY4TgNZrpGCDC3iPerHTIzBKX/0
zVSVDbdtP6lO6wkeCZCQQSiJoMVyfdTs3v1Qxs7pjLJbN+kp6W3GrSDr2YJO
1XQCMoUwoJP5hU1hVnGO9Kng/3wsQ0QcYTqIPv7PIXqDcs3HBQx5vXYtg4iF
CkfKiNUf91ebmPBcM3PDeegL4FNkK0BoL+h8L7bL+DiMzzfXJ69yO++Ggzh+
vFh0KMNohbGtl0FZeNLWQJMzjl3zXLMd2MTHgbYUu4E4MWq7TuDLhQAPVD0U
2bSmBjw9sGrzk/lbHlw0DFvf6Lu1WMSs2ZAq47GyhvGlULb4fS6xNqvY6Ls4
It78W3BKsmTNlM9lOvVTNASrdiepFyJQjMotJ1H4k72uU+SYMcErOPeYR3LR
Ugs1zOYMJe4dAJnSy9VyTNZzeCAEhl/JZ6E2U4R/JJgFyBp3antakCNpCkY3
xcsar+KaK8t1siFtnwMnToHprF1EpkMhsNe0ea7g6SE5OsHowOIUQxZVVFf5
=7oyC
-----RAQ CTC ZRFFNTR-----
"></div>

    <fieldset id="form-personal-timeline-fieldset" hidden="">
        <h2>Uw persoonlijk overzicht staat klaar</h2>
        <p>Om uw persoonlijk overzicht te bekijken, moet u uw wachtwoord invullen.</p>
        <p>Heeft u vragen over het overzicht, dan kunt u ons bellen op 0800 235 83 56 (gratis).  Wij zijn bereikbaar van maandag tot en met vrijdag tussen 8.00 en 17.00 uur. Ook kunt u met ons chatten. Om te chatten klikt u op het chatsymbool rechtsonder in uw scherm.</p>

        <div class="formfield-container--wrapper">
            <div class="formfield-container">
                <label for="passphrase">Wachtwoord</label>
                <p class="explanation">Vul uw wachtwoord in. Dit is het wachtwoord dat u heeft ingesteld bij de aanvraag van het persoonlijk overzicht.</p>
                <div class="group">
                    <input type="password" name="passphrase" placeholder="Uw wachtwoord" id="timeline-passphrase" class="passphrase" required="" maxlength="64" autocomplete="off">
                    <button type="button" id="timeline-passphrase-toggle-button" class="button button-primary hidden" aria-label="Toon/verberg wachtwoord"></button>
                </div>

                <div id="timeline-passphrase-error-message" class="passphrase-error-message" data-message-enter-passphrase="Voer alstublieft een wachtwoord in." data-message-incorrect-passphrase="Incorrect wachtwoord" data-message-decrypt-key-error="Fout bij het ontsleutelen van de key" data-message-read-message-error="Fout bij het lezen van versleutelde data" data-message-decrypt-error="Fout bij het ontsleutelen van de data" data-message-could-not-parse-json="Kan de JSON niet parsen" data-message-error-importing-openpgpjs="De PGP-module kon niet worden geladen." data-message-sanity-check-failed="Er is iets fout gegaan." style="display: none;"></div>
            </div>
        </div>
        <div class="button-set">
            <button type="button" id="timeline-passphrase-button" class="passphrase-button button button-primary" data-track-content="" data-content-name="Toon_overzicht">
                Overzicht bekijken
                <img id="timeline-passphrase-spinner" class="passphrase-spinner" alt="" width="18" height="18" src="/static/img/spinner.svg">
            </button>

            <button type="button" id="timeline-passphrase-forgotten-button" class="passphrase-forgotten-button button button-primary" data-track-content="" data-content-name="wachtwoord_vergeten">
                Wachtwoord vergeten?
            </button>
        
        </div>
    </fieldset>

    <div id="personal-timeline-destination" aria-live="assertive" class="timeline">
        <div class="timeline__wrapper">
            <div class="timeline__inner">
                <div id="personal-timeline-container"><div class="timeline__section reasons">
                    <div class="timeline__intro">
                        <h2>Redenen van de registratie</h2>
                    </div><ol class="timeline__list">
                            <li class="timeline__item timeline--date">
                                <h4>Uw gegevens stonden voor het eerst geregistreerd in de FSV.</h4>
                                <span class="inner"><time datetime="12-06-2011">op 12 juni 2011</time></span></li>
                            <li class="timeline__item timeline--date">
                                <h4>datum</h4>
                                <p data-block-key="8q7t9">een enkele datum</p><span class="inner"><time datetime="10-06-2018">10 juni 2018</time></span></li>
                            <li class="timeline__item timeline--date">
                                <h4>meerdere datums</h4>
                                <ul><li class="inner"><time datetime="12-06-2013">12 juni 2013</time></li><li class="inner"><time datetime="12-06-2022">12 juni 2022</time></li></ul></li>
                            <li class="timeline__item timeline--year-with-category">
                                <h4>jaar met categorie</h4>
                                <p data-block-key="iztqg">content voor jaar met categorie</p><ol><li>
                                    <ol class="inner">
                                        <li>
                                            <time datetime="2012">2012</time>
                                        </li>
                                        <li>bla en bar</li>
                                    </ol>
                                </li><li>
                                    <ol class="inner">
                                        <li>
                                            <time datetime="2022">2022</time>
                                        </li>
                                        <li>aap noot mies en b</li>
                                    </ol>
                                </li></ol></li>
                            <li class="timeline__item timeline--year-with-category">
                                <h4>jaar met categorie</h4>
                                <p data-block-key="iztqg">content voor jaar met categorie</p><ol><li>
                                    <ol class="inner">
                                        <li>
                                            <time datetime="2012">2012</time>
                                        </li>
                                        <li>foo en bar</li>
                                    </ol>
                                </li><li>
                                    <ol class="inner">
                                        <li>
                                            <time datetime="2022">2022</time>
                                        </li>
                                        <li>a en b</li>
                                    </ol>
                                </li></ol></li>
                            <li class="timeline__item timeline--year">
                                <h4>header</h4>
                                <p data-block-key="owvdg">lkj;lkj;lk</p><ul>
                                    <li><time class="timeline__dateyear" datetime="2012">2012</time></li>
                                    <li><time class="timeline__dateyear" datetime="2014">2014</time></li></ul></li>
                            <li class="timeline__item timeline--date-with-category">
                                <h4>Datum met category</h4>
                                <p data-block-key="w95iw">conten</p><ol><li>
                                    <ol class="inner">
                                        <li>
                                            <time datetime="01-01-2024">01-01-2024</time>
                                        </li>
                                        <li>foo en bar</li>
                                    </ol>
                                </li><li>
                                    <ol class="inner">
                                        <li>
                                            <time datetime="02-05-2015">02-05-2015</time>
                                        </li>
                                        <li>a en b</li>
                                    </ol>
                                </li></ol></li>
                            <li class="timeline__item timeline--date-range">
                                <h4>date ranges</h4>
                                <p data-block-key="aofq6">jo</p>
                                    <ul class="timeline--ranges">
                                        <li><time class="timeline__dateyear" datetime="van 01-01-2012 tot 01-04-2023">van 01-01-2012 tot 01-04-2023</time></li><li><time class="timeline__dateyear" datetime="van 01-03-2018 tot 08-02-2020">van 01-03-2018 tot 08-02-2020</time></li>
                                    </ul>
                                </li>
                            <li class="timeline__item timeline--date-range">
                                <h4>header date range</h4>
                                
                                    <ul class="timeline--ranges">
                                        <li><time class="timeline__dateyear" datetime="van 01-01-2012 tot 01-04-2023">van 01-01-2012 tot 01-04-2023</time></li>
                                    </ul>
                                </li>
                            <li class="timeline__item timeline--year-range">
                                <h4>year range</h4>
                                <p data-block-key="179dz">jo</p>
                                    <ul class="timeline--ranges">
                                        <li><time class="timeline__dateyear" datetime="van 2009 tot 2012">van 2009 tot 2012</time></li>
                                    </ul>
                                </li>
                            <li class="timeline__item timeline--year-range">
                                <h4>header voor year ranges</h4>
                                <p data-block-key="wxm13">ladidi</p>
                                    <ul class="timeline--ranges">
                                        <li><time class="timeline__dateyear" datetime="van 2009 tot 2012">van 2009 tot 2012</time></li><li><time class="timeline__dateyear" datetime="van 2021 tot 2023">van 2021 tot 2023</time></li>
                                    </ul>
                                </li>
                            <li class="timeline__item timeline--end timeline__end">
                                <h4>Einde van uw FSV registratie</h4>
                                <time datetime="27-02-2020">op 27-02-2020</time>
                            </li></ol></div></div>
            </div>
        </div>
    </div>    
</form>



    <div id="request-timeline-data" data-timeline-status="" data-bd-public-key="-----BEGIN PGP PUBLIC KEY BLOCK-----

xjMEY/2+8BYJKwYBBAHaRw8BAQdAP5sMr1iDoIpVRBb4cYj4pcoPhT81OQKJ
q24BuwlNryTND0JlbGFzdGluZ2RpZW5zdMKMBBAWCgA+BQJj/b7wBAsJBwgJ
EGRPL6AWGM8KAxUICgQWAAIBAhkBAhsDAh4BFiEE8Nx5AZsI9uO1umknZE8v
oBYYzwoAACKiAP4rj8+W+pSvEMnVmGZWJg7q50lA2fyKMvSO4g1084akdAEA
uw7/qXEf8iMnmXwAqWD2N9jgTKgBnxlKmB+i1Ns8SAvOOARj/b7wEgorBgEE
AZdVAQUBAQdAi5WgMf9G19JFK4U9zQTkxDk0XUrL5fZoOXajvntAQ1UDAQgH
wngEGBYIACoFAmP9vvAJEGRPL6AWGM8KAhsMFiEE8Nx5AZsI9uO1umknZE8v
oBYYzwoAAI3JAP0buH99ViYi8Winz2ahSnTdUOEffNt15oes2mxWatArnAEA
q1bgxLDtq5yjLQcARBG17hBeRtTChFST6k3zCrDCtwQ=
=q3QB
-----END PGP PUBLIC KEY BLOCK-----"></div>

    <form class="fsv-form form-key-pair" id="form-key-pair" method="post" accept-charset="utf-8" aria-live="assertive">
        <input type="hidden" name="csrfmiddlewaretoken" value="eYrbROB4qeD0EZcEbsXaFrjHZStRwYsy2HAQ79kKdfHYKZyuuxUBDlvA73xMhFNh">
        <input type="hidden" name="public_key" value="">
        <input type="hidden" name="private_key" value="">
        <div id="passphrase-form" class="passphrase-form block-group">
            <h2>Vraag uw persoonlijk overzicht aan</h2>
            <p data-block-key="ndod1">Met de onderstaande knop kunt u uw persoonlijk overzicht aanvragen. Hiervoor is een wachtwoord nodig. Dit wachtwoord is een extra beveiliging van uw gegevens. Het kan enkele dagen duren voordat uw overzicht klaar staat. Wilt u een SMS ontvangen als het overzicht voor u klaar staat? Vul dan ook uw mobiele telefoonnummer in.</p>

            <div class="alert-box alert-warning">
                <p data-block-key="ww5ar"><b>Onthoud uw wachtwoord goed.</b> Hiermee kunt u later inloggen om uw overzicht te zien. Bent u uw wachtwoord vergeten? Dan moet u opnieuw het overzicht aanvragen.</p>
            </div>

            <button type="button" id="passphrase-show-form-button" class="passphrase-button button button-primary">
                Vraag uw overzicht aan
            </button>

            <fieldset class="input-box">
                <div id="passphrase-show-form-area" class="passphrase-show-form-area">
                    <div class="formfield-container--wrapper">
                        <div class="formfield-container">
                           <h5 data-block-key="47p5b">Wachtwoord</h5><p data-block-key="97gso">U heeft het wachtwoord dat u hier instelt opnieuw nodig wanneer uw tijdlijn is aangevraagd en klaar staat. Het is belangrijk om dit wachtwoord niet te vergeten en op een veilige plek op te schrijven.</p>
                             <div class="group">
                                <input type="password" name="passphrase" id="passphrase" class="passphrase" required="" maxlength="64" autocomplete="off">
                                <button type="button" id="passphrase-toggle-button" class="button button-primary hidden" aria-label="Toon/verberg wachtwoord"></button>
                            </div>
                            <div id="passphrase-error-message-0" class="alert-box alert-error" style="display: none;"></div>

                            <label for="passphrase-confirmation">Herhaal wachtwoord echt wel...</label>
                            <div class="group">
                                <input type="password" name="passphrase_confirmation" id="passphrase-confirmation" class="passphrase" required="" maxlength="64" autocomplete="off">
                                <button type="button" id="passphrase-confirmation-toggle-button" class="button button-primary hidden" aria-label="Toon/verberg wachtwoord"></button>
                            </div>
                            <div id="passphrase-error-message-1" class="alert-box alert-error" style="display: none;"></div>

                            <div class="passphrase-notification-group">
                                <input type="checkbox" value="1" id="passphrase-notification">
                                <label for="passphrase-notification" class="checkbox-label">Wilt u een SMS ontvangen wanneer uw persoonlijk overzicht voor u klaar staat en wanneer er nieuwe informatie beschikbaar is? Laat dan hier uw mobiele telefoonnummer achter:</label>
                            </div>

                            <div id="mobile-phone-number-container" class="mobile-phone-number-container">
                                <label for="mobile-phone-number">Telefoonnummer</label>
                                <small>Vul uw mobiele telefoonnummer in (10 cijfers).</small>
                                <input type="tel" name="mobile_phone_number" id="mobile-phone-number" class="passphrase-show-form-area__phone" pattern="[0-9]{10}" placeholder="06          12345678" data-last-eight-chars="">
                                 <!-- placeholder spaces are not a typo. Is needed for the design. 
                                MUST BE 10 WHITESPACES IN ORDER TO VALIDATE. See main-timeline.js ~line 88.-->
                                
                                </div>                          
                            <div id="passphrase-error-message" class="alert-box alert-error" data-message-enter-passphrase="Voer alstublieft een wachtwoord in." data-message-passphrase-too-short="Het wachtwoord moet minimaal %1% tekens lang zijn." data-message-confirm-passphrase="Voer het wachtwoord opnieuw in ter bevestiging." data-message-passphrases-not-equal="De wachtwoorden komen niet overeen." data-message-error-importing-openpgpjs="De PGP-module kon niet worden geladen." data-message-empty-key-pair="Het gegenereerde sleutelpaar is leeg." data-message-could-not-generate-key-pair="Het sleutelpaar kan niet worden gegenereerd." data-message-could-not-send-data="Het gegenereerde sleutelpaar kon niet worden opgeslagen." data-message-no-phone-number="Voer uw mobiele telefoonnummer in." data-message-invalid-phone-number="Voer een geldig telefoonnummer in (0612345678)." data-message-enter-ten-characters="Het ingevoerde telefoonnummer moet uit minimaal 10 cijfers bestaan." data-message-public-key-available="Geen public key beschikbaar." data-message-could-not-encrypt-data="Kon de gegevens niet versleutelen." data-message-invalid-phone-number-prefix="Het telefoonnummer moet beginnen met '06'. Vul alstublieft een geldig telefoonnummer in." style="display: none;"></div>
                        </div>
                    </div>
                    <button type="button" id="passphrase-button" class="passphrase-button button button-primary" data-track-content="" data-content-name="Overzicht_aangevraagd">
                        <span>Vraag uw overzicht aan</span>
                        <img id="passphrase-spinner" class="passphrase-spinner" alt="" width="18" height="18" src="/static/img/spinner.svg" style="display: none;">
                    </button>
                </div>
            </fieldset>
        </div>

            <div id="passphrase-success-message" class="passphrase-success-message" aria-live="polite">
                <h2>Uw persoonlijk overzicht is aangevraagd</h2>
                <p>Uw persoonlijk overzicht staat nog niet klaar. Dit kan enkele werkdagen duren. Heef u uw mobiele telefoonnummer aan ons doorgegeven? Dan ontvangt u een sms wanneer uw overzicht klaarstaat.</p>

                <div class="steps">
                    <div class="step step-1">
                        <div class="circle">
                            <div class="text">✓</div>
                        </div>
                        <div class="caption">Overzicht aangevraagd</div>
                    </div>
                    <div class="between">
                        <div class="line"></div>
                    </div>
                    <div class="step step-2">
                        <div class="circle">
                            <div class="text">2</div>
                        </div>
                        <div class="caption">Overzicht staat klaar</div>
                    </div>
                </div>

                <div class="reminder">
                    <div class="exclamation">
                        <div class="text">!</div>
                    </div>
                    <div class="text">Uw persoonlijk overzicht is aangevraagd. Onthoud uw wachtwoord goed. U heeft het wachtwoord nodig om de volgende keer in te loggen.</div>
                </div>
            </div>

    </form>


        
            <div class="block-group">
    
        
<ol class="faq">
    
        <li class="faq-item">
            <details open="">
                
                    
                        <summary>Ik wil een afspraak inplannen</summary>
                    
                
                    
                        <div class="paragraph"><p data-block-key="8e5ci">Heeft u een vraag , jonge?, over uw FSV-registratie of wilt u iets met ons bespreken? En wilt u telefonisch contact hierover? U kunt een afspraak maken via de onderstaande knop. We vragen u dan via uw telefoonnummer aan ons door te geven. Daarna kiest u zelf op welke datum en tijd u gebeld wilt worden. Een medewerker van de Belastingdienst neemt dan contact met u op.</p></div>

                    
                
                    
                        <a href="/online-afspraken/" class="button">Een afspraak inplannen</a>

                    
                
            </details>
        </li>
    
</ol>

    
</div>

        
            <div class="block-group">
    
        <h2 id="telefoonnummer-doorgeven">Telefoonnummer doorgeven</h2>

    
        

<div id="personal-preferences" class="personal-preferences" data-django-csrf-token="eYrbROB4qeD0EZcEbsXaFrjHZStRwYsy2HAQ79kKdfHYKZyuuxUBDlvA73xMhFNh" data-user-id="d470173f-6acd-4ac2-8fe5-94dafa68b14a" data-public-key="-----BEGIN PGP PUBLIC KEY BLOCK-----

xjMEY/2+8BYJKwYBBAHaRw8BAQdAP5sMr1iDoIpVRBb4cYj4pcoPhT81OQKJ
q24BuwlNryTND0JlbGFzdGluZ2RpZW5zdMKMBBAWCgA+BQJj/b7wBAsJBwgJ
EGRPL6AWGM8KAxUICgQWAAIBAhkBAhsDAh4BFiEE8Nx5AZsI9uO1umknZE8v
oBYYzwoAACKiAP4rj8+W+pSvEMnVmGZWJg7q50lA2fyKMvSO4g1084akdAEA
uw7/qXEf8iMnmXwAqWD2N9jgTKgBnxlKmB+i1Ns8SAvOOARj/b7wEgorBgEE
AZdVAQUBAQdAi5WgMf9G19JFK4U9zQTkxDk0XUrL5fZoOXajvntAQ1UDAQgH
wngEGBYIACoFAmP9vvAJEGRPL6AWGM8KAhsMFiEE8Nx5AZsI9uO1umknZE8v
oBYYzwoAAI3JAP0buH99ViYi8Winz2ahSnTdUOEffNt15oes2mxWatArnAEA
q1bgxLDtq5yjLQcARBG17hBeRtTChFST6k3zCrDCtwQ=
=q3QB
-----END PGP PUBLIC KEY BLOCK-----" data-external-id="070550657">
    <div class="form">
        <h2>Melding van deling FSV-registratie</h2>
        
        <p data-block-key="gvo8f">Vermoedt u dat uw FSV-registratie is gedeeld met een andere organisatie binnen de overheid? En wilt u dat aan ons melden? Dan kunt u hieronder uw telefoonnummer aan ons doorgeven. Een medewerker van de Belastingdienst neemt dan telefonisch contact met u op. U kunt ook zelf een afspraak maken.</p>

        <form name="personal_preferences_form">
            <div>
                <div class="phone-row">
                    <div class="phone-label">
                        <label for="input-phone">Telefoonnummer:</label>
                    </div>
                    <div class="phone-input">
                        <input class="input" type="tel" name="phone" maxlength="24" minlength="24" placeholder="0612345678" id="input-phone">
                    </div>
               </div>
            </div>

            <div class="consent-section">
                <label>
                    <input type="checkbox" name="consent" value="yes" id="input-consent">
                    <span class="caption">
                        <small>
                            Ik ga akkoord met het verwerken van mijn gegevens door de Belastingdienst.
                        </small>
                    </span>
                </label>
            </div>

            <p>
                <small>
                    <a href="https://fsvportaal.belastingdienst.nl/het-programma/" rel="noopener noreferrer" target="_blank">Lees meer
                        over hoe de Belastingdienst omgaat met privacy en persoonsgegevens.</a>
                </small>
            </p>

            <div class="error-message" aria-live="polite" data-message-enter-phone-number="Voer uw telefoonnummer in." data-data-message-no-letters="Voer a.u.b. alleen nummers in, letters zijn niet toegestaan." data-message-no-consent="Om verder te kunnen gaan hebben wij uw akkoord nodig om uw gegevens te kunnen verwerken." data-message-could-not-encrypt-data="Kon de gegevens niet versleutelen." data-message-could-not-process-data="De server kon de versleutelde gegevens niet verwerken." data-message-could-not-send-data="Kon de versleutelde data niet versturen." data-message-no-public-key="Geen public key beschikbaar." data-message-error-importing-openpgpjs="De PGP-module kon niet worden geladen."></div>

            <button type="submit" data-track-content="" data-content-name="melding_doorgeven" id="submit-button" class="submit-button button" disabled="">Verstuur</button>
        </form>
        
    </div>

    <div class="success">
        <h3 data-block-key="gnv50">Bedankt voor het doorgeven van uw melding.</h3><p data-block-key="nobv7">Wij hebben uw melding ‘Deling FSV-registratie’ ontvangen. Binnenkort nemen wij telefonisch contact met u op.</p><p data-block-key="rdubi"></p><p data-block-key="7ppwe">Wilt u liever zelf een afspraak maken? Dat kan <a href="https://fsvportaal.belastingdienst.nl/online-afspraken/">hier</a>.</p><p data-block-key="08cpn">Wilt u toch op een ander nummer gebeld worden dan u heeft opgegeven? Dan kunt u ons gratis bellen op 0800 235 83 56. We zijn bereikbaar van maandag tot en met vrijdag, tussen 8.00 en 17.00 uur.</p><h3 data-block-key="qdwkj">Persoonlijk overzicht</h3><p data-block-key="mp21l">U kunt de behandeling van uw melding volgen via uw persoonlijk overzicht op het FSV Portaal. Uw persoonlijk overzicht kunt u <a href="https://fsvportaal.belastingdienst.nl/ik-en-de-fsv/uw-persoonlijke-omgeving/#form-personal-timeline-fieldset">hier</a> aanvragen.</p><h3 data-block-key="qvhp6">Extra formulier inzageverzoek</h3><p data-block-key="107v6">In het telefoongesprek vertellen wij u dat u een inzageverzoek kunt doen bij de organisatie waarvan u vermoedt dat deze informatie over uw FSV-registratie heeft. U krijgt daarvoor een formulier per post thuisgestuurd. Wilt u een inzageverzoek doen bij meerdere organisaties? Dan kunt u een <a href="https://fsvportaal.belastingdienst.nl/documents/66/Aanvraagformulier_Melding_gegevensdeling_FSV-registratie.pdf">extra formulier hier downloaden</a>. In het document vindt u ook een uitleg hoe u het formulier kunt invullen.</p><p data-block-key="n9vzn">Kijk voor meer informatie in het artikel <a href="https://fsvportaal.belastingdienst.nl/nieuws/wat-gebeurt-er-nadat-u-een-melding-deling-fsv-registratie-heeft-gedaan/">‘Wat gebeurt er nadat u een melding ‘Deling FSV-registratie’ heeft gedaan?’</a></p>
    </div>
</div>


    
</div>

        
            <div class="block-group">
    
        <h2 id="uw-persoonlijke-tijdlijn">Uw persoonlijke tijdlijn</h2>

    
        
<ol class="timeline__list article-container">
    
    <li class="timeline__listitem">
        <details class="timeline__content" open="">
            <summary class="timeline__header">
                <p>Voorbeeld-event</p>
                <time class="timeline__time">
                    
                        
                            01-01-2023
                        
                    
                </time>
            </summary>
            <div class="timeline__body">
                
                <p data-block-key="n74zc">Dit is de inhoud, die automatisch uitgeklapt wordt</p>
                
            </div>
        </details>
    </li>
    
    <li class="timeline__listitem">
        <details class="timeline__content" open="">
            <summary class="timeline__header">
                <p>Nog een voorbeeld-event</p>
                <time class="timeline__time">
                    
                        
                            03-12-2022
                        
                    
                </time>
            </summary>
            <div class="timeline__body">
                
                <p data-block-key="1ypv7">Ook dit event heeft een inhoud. Ook dit event heeft een inhoud. Ook dit event heeft een inhoud. Ook dit event heeft een inhoud. Ook dit event heeft een inhoud. </p>
                
            </div>
        </details>
    </li>
    
</ol>

    
        <a href="/ik-en-de-fsv/uw-persoonlijke-tijdlijn/" class="button">Bekijk hele tijdlijn</a>

    
</div>

        
            <div class="block-highlighted block-highlighted__blue">
  <h3 data-block-key="0b41g">Chatten</h3><p data-block-key="agh6i">Op deze plek kunt u van maandag tot en met vrijdag tussen 10.00 en 16.00 uur chatten met een medewerker van de Belastingdienst. In het open veld kunt u een vraag stellen, waarna een van onze medewerkers persoonlijk reageert.</p><p data-block-key="e0apg">Is de chat gesloten of is het erg druk? Dan kunt u altijd op het FSV Portaal de <a href="/over/">veel gestelde vragen</a> bekijken.</p><p data-block-key="e7bf">Wilt u toch liever telefonisch informatie over de FSV krijgen? Dan kunt u van maandag tot en met vrijdag tussen 8.00 en 17.00 uur gratis bellen naar <a href="tel:08002358356">0800-235 8356</a>.</p>
</div>

        
            <div class="block-group">
    
        <h2 id="u-heeft-nu-de-volgende-mogelijkheden">U heeft nu de volgende mogelijkheden</h2>

    
        <ol class="faq">

    
<li class="faq-item">
    <details>
        <summary>Ik wil contact met een medewerker</summary>
        
            <div>
                <p data-block-key="0zvrc">Voorbeeld.</p>
            </div>
        
    </details>
</li>



</ol>

    
</div>

        
        </div>

    </article>


            
                <div class="research__button-wrapper">
                    <a href="https://xs.motivaction.nl/s.asp?u=D0726F36C1404E132C227DD1EF185A3EB1B2B85E" class="button button__research" target="_blank">
  Help onze dienstverlening te verbeteren</a>

                </div>
            
        </div>
    </main>