---
id: "bb5f8eb498544d3e90716decf30ad1ac"
tags: []
sortOrder: 48
preferredEditorMode: "raw"
createdAt: 1763524143589
modifiedAt: 1763524658359
---
There are some major ui and ux flaws. Especially on mobile.

(1) We should have semantic searching for likewise words or typos or things in the same context toggleable on or off but that doesn’t seem to appear in any search. The semantic matching should be very smart and understand synoniems and context regarding seks, nudidity, flirting, adult talk in Dutch  

(2) When i search I do get results but if i scroll to let’s say 8 year old and click on it it just loads page 1 instead of going to the correct message

(3) In production quite often if I press the search circle on mobile the page just gives nextjs error

(4) EASY QUICK FIX!

- - I miss a search filter button to only search on that specific string I entered. Not words containing that string. E.g.;query : wagon 
- Result should only find sentences with wagon in it. Not sentences with for example : wagons (because it doesn’t match exactly)

(5) EASY QUICK FIX 

- If I focus the search on a chat page itself it loses focus after first character, second also and from there I usually can keep typing but it often crashes (prod)

PRIORITY: It needs to be perfectly optimized for mobile viewing. Optimal ux and responsiveness. Code kwaliteit or methods used does not matter 1 bi

