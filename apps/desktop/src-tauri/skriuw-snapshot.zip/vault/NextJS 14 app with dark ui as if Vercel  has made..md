---
id: "890c3e487fef4d5aa0c372d369000b70"
tags: []
sortOrder: 30
preferredEditorMode: "block"
createdAt: 1732593658824
modifiedAt: 1768593749928
---
        
    NextJS 14 app with dark ui as if Vercel  has made.

I already have a enige dashboard setup so u only crate the main route which is a main view with a right extra info  sidebar 

I wanf a beautiful animated calendar with easy navigation + search for keywords or dates to receive entry’s gist were made the

U should be able to. Click in a date bloc and get the option to add new entry with a advanced amount of fields

Name
Event/type
Color 
Where/location 
Entire day?
Duration from duration till 
Multiple days?
Repeating? Till when
Want reminder? How many? How much before them (if 10 reminders and 10 min before it starts at 110 min before event 
With who? 
Add privacy lock pincode 

If adddd show color bullet on caldnxsd and allow to view entire entry or edit if. For now, store al data ik zustand.  Besides this I wanf integration with gmail calendar fo sync all entry’s I make here with my phone and vice versa.

If possible also outlook mail.

Again,  nex(js 14 no api routed typescript separate of concerns . 1 function per file. Easy maintained scalable. animate all nicely with teamed mofion 