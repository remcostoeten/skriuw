---
id: "4b338db3-fefc-41c6-8f9e-cfc26ba25e5e"
tags: []
sortOrder: 99
preferredEditorMode: "raw"
createdAt: 1748820222478
modifiedAt: 1750237173275
---
We are work in a new feature called "exposition sharing" where the student can ask the  coach to review their work and get an  expisiton graded. My  task is to rework the activityfeed which already e xists over at src/Components/ActivityFeed.

I attached the new design in the images. It's moreso of the same but some substantial differences which  I want to implement with you

Lets create a v2 with the same api as currently exists but with the new design.

Change #1
- The current activity feed is rendered ina custom sidebar/modal implementation, we are going to renewer it in the SidebarModal. So make it trigger via the sidebaarmodal as wrapper.

Changes #2 
- Slight changes in thedateindicators, very subtle.
Then for the 
The new design has horizontal bar pseudo selectors, check if current implementation has this.

Change #3
The title with “Opdracht ingeleverd/Opdracht beoordeeld in the new design has the timestamp at the. Right side meaning it has justify-content space between, whilst the current implementation has the timestamp eighth next to the title.


Changes #4
- The green badge with “goedgekeurd” or rejected has been removed.

Changes #5 
- Notice the color primary text link with “versie bekijken” where the title is bold, the text link is underline and primary and to the right is the timestamp.

Then for the biggest change which I want you to ignore for now, is the activitycard (the green one with the numeric / thumbs down in there), well pick that up later.


Let me know if u have any questions.

